# Generator guide (for sub-agents)

Root: `/home/claude/smarthome-dataset`. Read `generators/p01_sam.py` first. It is the reference persona. Copy its structure.

## Rules
- Do NOT edit anything in `lib/` or `trackers/`. If the builder can't do something you need, say so in your final report.
- One file per persona: `generators/<persona-id>.py` (use underscore: `p02_sara.py`), persona id like `p02-sara`.
- Use a fixed `seed` so output is reproducible. Run with `python3 generators/<file>.py` from the root.
- Window: 2026-08-08 to 2026-11-05 (90 days). Visit is 2026-11-06. Timezone America/New_York (builder handles UTC).
- Fake data only. Display names are first name + last initial.
- After generating, run `python3 lib/validate.py <persona-id>` and fix until OK.
- Then print the computed metrics and CHECK the story actually shows up in the numbers (adherence %, trends, symptom days, rescue days, FEV1 change). Tune parameters until it does. Ground truth text must match the numbers.

## Builder API (lib/smarthome.py)
```python
b = PatientBuilder(persona_id, display_name, age, sex, seed, enrolled_date=WINDOW_START, height_cm=None, dob=None)
r = b.rng                                   # use this for all randomness
b.assign_tracker("asthma" | "ibd" | "migraine")
b.add_tracker_reminder("asthma", "19:30", enabled=True)
med = b.add_medication(name, condition, how_often, icon, dose_qty, dose_unit,
                       times=["08:00","20:00"], period_unit="Daily"|"Weekly", interval=1,
                       archived=False, start_date=None, schedule_days=None)
#  how_often: "Daily", "As Needed", "Weekly", "Every 2 Weeks"
#  every 2 weeks -> period_unit="Weekly", interval=2, times=["09:00"]
#  weekly on a set day -> period_unit="Weekly", interval=1, start_date on that weekday
b.take_dose(med, day, "HH:MM" or (h, m), value=1)          # value = puffs/tablets, stored as string
b.submit(tracker_key, day, (h, m), {metricKey: value, ...})  # omit a key = question skipped
b.submit(tracker_key, day, (h, m), blank=True)               # submission with no responses
b.submit(tracker_key, day, (h, m), empty_values=True)        # every question present, value ""
b.add_spirobank()                                            # once, before spirometry
blows, best = b.spirometry_session(day, (h, m), pred, fev1_pct, n_blows=3, reject_prob=0.15,
                                   link_to_tracker=True, ratio_cap=None)
#  pred = {"fev1": L, "fvc": L, "pef": L/s}; fev1_pct like 0.82; ratio_cap like 0.72 forces obstruction
b.set_action_plan("Green"|"Yellow"|"Red", last_updated_iso, expiration_date, retest_time_iso_or_None)
b.save(ground_truth_dict)   # writes patients/ and ground_truth/, computes metrics + badges
```
Answer values by question type (see `trackers/*.json` for metricKeys and exact options):
- face_scale / single_choice / icon_choice: exact option string
- checkbox: python list of option strings (asthma none option has a trailing space: `"None of these "`)
- yes_no: True/False
- number / scale_1_10: int or float

Days with a medication due but no dose = missed. Don't call take_dose for missed doses.

## Ground truth dict (passed to save)
```python
{
  "name": str, "age": int, "conditions": [...], "viewers": [...specialists...],
  "scenario": "2 to 3 sentences, plain language",
  "clinician30s": "what a clinician should take away in 30 seconds",
  "expectedFlags": [{"flag": "short_snake_case", "severity": "high|medium|low", "for": ["Pulmonologist", ...], "evidence": "numbers from computedMetrics"}],
  "expectedNonFlags": ["things that look odd but should NOT be flagged, and why"],
  "keyFindings": {short key: plain value},
  "specialistViews": {"Pulmonologist": "what they care about here", ...},   # only for multi-specialist personas
  "injectedQuirks": ["data mess you added on purpose"],
}
```
Make the data realistic for a teen: logs mostly evenings, fewer on weekends, missed evening doses more than morning, occasional double submissions, occasional blank submissions, school days vs weekends, school missed only on weekdays.

## Realism references
- Asthma: rescue use > 2 days/week or night waking >= 1x/week = not well controlled (NAEPP/GINA). FEV1 < 80% predicted = reduced, < 60% = severe. Action plan zones: Green >= 80% personal best, Yellow 50 to 79%, Red < 50% (peak flow based).
- FEV1/FVC below about 0.75 to 0.80 in teens suggests obstruction.
- Migraine: chronic migraine = headache on >= 15 days/month. Medication overuse risk: combination analgesics or triptans on >= 10 days/month, simple analgesics on >= 15 days/month, for > 3 months.
- IBD flare signs: stool count up, blood, night-time stools, pain, missed school, low energy.
- Adherence is self-reported in this app. Never describe it as verified.

## Persona specs

### Agent A
**p02-sara**, 16 F, 165 cm, Asthma. Treatment NOT TAKEN. Dulera 100/5 2 puffs twice daily (08:00, 20:00) + albuterol as needed. Controller adherence falls: prior30 about 65 to 75%, last30 about 30 to 40%, evening and weekend doses missed most. Rescue use rises (prior30 about 4 days, last30 about 12 to 16 days). Symptom days rise, night waking 1 to 2x/week in last 30, 1 school day missed. FEV1 best about 90% early, about 76 to 80% last 2 weeks. Spirometry sessions get less frequent. Current zone Yellow. Logs drop a bit but she keeps using the symptom tracker. Pred fev1 3.25, fvc 3.70, pef 6.6.

**p03-alex**, 15 M, 172 cm, Asthma. Treatment NOT WORKING. Dulera 200/5 2 puffs twice daily (07:15, 21:00) about 95 to 98% on time, montelukast 10 mg nightly (21:00) about 95%. From mid September (school + colds): symptom days rise, rescue 3 to 4 days/week in last 30, night waking about 2x/week, 2 school days missed. FEV1 about 88% in August falling to about 72 to 76% last 2 weeks, FEV1/FVC low (use ratio_cap about 0.72 in later sessions). Triggers: Being sick, Cold air. Zone Yellow (was Red briefly late October, now Yellow). Pred fev1 3.85, fvc 4.45, pef 8.0. Flag should suggest step-up / technique check, and note adherence is self-reported.

**p04-grace**, 13 F, 155 cm, Asthma. DISCORDANT + BAD SPIROMETRY. Feeling "Great"/"Good" on about 80 to 85% of days, yet Wheezing / Shortness Of Breath on about 40% of days. Most blows rejected (reject_prob about 0.55 to 0.65, several sessions grade D or F, many coaching messages). Accepted FEV1 about 70 to 78%. Qvar 80 mcg 2 puffs twice daily about 70 to 80%. Rescue 2 to 3 days/week. Zone Yellow. Pred fev1 2.85, fvc 3.20, pef 5.8. Flags: feeling vs symptoms mismatch, unreliable spirometry (coach technique), poor control.

### Agent B
**p05-felix**, 15 M, 170 cm, Asthma. EXACERBATION + RECOVERY. Symbicort 160/4.5 2 puffs twice daily about 88%, albuterol as needed. Stable Green until a cold starts 2026-10-12. Oct 14 to 19: rescue several times a day (4 to 8 puffs), lowest FEV1 about 55 to 60% on Oct 16, night waking, school missed Oct 15, 16, 19, 20 (weekdays only). Add prednisolone 40 mg daily, start_date 2026-10-16, 5 days, taken Oct 16 to 20, then the med is archived (archived=True; note the metrics treat archived meds as recorded doses only). Bursts: during the flare, 3 to 5 submissions on some days, answers changing within minutes, one at 3 am. Recovery to about 88 to 92% by Nov 1. Current zone Green, plan updated 2026-11-02. Note: the record only stores the CURRENT zone, so the flare must be visible from rescue use, symptoms, spirometry. Pred fev1 3.75, fvc 4.35, pef 7.8.

**p06-nora**, 13 F, 152 cm, Asthma. NEW PATIENT. enrolled_date 2026-11-02. Data only Nov 2 to 5. Arnuity Ellipta 100 mcg 1 inhalation daily (08:00), took 3 of 4. Albuterol as needed, unused. Day 1: exploring app, 3 submissions including 1 blank. First spirometry session has 6 blows, most rejected, then improves. FEV1 about 90%. Zone Green set 2026-11-02. Flags: insufficient data, view should not show trends. Pred fev1 2.80, fvc 3.15, pef 5.7.

**p13-rosa**, 14 F, 158 cm, Asthma + IBD (Crohn's). TWO SPECIALISTS. Asthma well controlled: fluticasone HFA 110 mcg 2 puffs twice daily about 85%, albuterol as needed (about 2 days in 90), FEV1 about 93% stable, 1 to 2 sessions/week, Green. IBD: adalimumab 40 mg every 2 weeks (Weekly, interval 2, start 2026-08-12), one dose 4 days late in September and the 2026-10-21 dose missed entirely. Iron supplement daily about 50%. IBD symptoms creep up after the missed dose: stool count 2 to 4-5, pain 2 to 4-5, energy down, urgency, no blood. She logs asthma on about 85% of days but IBD on only about 60%. Flags for GI only. Include specialistViews for Pulmonologist, Gastroenterologist, Primary care.

### Agent C
**p07-priya**, 16 F, IBD (ulcerative colitis). REMISSION, GI BASELINE. Mesalamine 1.2 g 4 tablets once daily (08:00) about 92%, vitamin D daily about 85%. Stool 1 to 2/day Normal, no blood, pain 1 to 2, energy 7 to 8, rare urgency. Stomach bug 2026-09-20 to 21 (stool 5, Watery, no blood, Nausea) that resolves. Logs about 80% of days. No device, no action plan. Non-flag: the 2-day stomach bug.

**p08-isaac**, 16 M, IBD (Crohn's). ACTIVE FLARE despite adherence. Azathioprine 100 mg daily (08:00) about 92%, adalimumab 40 mg every 2 weeks on schedule. Flare from about 2026-10-10: stool count 2 up to 6 to 8, Mushy/Watery, blood "A little" rising to some "A lot" in last week, pain 6 to 8, night waking 4+ nights/week, energy about 3, school missed about 6 weekdays in last 30, Low appetite, Joint pain. Feeling Bad/Awful. Logs more often in the last week (2 to 3 per day). Flags: active worsening flare with blood and night stools, high severity.

**p09-finn**, 17 M, IBD (Crohn's). DISENGAGING. Methotrexate 15 mg weekly on Saturdays (Weekly, start 2026-08-08 is a Saturday) + folic acid 1 mg daily. Weeks 1 to 4: logs about 90%, adherence about 95%. Weeks 5 to 8: logs about 50%, several blank and empty_values submissions, burst days with 3 to 5 submissions within minutes and answers changing. After that almost nothing: last non-blank submission 2026-10-19, one blank 2026-10-27, last dose 2026-10-24. Symptoms when reported creep mildly (stool 3 to 4, pain 3 to 4). Tracker reminder enabled=False (he turned it off). Badges early only. Flags: disengagement, status unknown, do not read "no data" as "no symptoms".

### Agent D
**p10-maya**, 15 F, Migraine. MEDICATION OVERUSE. Excedrin Migraine 2 tablets as needed, ibuprofen 400 mg as needed, riboflavin 400 mg daily (08:00) about 55 to 65%. Headache days about 13 in prior30, about 17 in last30 (chronic range). Excedrin on about 11 to 14 days per 30 throughout (overuse pattern), ibuprofen about 4 to 6 days. Severity mostly 4 to 7, a few 8. Sleep about 6 to 6.5 h on school nights. Triggers Poor sleep, Screens, Stress, some Period. 3 school days missed in last 30. Submits most days, including no-headache days. Flags: chronic migraine frequency, acute medication overuse, low preventive adherence, short sleep.

**p11-ben**, 14 M, Migraine. IMPROVING on preventive. Amitriptyline 10 mg nightly (21:00), start_date 2026-09-01, about 90%. Rizatriptan 10 mg as needed, ibuprofen 400 mg as needed. Headache days about 9 to 10 in the 24 days before Sep 1, falling to about 3 to 5 in last30. Severity falling. Sleep 8 to 9 h after starting. Flags: none bad, an improvement finding (continue preventive). Show before/after clearly in keyFindings.

**p12-dev**, 17 M, 178 cm, Asthma + Migraine. TWO SPECIALISTS + DUPLICATE MED. Asthma: Dulera 200/5 2 puffs twice daily about 80%, albuterol about 1 day/week, FEV1 about 88% stable, sessions about weekly, Green. Migraine: about 5 to 7 headache days/month, cluster during midterms (Oct 12 to 23). Two Excedrin records: index 0 "Excedrin" archived=True and a newer active "Excedrin" (same name, different id). Doses in August logged against the archived id, later ones against the active id, plus 2 stray doses against the archived id in October (stale reminder). He only submits the migraine tracker on headache days, so missing migraine days are ambiguous. Cross-specialty note in ground truth: propranolol (a common migraine preventive) is generally avoided in asthma. Include specialistViews for Pulmonologist, Neurologist, Primary care. Pred fev1 4.10, fvc 4.85, pef 8.6.
