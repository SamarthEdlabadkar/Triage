# SMART@Home synthetic test dataset

13 fake patients, 90 days each (2026-08-08 to 2026-11-05), visit date 2026-11-06.
Format is inferred from section 3 of the hackathon brief. All data is made up.

## Folders
```
trackers/       question definitions (asthma, ibd, migraine). Question text lives here, not in patients
patients/       one nested JSON per patient (the Cosmos-style document)
ground_truth/   what a good clinician view should surface, plus reference metrics
generators/     one script per persona (fixed seeds, reproducible)
lib/            shared builder, metrics, validator
AGENT_GUIDE.md  full persona specs used to generate the data
```

## Personas
| id | Who | Condition | Scenario | Flags |
|---|---|---|---|---|
| p01-sam | 14 M | Asthma | Stable, the "nothing to see" patient | 0 |
| p02-sara | 16 F | Asthma | Skipping controller, getting worse (not taken) | 5 |
| p03-alex | 15 M | Asthma | Adherent but worsening (not working) | 4 |
| p04-grace | 13 F | Asthma | Says "Great" while wheezing, bad spirometry technique | 3 |
| p05-felix | 15 M | Asthma | Cold, exacerbation, steroid burst, recovered | 3 |
| p06-nora | 13 F | Asthma | New patient, 4 days of data | 3 |
| p07-priya | 16 F | IBD (UC) | Remission, GI baseline | 0 |
| p08-isaac | 16 M | IBD (Crohn's) | Active flare with blood despite adherence | 5 |
| p09-finn | 17 M | IBD (Crohn's) | Disengaging, no real data since Oct 19 | 4 |
| p10-maya | 15 F | Migraine | Chronic frequency, acute med overuse | 4 |
| p11-ben | 14 M | Migraine | Improving on new preventive | 1 |
| p12-dev | 17 M | Asthma + Migraine | Duplicate Excedrin records, two specialists | 4 |
| p13-rosa | 14 F | Asthma + IBD | Missed biologic, GI issue only | 4 |

## Patient document (inferred schema)
```
patient
├── id, personaId, studyId, displayName, age, sex, heightCm, enrolledDate
├── assignedTrackers[]   {trackerId, trackerName, assignedDate}
├── medications[]        {id (uuid), name, relatedCondition, howOften, dosage.timing, startDate, archived, index}
├── reminders[]          {type Medication|Tracker, medicationId|trackerId, time, enabled}
├── medicalDevices[]     Spirobank, asthma patients only
│   └── baselineReadings[]  {sessionId, readingDate, accepted, fvcPlusResults{fev1, fvc, fev1FvcRatio, pef, ...}, qualityReport}
├── asthmaTreatmentPlan  {status Green|Yellow|Red, lastUpdated, expiration, retestTime} or null
├── dailyLogs[]          {day, allMedicationsAdministered, trackerResponses[], medicationAdministrations[]}
│   ├── trackerResponses[]          {trackerId, submittedAt, responses[] {questionId, value}}
│   └── medicationAdministrations[] {medicationId, name, administeredAt, value}
├── earnedTrackerBadges[]
└── earnedMedicationBadges[]
```
Units: fev1 and fvc in liters, pef in **liters per second** (multiply by 60 for L/min), ratio and percent predicted as 0 to 100. Timestamps are UTC; group by day in America/New_York.

## Mess you have to handle (on purpose, matches the brief)
- `value` is always a string. Checkboxes are JSON text like `["Coughing","Tight Chest"]`.
- Multiple submissions per day, answers can change within minutes.
- Blank submissions (no responses, or every value `""`). Spirometer check-ins are often blank even when blows exist.
- Asthma "None of these " has a trailing space (copied from the brief's screenshot).
- Medications linked by random IDs. Dev has two records both named "Excedrin".
- Per-blow `accepted` often disagrees with session `qualityCode`. Coaching messages are run-together text.
- Only the **current** action plan zone is stored. Zone history must be inferred.
- `allMedicationsAdministered` is true only when every scheduled dose that day was marked.
- Adherence is self-reported. Do not present it as verified.
- Archived and as-needed meds have no adherence, only days used.

## Reference aggregation rules (used in ground_truth computedMetrics)
One reasonable choice. Your view can pick others.
- One answer per day: last non-blank submission of the day
- Checkboxes: union across the day. Yes/no: any Yes. Numbers and 1 to 10 scales: daily max
- Windows: last30 (Oct 7 to Nov 5), prior30 (Sep 7 to Oct 6), full90
- Adherence: scheduled doses taken / due. "Every 2 weeks" doses count if within 2 days of the due date (Rosa's 4-day-late dose counts as missed)
- FEV1 trend: average best accepted FEV1 % predicted, first 14 days of readings vs last 14

## Using ground truth
Each `ground_truth/<id>.json` has `clinician30s` (the one-line takeaway), `expectedFlags` (with severity, which specialist cares, and numeric evidence), `expectedNonFlags` (things that look odd but should not alarm), and `computedMetrics`. Good test: does your view surface every expected flag and none of the non-flags?

## Regenerate
```
python3 lib/make_trackers.py
for f in generators/p*.py; do python3 "$f"; done
python3 lib/validate.py
```

## Caveats
- Field names are inferred from the brief, not the real SMART@Home schema.
- Only the asthma tracker is described in the brief. IBD and migraine questions are invented using the brief's question types.
