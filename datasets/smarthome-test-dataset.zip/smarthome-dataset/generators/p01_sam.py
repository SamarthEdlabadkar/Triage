import sys
from datetime import date
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "lib"))
from smarthome import PatientBuilder, days, WINDOW_START  # noqa: E402

b = PatientBuilder("p01-sam", "Sam R.", 14, "M", seed=101, height_cm=165, dob="2012-05-14")
r = b.rng
b.assign_tracker("asthma")
b.add_tracker_reminder("asthma", "19:30")
ics = b.add_medication("Qvar RediHaler 80 mcg", "Asthma", "Daily", "Inhaler", 2, "puffs", times=["07:30", "20:00"])
rescue = b.add_medication("Albuterol HFA", "Asthma", "As Needed", "Inhaler", 2, "puffs")
b.add_spirobank()
pred = {"fev1": 3.30, "fvc": 3.82, "pef": 7.2}

for d in days():
    weekend = d.weekday() >= 5
    if r.random() < (0.93 if not weekend else 0.85):
        b.take_dose(ics, d, (7 if not weekend else 9, r.randint(20, 55)))
    if r.random() < 0.9:
        b.take_dose(ics, d, (20, r.randint(0, 50)))

    ragweed = date(2026, 9, 1) <= d <= date(2026, 9, 14)
    if r.random() < 0.86:
        sym = ["None of these "]
        if ragweed and r.random() < 0.35:
            sym = ["Coughing"]
        elif r.random() < 0.04:
            sym = ["Coughing"]
        feeling = r.choices(["Great", "Good", "Okay"], [0.6, 0.33, 0.07])[0]
        if sym != ["None of these "] and feeling == "Great":
            feeling = "Good"
        trig = ["Pollen"] if ragweed and r.random() < 0.5 else (["Exercise"] if r.random() < 0.2 else ["None of these"])
        b.submit("asthma", d, (19, r.randint(30, 59)) if r.random() < 0.7 else (21, r.randint(0, 45)), {
            "feeling": feeling,
            "symptoms": sym,
            "night_waking": False,
            "school_missed": False,
            "triggers": trig if r.random() < 0.8 else None,
        })
        if r.random() < 0.05:
            b.submit("asthma", d, (22, r.randint(0, 30)), {"feeling": feeling})

    if d.weekday() in (0, 3) or (d.weekday() == 5 and r.random() < 0.4):
        if r.random() < 0.85:
            b.spirometry_session(d, (19, r.randint(5, 25)), pred, r.gauss(0.96, 0.025), n_blows=r.choice([3, 3, 4]),
                                 reject_prob=0.12, link_to_tracker=True)

for d in [date(2026, 9, 6), date(2026, 10, 17)]:
    b.take_dose(rescue, d, (10, 15), value=2)

b.set_action_plan("Green", "2026-11-04T23:41:12.118Z", "2027-03-01", None)

b.save({
    "name": "Sam",
    "age": 14,
    "conditions": ["Asthma"],
    "viewers": ["Pulmonologist", "Primary care", "Nurse"],
    "scenario": "Well controlled asthma. Takes controller about 90% of the time, rescue inhaler twice in 90 days, lung function steady near 96% predicted. Mild cough during early September ragweed season.",
    "clinician30s": "Stable. Green zone, high adherence, normal steady FEV1, rare symptoms. No change needed.",
    "expectedFlags": [],
    "expectedNonFlags": [
        "Brief early-September cough should not be flagged as worsening (seasonal, resolved).",
        "Two rescue inhaler uses in 90 days is normal.",
    ],
    "keyFindings": {
        "controllerAdherence": "about 90%",
        "rescueUse": "2 days in 90",
        "fev1Trend": "flat, about 96% predicted",
        "symptomDays": "low, clustered in early September",
        "zone": "Green",
    },
    "injectedQuirks": [
        "Occasional second evening submission with only the feeling answer.",
        "Spirometer question value is usually empty string even when a session exists.",
        "Some sessions have a rejected blow, so sessionGrade varies.",
    ],
})
print("p01-sam done")
