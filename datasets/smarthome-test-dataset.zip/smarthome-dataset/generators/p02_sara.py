import copy
import sys
from datetime import date, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "lib"))
from smarthome import PatientBuilder, days, WINDOW_START, WINDOW_END  # noqa: E402
from metrics import compute_metrics  # noqa: E402

LAST30 = WINDOW_END - timedelta(days=29)    # 2026-10-07
PRIOR30 = WINDOW_END - timedelta(days=59)   # 2026-09-07

b = PatientBuilder("p02-sara", "Sara K.", 16, "F", seed=202, height_cm=165, dob="2010-03-22")
r = b.rng
b.assign_tracker("asthma")
b.add_tracker_reminder("asthma", "20:30")
ctl = b.add_medication("Dulera 100/5 mcg", "Asthma", "Daily", "Inhaler", 2, "puffs", times=["08:00", "20:00"])
rescue = b.add_medication("Albuterol HFA", "Asthma", "As Needed", "Inhaler", 2, "puffs")
b.add_spirobank()
pred = {"fev1": 3.25, "fvc": 3.70, "pef": 6.6}


def phase(d):
    return 0 if d < PRIOR30 else (1 if d < LAST30 else 2)


def wsample(pool, weights, k):
    pool, weights, out = list(pool), list(weights), []
    for _ in range(k):
        x = r.choices(range(len(pool)), weights)[0]
        out.append(pool.pop(x))
        weights.pop(x)
    return set(out)


all_days = list(days())
by_phase = {p: [d for d in all_days if phase(d) == p] for p in (0, 1, 2)}

# Rescue days: rare early, rising, then clustered late.
rescue_days = wsample(by_phase[0], [1] * 30, 2)
rescue_days |= wsample(by_phase[1], [1 + i / 10 for i in range(30)], 4)
rescue_days |= wsample(by_phase[2], [1 + i / 6 for i in range(30)], 14)
# Night waking: about 1.5x/week in last30, mostly on rescue days. One in prior30.
night_days = wsample(sorted(d for d in rescue_days if phase(d) == 2), [1] * 14, 6)
night_days |= wsample(sorted(d for d in rescue_days if phase(d) == 1), [1] * 4, 1)
school_day = max(d for d in night_days if d.weekday() < 5 and phase(d) == 2)
# Extra symptom days (no rescue).
extra_sym = wsample([d for d in by_phase[0] if d not in rescue_days], [1] * 28, 3)
extra_sym |= wsample([d for d in by_phase[1] if d not in rescue_days], [1] * 26, 5)
extra_sym |= wsample([d for d in by_phase[2] if d not in rescue_days], [1] * 16, 5)
sym_days = rescue_days | extra_sym

# Controller adherence: exact doses taken per 30-day block; which slots are missed is weighted
# toward evenings and weekends. Miss weights: (weekday am, weekday pm, weekend am, weekend pm)
TAKE = {0: 52, 1: 42, 2: 21}   # of 60 doses -> about 87%, 70%, 35%
MISS_W = (0.6, 2.5, 2.0, 4.0)
taken_slots = set()
for p in (0, 1, 2):
    slots = [(d, s) for d in by_phase[p] for s in ("am", "pm")]
    w = [MISS_W[(2 if d.weekday() >= 5 else 0) + (1 if s == "pm" else 0)] for d, s in slots]
    missed = wsample(slots, w, len(slots) - TAKE[p])
    taken_slots |= set(slots) - missed
LOG_P = {0: 0.9, 1: 0.86, 2: 0.45}


def fev1_target(d):
    # ~0.885 early, slow drift down, faster fall in last 30 days
    pts = [(WINDOW_START, 0.9), (PRIOR30, 0.875), (LAST30, 0.83), (date(2026, 10, 22), 0.77), (WINDOW_END, 0.76)]
    for (a, va), (bb, vb) in zip(pts, pts[1:]):
        if a <= d <= bb:
            return va + (vb - va) * (d - a).days / max(1, (bb - a).days)
    return pts[-1][1]


spiro_days = set()
for d in all_days:
    p = phase(d)
    if p == 0 and (d.weekday() in (0, 3) and r.random() < 0.9):
        spiro_days.add(d)
    elif p == 1 and d.weekday() == 3 and r.random() < 0.85:
        spiro_days.add(d)
spiro_days |= {date(2026, 10, 11), date(2026, 10, 20), date(2026, 10, 26), date(2026, 10, 30), date(2026, 11, 3)}

for d in all_days:
    p = phase(d)
    weekend = d.weekday() >= 5
    if (d, "am") in taken_slots:
        b.take_dose(ctl, d, (10, r.randint(0, 50)) if weekend else (7, r.randint(35, 59)))
    if (d, "pm") in taken_slots:
        b.take_dose(ctl, d, (20 if r.random() < 0.6 else 21, r.randint(0, 55)))

    if d in rescue_days:
        if d in night_days:
            b.take_dose(rescue, d, (r.choice([2, 3, 4]), r.randint(0, 50)), value=2)
            if r.random() < 0.4:
                b.take_dose(rescue, d, (r.randint(15, 18), r.randint(0, 59)), value=2)
        else:
            b.take_dose(rescue, d, (r.randint(14, 21), r.randint(0, 59)), value=r.choice([2, 2, 2, 4]))

    event = d in sym_days or d in night_days
    lp = LOG_P[p] * (0.85 if weekend else 1.0)
    if d in night_days or d == school_day or (event and r.random() < (0.8 if p == 2 else 0.95)) or (not event and r.random() < lp):
        if d in sym_days:
            k = 2 if (p == 2 and r.random() < 0.5) else 1
            sym = r.sample(["Coughing", "Wheezing", "Tight Chest", "Shortness Of Breath"], k)
            if d in night_days and r.random() < 0.4:
                sym.append("Activity limitations")
            feeling = r.choices(["Good", "Okay", "Bad"], [0.15, 0.55, 0.3] if p == 2 else [0.35, 0.55, 0.1])[0]
        else:
            sym = ["None of these "]
            feeling = r.choices(["Great", "Good", "Okay"], [0.45, 0.45, 0.1] if p < 2 else [0.25, 0.55, 0.2])[0]
        if d < date(2026, 9, 20) and r.random() < 0.15:
            trig = ["Pollen"]
        elif p == 2 and d in sym_days and r.random() < 0.45:
            trig = ["Cold air"] if r.random() < 0.6 else ["Exercise"]
        elif r.random() < 0.15:
            trig = ["Exercise"]
        else:
            trig = ["None of these"]
        t = (r.randint(20, 22), r.randint(0, 59)) if not weekend else (r.randint(13, 22), r.randint(0, 59))
        b.submit("asthma", d, t, {
            "feeling": feeling,
            "symptoms": sym,
            "night_waking": d in night_days,
            "school_missed": d == school_day,
            "triggers": trig if r.random() < 0.85 else None,
        })
        if r.random() < 0.06:  # quick second submission, feeling only
            b.submit("asthma", d, (min(23, t[0] + 1), r.randint(0, 59)), {"feeling": feeling})
    elif r.random() < 0.04:
        b.submit("asthma", d, (r.randint(19, 22), r.randint(0, 59)), blank=True)

    if d in spiro_days:
        pct = fev1_target(d) + r.gauss(0, 0.012)
        b.spirometry_session(d, (19, r.randint(0, 30)), pred, pct, n_blows=r.choice([3, 3, 4]),
                             reject_prob=0.15, link_to_tracker=True)

b.set_action_plan("Yellow", "2026-10-28T00:14:37.512Z", "2027-04-27", "2026-11-07T00:00:00.000Z")

# Preview metrics so ground-truth text quotes the real numbers.
m = compute_metrics(copy.deepcopy(b).build(), b.trackers)
tw = m["trackers"][0]["windows"]
meds = {x["name"]: x for x in m["medications"]["medications"]}
dul, alb = meds["Dulera 100/5 mcg"]["windows"], meds["Albuterol HFA"]["windows"]
sp = m["spirometry"]
Q = lambda w: tw[w]["questions"]  # noqa: E731
pr, la = Q("prior30"), Q("last30")
fmt = lambda x: f"{x:.1f}"  # noqa: E731

b.save({
    "name": "Sara",
    "age": 16,
    "conditions": ["Asthma"],
    "viewers": ["Pulmonologist", "Primary care", "Nurse"],
    "scenario": "Asthma getting worse because she has stopped taking her controller regularly. Dulera use dropped by about half, mostly missed evening and weekend doses. Rescue inhaler use, symptoms and night waking went up and lung function slipped from about 90% to under 80% predicted.",
    "clinician30s": (
        f"Not well controlled because treatment is not being taken. Self-reported Dulera adherence fell from {dul['prior30']['adherencePct']}% to "
        f"{dul['last30']['adherencePct']}% (prior30 vs last30). Rescue days {alb['prior30']['daysUsed']} to {alb['last30']['daysUsed']}, "
        f"night waking {la['night_waking']['yesDays']} nights in last 30, FEV1 {fmt(sp['first14dAvgBestFev1Pct'])}% to {fmt(sp['last14dAvgBestFev1Pct'])}% predicted. "
        "Yellow zone. Address adherence (evening and weekend doses) before stepping up therapy."
    ),
    "expectedFlags": [
        {"flag": "controller_adherence_decline", "severity": "high", "for": ["Pulmonologist", "Primary care", "Nurse"],
         "evidence": f"Dulera self-reported adherence {dul['prior30']['adherencePct']}% prior30 -> {dul['last30']['adherencePct']}% last30 ({dul['last30']['dosesTaken']} of {dul['last30']['expectedDoses']} doses); full90 {dul['full90']['adherencePct']}%. Missed doses are mostly evening and weekend."},
        {"flag": "rising_rescue_use", "severity": "high", "for": ["Pulmonologist", "Primary care"],
         "evidence": f"Albuterol used on {alb['prior30']['daysUsed']} days prior30 vs {alb['last30']['daysUsed']} days last30 ({alb['last30']['totalUnits']:.0f} puffs), above 2 days/week."},
        {"flag": "not_well_controlled_symptoms", "severity": "medium", "for": ["Pulmonologist", "Primary care"],
         "evidence": f"Symptom days {pr['symptoms']['daysWithAny']} prior30 -> {la['symptoms']['daysWithAny']} last30; night waking {pr['night_waking']['yesDays']} -> {la['night_waking']['yesDays']} nights (about {la['night_waking']['yesDays'] / 30 * 7:.1f}/week); school missed {la['school_missed']['yesDays']} day last30."},
        {"flag": "fev1_decline", "severity": "medium", "for": ["Pulmonologist"],
         "evidence": f"Best FEV1 first 14 days avg {fmt(sp['first14dAvgBestFev1Pct'])}% vs last 14 days avg {fmt(sp['last14dAvgBestFev1Pct'])}% predicted ({sp['changeFev1PctPoints']} points); lowest last30 {sp['minBestFev1PctLast30']}%. Current zone Yellow."},
        {"flag": "fewer_spirometry_sessions", "severity": "low", "for": ["Pulmonologist", "Nurse"],
         "evidence": f"{sp['sessions']} sessions in 90 days but only {sp['sessionsLast30']} in last30 (about twice weekly in August)."},
    ],
    "expectedNonFlags": [
        "Do not recommend a step-up as the first move: the drop in control lines up with missed controller doses, not treatment failure.",
        f"Tracker logging only dipped a little ({tw['prior30']['daysWithAnswers']} -> {tw['last30']['daysWithAnswers']} days with answers); she is still engaged with the symptom tracker.",
        "Adherence is self-reported in the app, not verified.",
    ],
    "keyFindings": {
        "controllerAdherence": f"{dul['prior30']['adherencePct']}% prior30 -> {dul['last30']['adherencePct']}% last30 (self-reported)",
        "rescueUse": f"{alb['prior30']['daysUsed']} days prior30 -> {alb['last30']['daysUsed']} days last30",
        "symptomDays": f"{pr['symptoms']['daysWithAny']} prior30 -> {la['symptoms']['daysWithAny']} last30",
        "nightWaking": f"{la['night_waking']['yesDays']} nights last30",
        "schoolMissed": f"{la['school_missed']['yesDays']} day last30",
        "fev1Trend": f"{fmt(sp['first14dAvgBestFev1Pct'])}% first 14d -> {fmt(sp['last14dAvgBestFev1Pct'])}% last 14d",
        "spirometrySessions": f"{sp['sessions']} total, {sp['sessionsLast30']} in last30",
        "zone": "Yellow",
    },
    "injectedQuirks": [
        "Missed doses skew to evenings and weekends; weekend morning doses logged late (around 10:00).",
        "Some night-waking days have a 2 to 4 am albuterol dose.",
        "Occasional second evening submission with only the feeling answer, and a few blank submissions.",
        "Spirometer question value is usually empty string even when a session exists.",
    ],
})
print("p02-sara done")
