import copy
import sys
from datetime import date, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "lib"))
from smarthome import PatientBuilder, days, WINDOW_START, WINDOW_END  # noqa: E402
from metrics import compute_metrics  # noqa: E402

LAST30 = WINDOW_END - timedelta(days=29)    # 2026-10-07
PRIOR30 = WINDOW_END - timedelta(days=59)   # 2026-09-07
WORSE_FROM = date(2026, 9, 15)              # school + first cold
COLD1 = (date(2026, 9, 15), date(2026, 9, 24))
COLD2 = (date(2026, 10, 16), date(2026, 10, 25))
RED_DAYS = {date(2026, 10, 20), date(2026, 10, 21)}   # briefly Red zone
SCHOOL_MISSED = {date(2026, 10, 21), date(2026, 10, 22)}

b = PatientBuilder("p03-alex", "Alex T.", 15, "M", seed=303, height_cm=172, dob="2011-06-02")
r = b.rng
b.assign_tracker("asthma")
b.add_tracker_reminder("asthma", "21:15")
ctl = b.add_medication("Dulera 200/5 mcg", "Asthma", "Daily", "Inhaler", 2, "puffs", times=["07:15", "21:00"])
mont = b.add_medication("Montelukast 10 mg", "Asthma", "Daily", "Pill", 1, "tablet", times=["21:00"])
rescue = b.add_medication("Albuterol HFA", "Asthma", "As Needed", "Inhaler", 2, "puffs")
b.add_spirobank()
pred = {"fev1": 3.85, "fvc": 4.45, "pef": 8.0}


def in_rng(d, rg):
    return rg[0] <= d <= rg[1]


def wsample(pool, weights, k):
    pool, weights, out = list(pool), list(weights), []
    for _ in range(k):
        x = r.choices(range(len(pool)), weights)[0]
        out.append(pool.pop(x))
        weights.pop(x)
    return set(out)


all_days = list(days())
early = [d for d in all_days if d < WORSE_FROM]
mid = [d for d in all_days if WORSE_FROM <= d < LAST30]
late = [d for d in all_days if d >= LAST30]

# Rescue: rare before mid Sept, then rising; 3 to 4 days/week in last30. Colds weigh more.
rescue_days = wsample(early, [1] * len(early), 2)
rescue_days |= wsample(mid, [3 if in_rng(d, COLD1) else 1 for d in mid], 8)
rescue_days |= RED_DAYS | wsample([d for d in late if d not in RED_DAYS],
                                  [3 if in_rng(d, COLD2) else 1 for d in late if d not in RED_DAYS], 13)
# Night waking: about 2x/week in last30, a few in late Sept.
night_days = RED_DAYS | wsample(sorted(d for d in rescue_days if d >= LAST30 and d not in RED_DAYS), [1] * 13, 7)
night_days |= wsample(sorted(d for d in rescue_days if d in mid), [1] * 8, 3)
extra_sym = wsample([d for d in early if d not in rescue_days], [1] * (len(early) - 2), 2)
extra_sym |= wsample([d for d in mid if d not in rescue_days], [1] * (len(mid) - 8), 6)
extra_sym |= wsample([d for d in late if d not in rescue_days], [1] * (30 - 15), 6)
sym_days = rescue_days | extra_sym


def fev1_target(d):
    pts = [(WINDOW_START, 0.875), (WORSE_FROM, 0.86), (LAST30, 0.80), (date(2026, 10, 18), 0.77),
           (date(2026, 10, 20), 0.665), (date(2026, 10, 21), 0.67), (date(2026, 10, 24), 0.75),
           (date(2026, 10, 27), 0.775), (WINDOW_END, 0.77)]
    for (a, va), (bb, vb) in zip(pts, pts[1:]):
        if a <= d <= bb:
            return va + (vb - va) * (d - a).days / max(1, (bb - a).days)
    return pts[-1][1]


# Spirometry about twice a week (Tue/Sat), extra during colds; he is diligent.
spiro_days = {d for d in all_days if d.weekday() in (1, 5) and r.random() < 0.9}
spiro_days |= {date(2026, 9, 19), date(2026, 10, 20), date(2026, 10, 21), date(2026, 10, 23), date(2026, 11, 3), date(2026, 11, 4)}

mont_missed = wsample(all_days, [1] * len(all_days), 5)   # about 94%

for d in all_days:
    weekend = d.weekday() >= 5
    # Controller and montelukast: very high self-reported adherence, on time.
    if r.random() < 0.97:
        b.take_dose(ctl, d, (8, r.randint(15, 59)) if weekend else (7, r.randint(5, 30)))
    eve = r.random() < 0.965
    if eve:
        t = (21, r.randint(0, 25)) if r.random() < 0.8 else (20, r.randint(40, 59))
        b.take_dose(ctl, d, t)
    if d not in mont_missed:
        b.take_dose(mont, d, (21, r.randint(0, 30)))

    if d in rescue_days:
        if d in RED_DAYS:
            for hh in (3, 9, 15, 20):
                b.take_dose(rescue, d, (hh, r.randint(0, 50)), value=4 if hh in (3, 15) else 2)
        elif d in night_days:
            b.take_dose(rescue, d, (r.choice([1, 2, 3, 4]), r.randint(0, 50)), value=2)
            if r.random() < 0.4:
                b.take_dose(rescue, d, (r.randint(15, 18), r.randint(0, 59)), value=2)
        else:
            t = (r.randint(6, 7), r.randint(0, 50)) if (d >= date(2026, 10, 26) and r.random() < 0.5) else (r.randint(15, 20), r.randint(0, 59))
            b.take_dose(rescue, d, t, value=2)

    event = d in sym_days or d in night_days or d in SCHOOL_MISSED
    if event or r.random() < (0.9 if not weekend else 0.75):
        sick = in_rng(d, COLD1) or in_rng(d, COLD2)
        if d in sym_days:
            k = 1 if d < WORSE_FROM else r.choice([1, 2, 2, 3])
            sym = r.sample(["Coughing", "Wheezing", "Tight Chest", "Shortness Of Breath"], k)
            if d in RED_DAYS or (d in night_days and r.random() < 0.35):
                sym.append("Activity limitations")
            if d in RED_DAYS:
                feeling = "Awful" if d == min(RED_DAYS) else "Bad"
            else:
                feeling = r.choices(["Good", "Okay", "Bad"], [0.25, 0.55, 0.2] if d >= LAST30 else [0.4, 0.5, 0.1])[0]
        else:
            sym = ["None of these "]
            feeling = r.choices(["Great", "Good", "Okay"], [0.5, 0.4, 0.1] if d < WORSE_FROM else [0.25, 0.55, 0.2])[0]
        trig = []
        if sick:
            trig.append("Being sick")
        if d >= date(2026, 10, 10) and r.random() < 0.45:
            trig.append("Cold air")
        if not trig and r.random() < 0.2:
            trig.append("Exercise")
        t = (21, r.randint(15, 59)) if r.random() < 0.75 else (22, r.randint(0, 30))
        if weekend:
            t = (r.randint(14, 22), r.randint(0, 59))
        b.submit("asthma", d, t, {
            "feeling": feeling,
            "symptoms": sym,
            "night_waking": d in night_days,
            "school_missed": d in SCHOOL_MISSED,
            "triggers": trig or ["None of these"],
        })
        if d in RED_DAYS:  # anxious repeat check-in later that night
            b.submit("asthma", d, (23, r.randint(0, 40)), {"feeling": "Bad", "symptoms": sym + ["Coughing"] if "Coughing" not in sym else sym})
        elif r.random() < 0.04:
            b.submit("asthma", d, (min(23, t[0] + 1), r.randint(0, 59)), {"feeling": feeling})
    elif r.random() < 0.03:
        b.submit("asthma", d, (21, r.randint(0, 59)), blank=True)

    if d in spiro_days:
        pct = fev1_target(d) + r.gauss(0, 0.01)
        if d >= date(2026, 9, 28):
            # obstructive pattern: FEV1/FVC around 0.70 to 0.72
            fvc_pct = pct * (pred["fev1"] / pred["fvc"]) / 0.715
            b.spirometry_session(d, (21, r.randint(20, 40)), pred, pct, fvc_pct=fvc_pct, n_blows=r.choice([3, 3, 4]),
                                 reject_prob=0.1, link_to_tracker=True, ratio_cap=0.72)
        else:
            b.spirometry_session(d, (21, r.randint(20, 40)), pred, pct, n_blows=r.choice([3, 3, 4]),
                                 reject_prob=0.1, link_to_tracker=True)

b.set_action_plan("Yellow", "2026-10-26T01:52:09.334Z", "2027-04-25", "2026-11-06T22:00:00.000Z")

# Preview metrics so ground-truth text quotes the real numbers.
m = compute_metrics(copy.deepcopy(b).build(), b.trackers)
tw = m["trackers"][0]["windows"]
meds = {x["name"]: x for x in m["medications"]["medications"]}
dul, mon, alb = meds["Dulera 200/5 mcg"]["windows"], meds["Montelukast 10 mg"]["windows"], meds["Albuterol HFA"]["windows"]
sp = m["spirometry"]
pr, la = tw["prior30"]["questions"], tw["last30"]["questions"]
fmt = lambda x: f"{x:.1f}"  # noqa: E731

# Mean FEV1/FVC of best accepted blows in late sessions, for the ratio claim.
doc_preview = copy.deepcopy(b).build()
sess = {}
for bl in doc_preview["medicalDevices"][0]["baselineReadings"]:
    if bl["accepted"]:
        sess.setdefault(bl["sessionId"], []).append(bl)
late_ratios = [max(v, key=lambda x: x["fvcPlusResults"]["fev1"])["fvcPlusResults"]["fev1FvcRatio"]
               for v in sess.values() if v[0]["readingDate"] >= "2026-10-07"]
early_ratios = [max(v, key=lambda x: x["fvcPlusResults"]["fev1"])["fvcPlusResults"]["fev1FvcRatio"]
                for v in sess.values() if v[0]["readingDate"] < "2026-09-07"]
late_ratio = sum(late_ratios) / len(late_ratios)
red_pct = min(max(v, key=lambda x: x["fvcPlusResults"]["fev1"])["fvcPlusResults"]["fev1PercentPredicted"]
              for v in sess.values() if v[0]["readingDate"][:10] in ("2026-10-21", "2026-10-22"))
early_ratio = sum(early_ratios) / len(early_ratios)
cold_air = la["triggers"]["daysByOption"].get("Cold air", 0)
sick = la["triggers"]["daysByOption"].get("Being sick", 0) + pr["triggers"]["daysByOption"].get("Being sick", 0)

b.save({
    "name": "Alex",
    "age": 15,
    "conditions": ["Asthma"],
    "viewers": ["Pulmonologist", "Primary care", "Nurse"],
    "scenario": "Asthma getting worse even though he reports taking his medicine almost perfectly. Since school started and a couple of colds in mid September and mid October, he has more symptoms, uses his rescue inhaler 3 to 4 days a week and wakes at night. Lung function fell from the high 80s to the mid 70s with an obstructive pattern; he dipped into the Red zone briefly in late October and is now Yellow.",
    "clinician30s": (
        f"Treatment not working despite high self-reported adherence (Dulera {dul['last30']['adherencePct']}%, montelukast {mon['last30']['adherencePct']}% last30). "
        f"Rescue {alb['last30']['daysUsed']} days and night waking {la['night_waking']['yesDays']} nights in last30, FEV1 "
        f"{fmt(sp['first14dAvgBestFev1Pct'])}% -> {fmt(sp['last14dAvgBestFev1Pct'])}% predicted, FEV1/FVC about {late_ratio / 100:.2f}. "
        "Check inhaler technique and confirm adherence (self-reported only), then consider stepping up therapy."
    ),
    "expectedFlags": [
        {"flag": "poor_control_despite_adherence", "severity": "high", "for": ["Pulmonologist", "Primary care"],
         "evidence": f"Self-reported Dulera adherence {dul['last30']['adherencePct']}% (on time {dul['last30']['onTimePct']}%), montelukast {mon['last30']['adherencePct']}% in last30, yet albuterol on {alb['last30']['daysUsed']} days last30 (about {alb['last30']['daysUsed'] / 30 * 7:.1f} days/week, up from {alb['prior30']['daysUsed']} prior30) and night waking {la['night_waking']['yesDays']} nights (about {la['night_waking']['yesDays'] / 30 * 7:.1f}/week). Suggest technique check and step-up review. Adherence is self-reported, not verified."},
        {"flag": "fev1_decline_obstructive", "severity": "high", "for": ["Pulmonologist"],
         "evidence": f"Best FEV1 first 14 days avg {fmt(sp['first14dAvgBestFev1Pct'])}% vs last 14 days avg {fmt(sp['last14dAvgBestFev1Pct'])}% predicted ({sp['changeFev1PctPoints']} points); lowest last30 {sp['minBestFev1PctLast30']}%. FEV1/FVC of best blow about {early_ratio:.0f}% in August vs {late_ratio:.0f}% in last30."},
        {"flag": "increasing_symptom_burden", "severity": "medium", "for": ["Pulmonologist", "Primary care", "Nurse"],
         "evidence": f"Symptom days {pr['symptoms']['daysWithAny']} prior30 -> {la['symptoms']['daysWithAny']} last30; school missed {la['school_missed']['yesDays']} days last30; triggers last30 Cold air {cold_air} days, Being sick {la['triggers']['daysByOption'].get('Being sick', 0)} days."},
        {"flag": "recent_red_zone_episode", "severity": "medium", "for": ["Pulmonologist", "Nurse"],
         "evidence": f"Oct 20 to 21: albuterol 4 times a day (12 puffs/day), feeling Awful/Bad, night waking, school missed Oct 21; best FEV1 those days as low as {red_pct:.1f}% predicted (lowest of last30 is {sp['minBestFev1PctLast30']}%). Record only stores current zone (Yellow), so the Red episode is visible only through these data."},
    ],
    "expectedNonFlags": [
        "Do not flag non-adherence: self-reported controller and montelukast adherence are both above 90%.",
        "Do not describe adherence as verified; it is self-reported in the app.",
        "Viral colds in mid September and mid October are triggers, not the whole story: symptoms and FEV1 stay down between colds.",
    ],
    "keyFindings": {
        "controllerAdherence": f"Dulera {dul['full90']['adherencePct']}% full90, {dul['last30']['adherencePct']}% last30 (self-reported, on time {dul['last30']['onTimePct']}%)",
        "montelukastAdherence": f"{mon['full90']['adherencePct']}% full90",
        "rescueUse": f"{alb['prior30']['daysUsed']} days prior30 -> {alb['last30']['daysUsed']} days last30",
        "nightWaking": f"{pr['night_waking']['yesDays']} prior30 -> {la['night_waking']['yesDays']} last30",
        "symptomDays": f"{pr['symptoms']['daysWithAny']} prior30 -> {la['symptoms']['daysWithAny']} last30",
        "schoolMissed": f"{la['school_missed']['yesDays']} days last30 (Oct 21, 22)",
        "fev1Trend": f"{fmt(sp['first14dAvgBestFev1Pct'])}% first 14d -> {fmt(sp['last14dAvgBestFev1Pct'])}% last 14d",
        "fev1FvcRatio": f"about {early_ratio:.0f}% August -> {late_ratio:.0f}% last30",
        "triggers": "Being sick, Cold air",
        "zone": "Yellow (briefly Red Oct 20 to 21)",
    },
    "injectedQuirks": [
        "Two submissions on each Red-zone day (a late-night repeat check-in with feeling and symptoms only).",
        "Night-waking days have a 1 to 4 am albuterol dose; late-October mornings sometimes have a pre-school albuterol dose.",
        "Montelukast occasionally logged on a night the evening Dulera dose was missed.",
        "Spirometer question value is usually empty string even when a session exists.",
    ],
})
print("p03-alex done")
