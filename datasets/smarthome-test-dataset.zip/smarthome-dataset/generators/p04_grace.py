import copy
import sys
from collections import Counter
from datetime import date, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "lib"))
from smarthome import PatientBuilder, days, WINDOW_START, WINDOW_END  # noqa: E402
from metrics import compute_metrics  # noqa: E402

LAST30 = WINDOW_END - timedelta(days=29)    # 2026-10-07
PRIOR30 = WINDOW_END - timedelta(days=59)   # 2026-09-07

b = PatientBuilder("p04-grace", "Grace L.", 13, "F", seed=404, height_cm=155, dob="2013-01-17")
r = b.rng
b.assign_tracker("asthma")
b.add_tracker_reminder("asthma", "19:00")
ics = b.add_medication("Qvar RediHaler 80 mcg", "Asthma", "Daily", "Inhaler", 2, "puffs", times=["07:00", "19:30"])
rescue = b.add_medication("Albuterol HFA", "Asthma", "As Needed", "Inhaler", 2, "puffs")
b.add_spirobank()
pred = {"fev1": 2.85, "fvc": 3.20, "pef": 5.8}


def wsample(pool, weights, k):
    pool, weights, out = list(pool), list(weights), []
    for _ in range(k):
        x = r.choices(range(len(pool)), weights)[0]
        out.append(pool.pop(x))
        weights.pop(x)
    return set(out)


all_days = list(days())
blocks = [[d for d in all_days if d < PRIOR30], [d for d in all_days if PRIOR30 <= d < LAST30],
          [d for d in all_days if d >= LAST30]]

# Logged days: about 85% weekdays, fewer weekends.
logged = set()
for blk in blocks:
    logged |= wsample(blk, [1.0 if d.weekday() < 5 else 0.6 for d in blk], 25)
logged_l = sorted(logged)
# Wheezing / Shortness Of Breath on about 40% of logged days; a few more with cough only.
wheeze_days = set()
for blk in blocks:
    lb = [d for d in blk if d in logged]
    wheeze_days |= wsample(lb, [1] * len(lb), 10)
cough_only = wsample([d for d in logged_l if d not in wheeze_days], [1] * (len(logged_l) - len(wheeze_days)), 6)
# Feeling: Great/Good on about 83% of logged days, even on most wheeze days (the discordance).
not_good = set()
for blk in blocks:
    lb = [d for d in blk if d in logged]
    not_good |= wsample(lb, [2.0 if d in wheeze_days else 1.0 for d in lb], 4)
# Rescue: 2 to 3 days/week, mostly on wheeze days.
rescue_days = set()
for blk in blocks:
    rescue_days |= wsample(blk, [4.0 if d in wheeze_days else 1.0 for d in blk], 11)
night_days = set()
for blk in blocks:
    cand = sorted(d for d in blk if d in wheeze_days and d in rescue_days)
    night_days |= wsample(cand, [1] * len(cand), 2)

# Qvar: exact count per 30-day block (about 75%), misses weighted to evenings and weekends.
TAKE = {0: 47, 1: 45, 2: 44}
MISS_W = (0.8, 2.0, 1.6, 3.0)
taken_slots = set()
for i, blk in enumerate(blocks):
    slots = [(d, s) for d in blk for s in ("am", "pm")]
    w = [MISS_W[(2 if d.weekday() >= 5 else 0) + (1 if s == "pm" else 0)] for d, s in slots]
    taken_slots |= set(slots) - wsample(slots, w, len(slots) - TAKE[i])

# Spirometry: about 1.5/week, poor technique -> most blows rejected; she often retries.
spiro_days = {d for d in all_days if (d.weekday() == 2 and r.random() < 0.85) or (d.weekday() == 6 and r.random() < 0.6)}
spiro_days |= {date(2026, 11, 1), date(2026, 11, 4)}

for d in all_days:
    weekend = d.weekday() >= 5
    if (d, "am") in taken_slots:
        b.take_dose(ics, d, (9, r.randint(0, 59)) if weekend else (6, r.randint(45, 59)) if r.random() < 0.4 else (7, r.randint(0, 25)))
    if (d, "pm") in taken_slots:
        b.take_dose(ics, d, (19, r.randint(20, 59)) if r.random() < 0.7 else (20, r.randint(0, 45)))

    if d in rescue_days:
        if d in night_days:
            b.take_dose(rescue, d, (r.choice([1, 2, 3]), r.randint(0, 50)), value=2)
        else:
            # PE / after-school activity
            b.take_dose(rescue, d, (r.randint(11, 18), r.randint(0, 59)), value=r.choice([2, 2, 2, 4]))

    if d in logged:
        if d in wheeze_days:
            sym = r.sample(["Wheezing", "Shortness Of Breath"], r.choice([1, 1, 2]))
            if r.random() < 0.4:
                sym.append(r.choice(["Coughing", "Tight Chest", "Activity limitations"]))
        elif d in cough_only:
            sym = ["Coughing"]
        else:
            sym = ["None of these "]
        if d in not_good:
            feeling = r.choices(["Okay", "Bad"], [0.8, 0.2])[0]
        else:
            feeling = r.choices(["Great", "Good"], [0.55, 0.45])[0]
        if d in rescue_days and d not in night_days and r.random() < 0.6:
            trig = ["Exercise"]
        elif r.random() < 0.12:
            trig = [r.choice(["Pets", "Pollen", "Cold air", "Smoke"])]
        else:
            trig = ["None of these"]
        t = (r.randint(19, 21), r.randint(0, 59)) if not weekend else (r.randint(11, 21), r.randint(0, 59))
        b.submit("asthma", d, t, {
            "feeling": feeling,
            "symptoms": sym,
            "night_waking": d in night_days,
            "school_missed": False,
            "triggers": trig if r.random() < 0.85 else None,
        })
        if r.random() < 0.07:   # double submission, she re-taps the face
            b.submit("asthma", d, (t[0], min(59, t[1] + r.randint(1, 4))), {"feeling": feeling, "symptoms": sym})
    elif r.random() < 0.05:
        b.submit("asthma", d, (r.randint(19, 21), r.randint(0, 59)), blank=True)

    if d in spiro_days:
        pct = 0.735 + r.gauss(0, 0.015)
        b.spirometry_session(d, (19, r.randint(0, 25)), pred, pct, n_blows=r.choice([3, 4, 4, 5]),
                             reject_prob=0.6, link_to_tracker=True)

b.set_action_plan("Yellow", "2026-10-15T23:08:51.774Z", "2027-04-14", None)

# Preview metrics so ground-truth text quotes the real numbers.
pdoc = copy.deepcopy(b).build()
m = compute_metrics(pdoc, b.trackers)
tw = m["trackers"][0]["windows"]
meds = {x["name"]: x for x in m["medications"]["medications"]}
qv, alb = meds["Qvar RediHaler 80 mcg"]["windows"], meds["Albuterol HFA"]["windows"]
sp = m["spirometry"]
f90 = tw["full90"]["questions"]
la = tw["last30"]["questions"]
ndays = tw["full90"]["daysWithAnswers"]
feel = f90["feeling"]["lastAnswerOfDayCounts"]
feel_days = f90["feeling"]["daysAnswered"]
good = feel.get("Great", 0) + feel.get("Good", 0)

# Day-level discordance: days with wheeze/SOB whose last feeling of the day was Great/Good.
tq = {q["metricKey"]: q["questionId"] for q in b.trackers["asthma"]["questions"]}
ws_days = ws_good = 0
for log in pdoc["dailyLogs"]:
    feel_last, syms = None, set()
    for s in log["trackerResponses"]:
        for x in s["responses"]:
            if x["value"] == "":
                continue
            if x["questionId"] == tq["feeling"]:
                feel_last = x["value"]
            if x["questionId"] == tq["symptoms"]:
                syms |= set(__import__("json").loads(x["value"]))
    if syms & {"Wheezing", "Shortness Of Breath"}:
        ws_days += 1
        ws_good += feel_last in ("Great", "Good")
sym_answered = f90["symptoms"]["daysAnswered"]

blows = pdoc["medicalDevices"][0]["baselineReadings"]
rejected = [x for x in blows if not x["accepted"]]
coached = [x for x in blows if x["qualityReport"]["qualityIndications"]]
msg_counts = Counter(mm for x in blows for mm in x["qualityReport"]["qualityIndications"])
top_msgs = ", ".join(k for k, _ in msg_counts.most_common(3))
acc_pcts = [x["fvcPlusResults"]["fev1PercentPredicted"] for x in blows if x["accepted"]]
grades = sp["gradeCounts"]
df = grades.get("D", 0) + grades.get("F", 0)
fmt = lambda x: f"{x:.1f}"  # noqa: E731

b.save({
    "name": "Grace",
    "age": 13,
    "conditions": ["Asthma"],
    "viewers": ["Pulmonologist", "Primary care", "Nurse"],
    "scenario": "Says she feels Great or Good almost every day, but also ticks Wheezing or Shortness Of Breath on about 4 in 10 days and uses her rescue inhaler 2 to 3 days a week. Her home spirometry is mostly rejected blows, so the numbers are shaky, but the accepted blows sit in the 70s. Takes Qvar about three quarters of the time.",
    "clinician30s": (
        f"Not well controlled and under-reporting it. Feels Great/Good on {good}/{feel_days} days yet Wheezing/SOB on {ws_days}/{sym_answered} days "
        f"(and {ws_good} of those still Great/Good). Rescue {alb['last30']['daysUsed']} days last30. Spirometry unreliable: {len(rejected)}/{len(blows)} blows rejected, "
        f"{df} of {sp['sessions']} sessions graded D or F; accepted FEV1 about {fmt(sum(acc_pcts) / len(acc_pcts))}% predicted. Coach blow technique; review control directly with her."
    ),
    "expectedFlags": [
        {"flag": "feeling_symptom_mismatch", "severity": "medium", "for": ["Pulmonologist", "Primary care", "Nurse"],
         "evidence": f"Feeling Great/Good on {good} of {feel_days} answered days ({100 * good / feel_days:.0f}%), but Wheezing or Shortness Of Breath on {ws_days} of {sym_answered} days ({100 * ws_days / sym_answered:.0f}%); on {ws_good} of those {ws_days} days her last feeling answer was still Great/Good."},
        {"flag": "unreliable_spirometry_technique", "severity": "medium", "for": ["Pulmonologist", "Nurse"],
         "evidence": f"{len(rejected)} of {len(blows)} blows rejected ({100 * len(rejected) / len(blows):.0f}%); grades {grades}; {sp['sessionsWithNoAcceptedBlow']} sessions with no accepted blow; {len(coached)} blows carried coaching messages (most common: {top_msgs}). Coach technique before trusting trends."},
        {"flag": "poor_asthma_control", "severity": "high", "for": ["Pulmonologist", "Primary care"],
         "evidence": f"Albuterol on {alb['prior30']['daysUsed']} days prior30 and {alb['last30']['daysUsed']} days last30 ({alb['full90']['daysUsed']} in 90, about {alb['full90']['daysUsed'] / 90 * 7:.1f} days/week); accepted-blow FEV1 avg {fmt(sum(acc_pcts) / len(acc_pcts))}% predicted (first 14d {fmt(sp['first14dAvgBestFev1Pct'])}%, last 14d {fmt(sp['last14dAvgBestFev1Pct'])}%); Qvar self-reported adherence {qv['full90']['adherencePct']}% full90 ({qv['last30']['adherencePct']}% last30). Zone Yellow."},
    ],
    "expectedNonFlags": [
        "Do not read the mostly Great/Good feeling answers as good control.",
        "Do not over-read session-to-session FEV1 swings or the rejected blows' low values: only accepted blows are meaningful, and even those come from poor-quality sessions.",
        f"No school missed and night waking is low ({f90['night_waking']['yesDays']} nights in 90); poor control shows in daytime symptoms and rescue use instead.",
        "Adherence is self-reported in the app, not verified.",
    ],
    "keyFindings": {
        "feelingGreatOrGood": f"{good}/{feel_days} days ({100 * good / feel_days:.0f}%)",
        "wheezeOrSobDays": f"{ws_days}/{sym_answered} days ({100 * ws_days / sym_answered:.0f}%)",
        "rescueUse": f"{alb['prior30']['daysUsed']} days prior30, {alb['last30']['daysUsed']} days last30",
        "controllerAdherence": f"Qvar {qv['prior30']['adherencePct']}% prior30, {qv['last30']['adherencePct']}% last30 (self-reported)",
        "spirometryQuality": f"{len(rejected)}/{len(blows)} blows rejected, grades {grades}",
        "fev1": f"accepted blows avg {fmt(sum(acc_pcts) / len(acc_pcts))}% predicted, flat (first 14d {fmt(sp['first14dAvgBestFev1Pct'])}%, last 14d {fmt(sp['last14dAvgBestFev1Pct'])}%)",
        "zone": "Yellow",
    },
    "injectedQuirks": [
        "Most blows rejected with coaching messages; sessionGrade and qualityCode are session-level and many sessions are D or F.",
        "Some sessions have 4 to 5 blows because she keeps retrying.",
        "Occasional double submission a few minutes apart with the same answers; a few blank submissions.",
        "Spirometer question value is usually empty string even when a session exists.",
    ],
})
print("p04-grace done")
