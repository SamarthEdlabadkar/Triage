import copy
import sys
from datetime import date, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "lib"))
from smarthome import PatientBuilder, days  # noqa: E402
from metrics import compute_metrics  # noqa: E402

D = date
b = PatientBuilder("p05-felix", "Felix M.", 15, "M", seed=505, height_cm=170, dob="2011-03-22")
r = b.rng
b.assign_tracker("asthma")
b.add_tracker_reminder("asthma", "20:00")
ctrl = b.add_medication("Symbicort 160/4.5 mcg", "Asthma", "Daily", "Inhaler", 2, "puffs", times=["07:30", "20:00"])
rescue = b.add_medication("Albuterol HFA", "Asthma", "As Needed", "Inhaler", 2, "puffs")
pred_med = b.add_medication("Prednisolone 40 mg", "Asthma", "Daily", "Pill", 40, "mg", times=["08:00"],
                            archived=True, start_date=D(2026, 10, 16))
b.add_spirobank()
pred = {"fev1": 3.75, "fvc": 4.35, "pef": 7.8}

COLD = D(2026, 10, 12)
PEAK = (D(2026, 10, 14), D(2026, 10, 19))
SCHOOL_MISSED = {D(2026, 10, 15), D(2026, 10, 16), D(2026, 10, 19), D(2026, 10, 20)}
NIGHT_WAKE = {D(2026, 10, 14), D(2026, 10, 15), D(2026, 10, 16), D(2026, 10, 17), D(2026, 10, 18), D(2026, 10, 20)}
BURST_DAYS = {D(2026, 10, 15), D(2026, 10, 16), D(2026, 10, 17), D(2026, 10, 19)}
NONE = "None of these "


def phase(d):
    if d < COLD:
        return "base"
    if d < PEAK[0]:
        return "cold"
    if d <= PEAK[1]:
        return "peak"
    if d <= D(2026, 10, 23):
        return "recover"
    if d <= D(2026, 10, 28):
        return "late"
    return "base"


# ---- controller: about 88%, evenings and weekends missed more, near perfect while sick
for d in days():
    wk = d.weekday() >= 5
    sick = COLD <= d <= D(2026, 10, 24)
    if r.random() < (0.98 if sick else (0.93 if not wk else 0.84)):
        b.take_dose(ctrl, d, (7 if not wk else 9, r.randint(15, 50)))
    if r.random() < (0.97 if sick else (0.87 if not wk else 0.78)):
        b.take_dose(ctrl, d, (20, r.randint(0, 55)) if r.random() < 0.8 else (21, r.randint(10, 50)))

# ---- rescue inhaler
for d, t in [(D(2026, 8, 21), (17, 40)), (D(2026, 9, 18), (16, 55)), (D(2026, 10, 2), (17, 20))]:
    b.take_dose(rescue, d, t, value=2)  # pre-exercise, soccer
rescue_plan = {
    D(2026, 10, 13): [((21, 30), 2)],
    D(2026, 10, 14): [((7, 10), 2), ((13, 5), 2), ((22, 40), 2)],
    D(2026, 10, 15): [((3, 5), 4), ((9, 30), 2), ((18, 45), 2)],
    D(2026, 10, 16): [((2, 50), 2), ((8, 15), 2), ((14, 0), 2), ((21, 50), 2)],
    D(2026, 10, 17): [((4, 20), 2), ((11, 40), 2), ((20, 35), 2)],
    D(2026, 10, 18): [((6, 55), 2), ((15, 10), 2), ((22, 15), 2)],
    D(2026, 10, 19): [((7, 0), 2), ((19, 20), 2)],
    D(2026, 10, 20): [((7, 15), 2), ((20, 5), 2)],
    D(2026, 10, 21): [((19, 30), 2)],
    D(2026, 10, 22): [((7, 5), 2)],
    D(2026, 10, 25): [((16, 30), 2)],
}
for d, uses in rescue_plan.items():
    for t, puffs in uses:
        b.take_dose(rescue, d, t, value=puffs)

# ---- oral steroid burst, Oct 16 to 20 (urgent visit Oct 16, first dose late morning)
for i in range(5):
    d = D(2026, 10, 16) + timedelta(days=i)
    b.take_dose(pred_med, d, (11, 35) if i == 0 else (7, r.randint(30, 59)))


# ---- symptom tracker
def answers(d):
    ph = phase(d)
    if ph == "base":
        sym = [NONE] if r.random() > 0.05 else ["Coughing"]
        feeling = r.choices(["Great", "Good", "Okay"], [0.55, 0.4, 0.05])[0]
        trig = ["Exercise"] if r.random() < 0.25 else ["None of these"]
    elif ph == "cold":
        sym = ["Coughing"] if d == COLD else ["Coughing", "Tight Chest"]
        feeling = "Okay"
        trig = ["Being sick"]
    elif ph == "peak":
        sym = ["Coughing", "Wheezing", "Shortness Of Breath"]
        if r.random() < 0.7:
            sym.append("Tight Chest")
        if r.random() < 0.6:
            sym.append("Activity limitations")
        feeling = r.choice(["Bad", "Bad", "Awful"])
        trig = ["Being sick"] + (["Cold air"] if r.random() < 0.3 else [])
    elif ph == "recover":
        sym = ["Coughing"] + (["Wheezing"] if r.random() < 0.6 else [])
        feeling = r.choice(["Okay", "Okay", "Bad"])
        trig = ["Being sick"]
    else:  # late
        sym = ["Coughing"] if r.random() < 0.5 else [NONE]
        feeling = r.choice(["Good", "Okay", "Good"])
        trig = ["None of these"]
    if sym != [NONE] and feeling == "Great":
        feeling = "Good"
    return {
        "feeling": feeling,
        "symptoms": sym,
        "night_waking": d in NIGHT_WAKE,
        "school_missed": d in SCHOOL_MISSED,
        "triggers": trig if r.random() < 0.85 else None,
    }


blank_days = {D(2026, 8, 19), D(2026, 9, 12), D(2026, 11, 1)}
for d in days():
    wk = d.weekday() >= 5
    ph = phase(d)
    if d in BURST_DAYS:
        a = answers(d)
        if d == D(2026, 10, 15):
            # 3 am wake-up, then morning, then an evening burst with answers changing
            b.submit("asthma", d, (3, 12), {"feeling": "Awful", "symptoms": ["Wheezing", "Shortness Of Breath", "Coughing"],
                                            "night_waking": True})
            b.submit("asthma", d, (7, 48), {"feeling": "Bad", "school_missed": True})
            b.submit("asthma", d, (19, 4), dict(a, feeling="Bad"))
            b.submit("asthma", d, (19, 6), dict(a, feeling="Okay", symptoms=["Coughing", "Wheezing"]))
            b.submit("asthma", d, (19, 9), dict(a, feeling="Bad"))
        else:
            n = r.choice([3, 4])
            h = r.choice([18, 19, 20])
            m0 = r.randint(0, 30)
            for i in range(n):
                ai = dict(a)
                ai["feeling"] = r.choice(["Okay", "Bad", "Awful"])
                if i % 2:
                    ai["symptoms"] = [s for s in a["symptoms"] if s != "Activity limitations"] or a["symptoms"]
                b.submit("asthma", d, (h, m0 + i * r.randint(1, 4)), ai)
        continue
    p = 0.97 if ph in ("cold", "peak", "recover") else (0.82 if not wk else 0.62)
    if r.random() < p:
        t = (19, r.randint(30, 59)) if r.random() < 0.65 else (21, r.randint(0, 50))
        if d in blank_days:
            b.submit("asthma", d, t, blank=True)
            continue
        a = answers(d)
        b.submit("asthma", d, t, a)
        if r.random() < 0.05:
            b.submit("asthma", d, (t[0], min(59, t[1] + r.randint(1, 6))), {"feeling": a["feeling"]})

# ---- spirometry
flare_sessions = {
    D(2026, 10, 13): 0.86, D(2026, 10, 14): 0.71, D(2026, 10, 16): 0.575, D(2026, 10, 18): 0.64,
    D(2026, 10, 20): 0.71, D(2026, 10, 22): 0.77, D(2026, 10, 24): 0.83, D(2026, 10, 27): 0.85,
    D(2026, 10, 29): 0.86, D(2026, 11, 1): 0.875, D(2026, 11, 3): 0.88, D(2026, 11, 5): 0.885,
}
for d in days():
    if d in flare_sessions:
        pct = flare_sessions[d]
        fvc_pct = min(1.0, pct + 0.18) if pct < 0.86 else None
        b.spirometry_session(d, (19, r.randint(5, 25)), pred, pct, fvc_pct=fvc_pct,
                             n_blows=r.choice([3, 4]) if pct > 0.6 else 5,
                             reject_prob=0.3 if pct < 0.7 else 0.12, link_to_tracker=True)
    elif d < COLD and d.weekday() in (0, 3) and r.random() < 0.85:
        b.spirometry_session(d, (19, r.randint(5, 25)), pred, r.gauss(0.935, 0.02), n_blows=r.choice([3, 3, 4]),
                             reject_prob=0.12, link_to_tracker=True)

b.set_action_plan("Green", "2026-11-02T21:14:37.402Z", "2027-05-02", None)


# ---- numbers for the ground-truth text, computed with the same rules as save()
doc = copy.deepcopy(b).build()
M = compute_metrics(doc, b.trackers)
T = M["trackers"][0]["windows"]
meds = {m["name"]: m for m in M["medications"]["medications"]}
C = meds["Symbicort 160/4.5 mcg"]["windows"]
R = meds["Albuterol HFA"]["windows"]
P = meds["Prednisolone 40 mg"]["windows"]
S = M["spirometry"]

sessions = {}
for bl in doc["medicalDevices"][0]["baselineReadings"]:
    sessions.setdefault(bl["sessionId"], []).append(bl)
low = None
for bs in sessions.values():
    acc = [x for x in bs if x["accepted"]]
    if acc:
        best = max(acc, key=lambda x: x["fvcPlusResults"]["fev1"])
        if low is None or best["fvcPlusResults"]["fev1PercentPredicted"] < low["fvcPlusResults"]["fev1PercentPredicted"]:
            low = best
low_pct = round(low["fvcPlusResults"]["fev1PercentPredicted"], 1)
low_ratio = round(low["fvcPlusResults"]["fev1FvcRatio"], 1)
from smarthome import local_day  # noqa: E402
low_day = local_day(low["readingDate"])

peak_puffs = {}
for log in doc["dailyLogs"]:
    d = date.fromisoformat(log["day"])
    if PEAK[0] <= d <= PEAK[1]:
        peak_puffs[d] = sum(float(a["value"]) for a in log["medicationAdministrations"] if a["medicationId"] == rescue)
pp = sorted(peak_puffs.values())
rec_sessions = sorted(
    (local_day(bs[0]["readingDate"]), round(max(x["fvcPlusResults"]["fev1PercentPredicted"] for x in bs if x["accepted"]), 1))
    for bs in sessions.values() if any(x["accepted"] for x in bs))
nov = [p for d, p in rec_sessions if d >= D(2026, 11, 1)]
L, Pr = T["last30"]["questions"], T["prior30"]["questions"]

b.save({
    "name": "Felix",
    "age": 15,
    "conditions": ["Asthma"],
    "viewers": ["Pulmonologist", "Primary care", "Nurse"],
    "scenario": ("Well controlled asthma on Symbicort until a cold starting Oct 12 set off an exacerbation. "
                 f"Oct 14 to 19 he used albuterol {int(pp[0])} to {int(pp[-1])} puffs a day, woke at night, missed 4 school days, "
                 f"and FEV1 fell to {low_pct}% predicted on {low_day}. A 5-day prednisolone burst (Oct 16 to 20) and recovery "
                 f"brought FEV1 back to {min(nov)} to {max(nov)}% in November; he is Green again."),
    "clinician30s": (f"Recovered exacerbation, not current loss of control. Lowest FEV1 {low_pct}% on {low_day} (FEV1/FVC {low_ratio}%), "
                     f"1 oral steroid course, rescue on {R['last30']['daysUsed']} days in last30 vs {R['prior30']['daysUsed']} in prior30, "
                     f"all clustered Oct 13 to 25. Self-reported controller adherence {C['full90']['adherencePct']}%. "
                     "Now Green with FEV1 back near baseline. Review the action plan for colds and count this toward steroid bursts per year."),
    "expectedFlags": [
        {"flag": "recent_asthma_exacerbation", "severity": "high", "for": ["Pulmonologist", "Primary care"],
         "evidence": (f"Albuterol last30 daysUsed {R['last30']['daysUsed']} / totalUnits {R['last30']['totalUnits']:.0f} puffs vs prior30 "
                      f"{R['prior30']['daysUsed']} days / {R['prior30']['totalUnits']:.0f} puffs; {int(pp[0])} to {int(pp[-1])} puffs/day Oct 14 to 19. "
                      f"Night waking yesDays last30 {L['night_waking']['yesDays']} (prior30 {Pr['night_waking']['yesDays']}); "
                      f"school_missed yesDays last30 {L['school_missed']['yesDays']}; symptom daysWithAny last30 {L['symptoms']['daysWithAny']} "
                      f"vs prior30 {Pr['symptoms']['daysWithAny']}. minBestFev1PctLast30 {S['minBestFev1PctLast30']} on {low_day}.")},
        {"flag": "oral_steroid_course", "severity": "medium", "for": ["Pulmonologist", "Primary care"],
         "evidence": (f"Prednisolone 40 mg (archived) daysUsed last30 {P['last30']['daysUsed']}, totalUnits {P['last30']['totalUnits']:.0f}, "
                      "Oct 16 to 20. One systemic steroid burst in 90 days; consider whether controller step-up or a cold-season plan is needed.")},
        {"flag": "fev1_recheck_after_flare", "severity": "low", "for": ["Pulmonologist"],
         "evidence": (f"last14dAvgBestFev1Pct {S['last14dAvgBestFev1Pct']} vs first14dAvgBestFev1Pct {S['first14dAvgBestFev1Pct']} "
                      f"(changeFev1PctPoints {S['changeFev1PctPoints']}); November sessions {min(nov)} to {max(nov)}%, so nearly but "
                      "maybe not fully back to his August baseline. Recheck at visit.")},
    ],
    "expectedNonFlags": [
        "Current zone Green should not be read as 'no recent problem': the record only stores the current zone, the flare is visible in rescue use, symptoms and spirometry.",
        f"Prednisolone shows as archived with only {P['full90']['daysUsed']} recorded days; it was a planned 5-day course, not missed doses.",
        f"Burst days ({T['last30']['multiSubmissionDays']} multi-submission days in last30) with answers changing within minutes and a 3 am entry on Oct 15 reflect a sick teen checking in, not data corruption. Use the last answer of the day.",
        f"Controller adherence {C['last30']['adherencePct']}% in last30 (self-reported) was high during the flare, so poor adherence is not the cause.",
        "Three pre-exercise rescue uses Aug to early Oct are normal for a well controlled athlete.",
    ],
    "keyFindings": {
        "controllerAdherence": f"Symbicort full90 {C['full90']['adherencePct']}% (prior30 {C['prior30']['adherencePct']}%, last30 {C['last30']['adherencePct']}%), self-reported",
        "rescueUse": f"prior30 {R['prior30']['daysUsed']} days, last30 {R['last30']['daysUsed']} days ({R['last30']['totalUnits']:.0f} puffs), peak {int(pp[-1])} puffs/day",
        "fev1Trend": f"about {S['first14dAvgBestFev1Pct']:.0f}% early, low {low_pct}% on {low_day}, {min(nov)} to {max(nov)}% in November",
        "symptomDays": f"prior30 {Pr['symptoms']['daysWithAny']}, last30 {L['symptoms']['daysWithAny']}",
        "nightWaking": f"last30 {L['night_waking']['yesDays']} days, all Oct 14 to 20",
        "schoolMissed": f"{L['school_missed']['yesDays']} days: Oct 15, 16, 19, 20",
        "oralSteroid": "prednisolone 40 mg Oct 16 to 20",
        "zone": "Green (updated 2026-11-02)",
    },
    "injectedQuirks": [
        "Burst submissions Oct 15 to 19: 3 to 5 per day, feeling flips between Okay/Bad/Awful within minutes.",
        "A 3:12 am submission on Oct 15 with only feeling, symptoms and night waking.",
        "Prednisolone is archived=True, so it has no due doses and counts as recorded doses only.",
        "Low-point sessions use 5 blows with more rejections (coughing).",
        "A few blank submissions and one feeling-only second submission.",
    ],
})
print("p05-felix done")
