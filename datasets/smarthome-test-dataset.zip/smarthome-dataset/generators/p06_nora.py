import copy
import sys
from datetime import date
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "lib"))
from smarthome import PatientBuilder, local_day  # noqa: E402
from metrics import compute_metrics  # noqa: E402

D = date
ENROLL = D(2026, 11, 2)
b = PatientBuilder("p06-nora", "Nora K.", 13, "F", seed=606, enrolled_date=ENROLL, height_cm=152, dob="2013-06-09")
r = b.rng
b.assign_tracker("asthma")
b.add_tracker_reminder("asthma", "19:00")
ics = b.add_medication("Arnuity Ellipta 100 mcg", "Asthma", "Daily", "Inhaler", 1, "inhalation", times=["08:00"])
rescue = b.add_medication("Albuterol HFA", "Asthma", "As Needed", "Inhaler", 2, "puffs")
b.add_spirobank()
pred = {"fev1": 2.80, "fvc": 3.15, "pef": 5.7}
NONE = "None of these "

# Controller: 3 of 4 days (missed Wed Nov 4). Day 1 dose taken late morning after the clinic visit.
b.take_dose(ics, D(2026, 11, 2), (11, 52))
b.take_dose(ics, D(2026, 11, 3), (7, 41))
b.take_dose(ics, D(2026, 11, 5), (8, 6))
# Albuterol prescribed, never used.

# Day 1: exploring the app. Blank tap-through, a partial try, then a real evening entry.
b.submit("asthma", D(2026, 11, 2), (15, 21), blank=True)
b.submit("asthma", D(2026, 11, 2), (15, 24), {"feeling": "Good", "symptoms": ["Coughing"]})
b.submit("asthma", D(2026, 11, 2), (19, 37), {"feeling": "Good", "symptoms": [NONE], "night_waking": False,
                                              "school_missed": False, "triggers": ["Pets"]})
b.submit("asthma", D(2026, 11, 3), (19, 48), {"feeling": "Great", "symptoms": [NONE], "night_waking": False,
                                              "school_missed": False, "triggers": ["None of these"]})
b.submit("asthma", D(2026, 11, 4), (21, 15), {"feeling": "Good", "symptoms": [NONE], "night_waking": False,
                                              "school_missed": False})
b.submit("asthma", D(2026, 11, 5), (19, 33), {"feeling": "Good", "symptoms": ["Coughing"], "night_waking": False,
                                              "school_missed": False, "triggers": ["Pets"]})

# Spirometry: first try is 6 blows, most rejected, then technique improves.
b.spirometry_session(D(2026, 11, 2), (15, 30), pred, 0.89, n_blows=6, reject_prob=0.6, link_to_tracker=False)
b.spirometry_session(D(2026, 11, 3), (19, 40), pred, 0.905, n_blows=4, reject_prob=0.3, link_to_tracker=False)
b.spirometry_session(D(2026, 11, 5), (19, 25), pred, 0.90, n_blows=3, reject_prob=0.08, link_to_tracker=False)

b.set_action_plan("Green", "2026-11-02T16:48:09.551Z", "2027-05-02", None)

doc = copy.deepcopy(b).build()
M = compute_metrics(doc, b.trackers)
T = M["trackers"][0]
meds = {m["name"]: m for m in M["medications"]["medications"]}
C = meds["Arnuity Ellipta 100 mcg"]["windows"]
R = meds["Albuterol HFA"]["windows"]
S = M["spirometry"]
sess = {}
for bl in doc["medicalDevices"][0]["baselineReadings"]:
    sess.setdefault(bl["sessionId"], []).append(bl)
rows = sorted((local_day(bs[0]["readingDate"]), len(bs), sum(x["accepted"] for x in bs), bs[0]["qualityReport"]["sessionGrade"],
               round(max((x["fvcPlusResults"]["fev1PercentPredicted"] for x in bs if x["accepted"]), default=0), 1))
              for bs in sess.values())
first, later = rows[0], rows[1:]
sess_txt = "; ".join(f"{d.strftime('%b %-d')} {n} blows, {a} accepted, grade {g}" + (f", best {p}%" if p else "") for d, n, a, g, p in rows)
fev1s = [p for *_, p in rows if p]
n_day1 = sum(len(l["trackerResponses"]) for l in doc["dailyLogs"] if l["day"] == "2026-11-02")

b.save({
    "name": "Nora",
    "age": 13,
    "conditions": ["Asthma"],
    "viewers": ["Pulmonologist", "Primary care", "Nurse"],
    "scenario": ("New patient enrolled Nov 2, so there are only 4 days of data before the visit. She started Arnuity once daily and "
                 "logged 3 of 4 doses, has not needed albuterol, and is learning the spirometer: the first session had mostly "
                 f"rejected blows and later ones were clean. Best FEV1 across sessions was {min(fev1s)} to {max(fev1s)}% predicted."),
    "clinician30s": ("Too little data to judge control or trends: 4 days, Green zone set at enrollment, no rescue use, normal FEV1 "
                     "once technique improved. Use this visit to set a baseline, not to read change."),
    "expectedFlags": [
        {"flag": "insufficient_data", "severity": "low", "for": ["Pulmonologist", "Primary care", "Nurse"],
         "evidence": (f"enrolledDate 2026-11-02; tracker full90 daysWithAnswers {T['windows']['full90']['daysWithAnswers']}, "
                      f"prior30 daysWithAnswers {T['windows']['prior30']['daysWithAnswers']}; Arnuity full90 expectedDoses "
                      f"{C['full90']['expectedDoses']}, prior30 expectedDoses {C['prior30']['expectedDoses']}; "
                      f"spirometry sessions {S['sessions']} ({S['firstSession']} to {S['lastSession']}).")},
        {"flag": "no_trend_view", "severity": "low", "for": ["Pulmonologist", "Primary care"],
         "evidence": (f"first14d and last14d spirometry windows are the same {S['sessions']} sessions "
                      f"(first14dAvgBestFev1Pct {S['first14dAvgBestFev1Pct']}, last14dAvgBestFev1Pct {S['last14dAvgBestFev1Pct']}, "
                      f"changeFev1PctPoints {S['changeFev1PctPoints']}); no prior30 data. The view should show raw values, not trends or % change.")},
        {"flag": "spirometry_technique_learning", "severity": "low", "for": ["Nurse", "Pulmonologist"],
         "evidence": f"{sess_txt}. Coach technique; first-session numbers are not reliable."},
    ],
    "expectedNonFlags": [
        f"Controller adherence {C['full90']['adherencePct']}% ({C['full90']['dosesTaken']} of {C['full90']['expectedDoses']}) is from 4 days only; do not call it low adherence.",
        f"Albuterol daysUsed {R['full90']['daysUsed']} is expected for a new, well patient; it is not missing data.",
        f"{n_day1} submissions on Nov 2 ({T['blankSubmissions']} blank, 1 partial) are her exploring the app on day 1, not distress.",
        f"Nov 2 session shows grade {rows[0][3]} even though {rows[0][1] - rows[0][2]} of {rows[0][1]} blows were rejected (grade only looks at the accepted blows); still treat it as a learning session.",
        "Empty prior30 window and no data before Nov 2 is enrollment timing, not disengagement or a logging gap.",
        f"changeFev1PctPoints {S['changeFev1PctPoints']} is an artifact of overlapping windows, not a real trend.",
    ],
    "keyFindings": {
        "enrolled": "2026-11-02, 4 days of data",
        "controllerAdherence": f"Arnuity {C['full90']['dosesTaken']} of {C['full90']['expectedDoses']} doses (self-reported), Nov 4 missed",
        "rescueUse": f"{R['full90']['daysUsed']} days",
        "fev1": f"{min(fev1s)} to {max(fev1s)}% predicted across {len(fev1s)} usable sessions",
        "spirometryQuality": sess_txt,
        "symptoms": f"daysWithAny {T['windows']['full90']['questions']['symptoms']['daysWithAny']} (mild cough around the cat)",
        "zone": "Green (set 2026-11-02)",
    },
    "injectedQuirks": [
        "Day 1 has a blank submission, a partial one, and a full one, plus the spirometry-linked entry.",
        "First spirometry session is 6 blows with most rejected and coaching messages.",
        "Spirometry sessions are not linked to tracker submissions (she skipped that prompt), keeping day 1 at exactly 3 submissions.",
        "Day 1 controller dose logged late morning (11:52) after the clinic visit, outside the 08:00 slot.",
        "enrolledDate is 2026-11-02, so prior30 and most of full90 are empty by design.",
    ],
})
print("p06-nora done")
