import copy
import sys
from datetime import date
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "lib"))
from smarthome import PatientBuilder, days  # noqa: E402
from metrics import compute_metrics  # noqa: E402

b = PatientBuilder("p07-priya", "Priya S.", 16, "F", seed=707, height_cm=162, dob="2010-03-22")
r = b.rng
b.assign_tracker("ibd")
b.add_tracker_reminder("ibd", "20:00")
mesa = b.add_medication("Mesalamine DR 1.2 g", "IBD", "Daily", "Pill", 4, "tablets", times=["08:00"])
vitd = b.add_medication("Vitamin D3 1000 IU", "IBD", "Daily", "Pill", 1, "tablet", times=["20:00"])

BLANK_DAYS = (date(2026, 8, 29), date(2026, 10, 18))
BUG1, BUG2, BUG3 = date(2026, 9, 20), date(2026, 9, 21), date(2026, 9, 22)


def evening():
    return (r.randint(19, 21), r.randint(0, 59)) if r.random() < 0.85 else (22, r.randint(0, 40))


def baseline_answers():
    sym = ["None of these"]
    x = r.random()
    if x < 0.04:
        sym = ["Urgency"]
    elif x < 0.10:
        sym = ["Tiredness"]
    ans = {
        "feeling": r.choices(["Great", "Good", "Okay"], [0.45, 0.45, 0.10])[0],
        "stool_count": r.choices([1, 2], [0.45, 0.55])[0],
        "stool_form": r.choices(["Normal", "Soft"], [0.88, 0.12])[0],
        "blood": "None",
        "pain": r.choices([1, 2], [0.65, 0.35])[0],
        "night_waking": False,
        "symptoms": sym,
        "energy": r.choice([7, 7, 8, 8, 8]) if sym != ["Tiredness"] else 6,
        "school_missed": False,
    }
    # teens skip optional questions now and then
    for k in ("stool_form", "energy", "symptoms"):
        if r.random() < 0.06:
            ans[k] = None
    return ans


for d in days():
    weekend = d.weekday() >= 5
    sick = d in (BUG1, BUG2)

    # meds: mesalamine ~92%, vitamin D ~85% (evening, missed more)
    if d != BUG1 and r.random() < (0.93 if not weekend else 0.85):
        b.take_dose(mesa, d, (7, r.randint(40, 59)) if not weekend else (r.randint(9, 10), r.randint(0, 59)), value=4)
    if r.random() < (0.88 if not weekend else 0.80):
        b.take_dose(vitd, d, (r.randint(19, 21), r.randint(0, 59)))

    if d == BUG1:
        b.submit("ibd", d, (18, 42), {
            "feeling": "Bad", "stool_count": 5, "stool_form": "Watery", "blood": "None", "pain": 4,
            "night_waking": False, "symptoms": ["Nausea", "Low appetite"], "energy": 4, "school_missed": False})
        continue
    if d == BUG2:
        b.submit("ibd", d, (17, 15), {
            "feeling": "Bad", "stool_count": 5, "stool_form": "Watery", "blood": "None", "pain": 3,
            "night_waking": True, "symptoms": ["Nausea", "Tiredness"], "energy": 4, "school_missed": True})
        continue
    if d == BUG3:
        b.submit("ibd", d, (20, 5), {
            "feeling": "Okay", "stool_count": 3, "stool_form": "Soft", "blood": "None", "pain": 2,
            "night_waking": False, "symptoms": ["Tiredness"], "energy": 6, "school_missed": False})
        continue

    if d in BLANK_DAYS:
        b.submit("ibd", d, (r.randint(16, 18), r.randint(0, 59)), blank=True)
    if r.random() < (0.85 if not weekend else 0.74):
        ans = baseline_answers()
        h, m = evening()
        b.submit("ibd", d, (h, m), ans)
        if r.random() < 0.05:
            # quick re-submit a few minutes later, only feeling + stool count
            b.submit("ibd", d, (h, min(59, m + r.randint(2, 9))), {"feeling": ans["feeling"], "stool_count": ans["stool_count"]})

gt = {
    "name": "Priya",
    "age": 16,
    "conditions": ["IBD (ulcerative colitis)"],
    "viewers": ["Gastroenterologist", "Primary care", "Nurse"],
}

# compute metrics on a copy so the ground truth text quotes the real numbers
cm = compute_metrics(copy.deepcopy(b).build(), b.trackers)
t = cm["trackers"][0]["windows"]
meds = {m["name"]: m["windows"] for m in cm["medications"]["medications"]}
f90, p30, l30 = t["full90"], t["prior30"], t["last30"]
mes, vd = meds["Mesalamine DR 1.2 g"], meds["Vitamin D3 1000 IU"]
q = f90["questions"]
blood_days = sum(v for k, v in q["blood"]["lastAnswerOfDayCounts"].items() if k != "None")

gt.update({
    "scenario": ("Ulcerative colitis in remission on mesalamine. She logs most days, stools stay at 1 to 2 a day and normal, "
                 "no blood, little pain, good energy. A 2-day stomach bug on Sep 20 to 21 caused watery stools and nausea, then cleared."),
    "clinician30s": (f"Stable remission. Mesalamine {mes['full90']['adherencePct']}% (self-reported), no blood on any day, "
                     f"stool mean {l30['questions']['stool_count']['meanOfDailyMax']}/day last 30 days. "
                     "One short stomach bug in September resolved. No change needed."),
    "expectedFlags": [],
    "expectedNonFlags": [
        f"Sep 20 to 21 stomach bug (stool 5, Watery, Nausea, one night waking, one school day missed Sep 21) is a resolved acute illness, "
        f"not a flare: no blood, back to baseline by Sep 22 to 23. Full90 max stool count {q['stool_count']['max']:.0f} comes only from those 2 days.",
        f"Missed mesalamine on Sep 20 (sick day) and occasional weekend misses; adherence still {mes['full90']['adherencePct']}% over 90 days.",
        f"Vitamin D adherence {vd['full90']['adherencePct']}% is a little lower (evening dose); fine for a supplement.",
        "Rare Urgency or Tiredness answers are background noise in remission.",
        "A few skipped days and a couple of blank submissions are normal logging gaps.",
    ],
    "keyFindings": {
        "mesalamineAdherence": f"{mes['prior30']['adherencePct']}% prior30, {mes['last30']['adherencePct']}% last30, {mes['full90']['adherencePct']}% full90 (self-reported)",
        "vitaminDAdherence": f"{vd['full90']['adherencePct']}% full90",
        "stoolCount": f"mean daily max {l30['questions']['stool_count']['meanOfDailyMax']} last30, {p30['questions']['stool_count']['meanOfDailyMax']} prior30",
        "blood": f"{blood_days} days with any blood in 90",
        "pain": f"mean {l30['questions']['pain']['meanOfDailyMax']} last30 (1 to 10 scale)",
        "energy": f"mean {l30['questions']['energy']['meanOfDailyMax']} last30",
        "nightWaking": f"{q['night_waking']['yesDays']} day in 90 (stomach bug)",
        "schoolMissed": f"{q['school_missed']['yesDays']} day in 90 (stomach bug)",
        "logging": f"answers on {f90['daysWithAnswers']} of 90 days",
        "stomachBug": "Sep 20 to 21: stool 5, Watery, Nausea; resolved by Sep 22 to 23",
    },
    "injectedQuirks": [
        "Occasional second submission minutes later with only feeling and stool count.",
        "A few blank submissions.",
        "Some optional questions (stool form, energy, symptoms) skipped now and then.",
        "No spirometer and no action plan (asthmaTreatmentPlan is null).",
    ],
})
b.save(gt)
print("p07-priya done")
