import copy
import random
import sys
from datetime import date
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "lib"))
from smarthome import PatientBuilder, days  # noqa: E402
from metrics import compute_metrics  # noqa: E402

b = PatientBuilder("p08-isaac", "Isaac M.", 16, "M", seed=808, height_cm=174, dob="2010-07-09")
r = b.rng
mr = random.Random(r.randint(0, 2**31))  # separate stream for doses so symptom tuning doesn't move adherence
b.assign_tracker("ibd")
b.add_tracker_reminder("ibd", "20:30")
aza = b.add_medication("Azathioprine 100 mg", "IBD", "Daily", "Pill", 1, "tablet", times=["08:00"])
ada = b.add_medication("Adalimumab (Humira) 40 mg pen", "IBD", "Every 2 Weeks", "Injection", 1, "pen",
                       times=["19:00"], period_unit="Weekly", interval=2, start_date=date(2026, 8, 14))

FLARE = date(2026, 10, 10)
LAST_WEEK = date(2026, 10, 30)
SCHOOL_MISSED = {date(2026, 10, 16), date(2026, 10, 22), date(2026, 10, 27),
                 date(2026, 10, 30), date(2026, 11, 2), date(2026, 11, 4)}
A_LOT_DAYS = {date(2026, 10, 31), date(2026, 11, 2), date(2026, 11, 4), date(2026, 11, 5)}


def sev(d):
    """0 before the flare, ramps to about 0.75 by Oct 20, 1.0 in the last week."""
    if d < FLARE:
        return 0.0
    if d >= LAST_WEEK:
        return 1.0
    k = (d - FLARE).days
    return min(0.8, 0.2 + k * 0.06)


def day_state(d):
    s = sev(d)
    if s == 0:
        sym = ["None of these"] if r.random() < 0.88 else [r.choice(["Tiredness", "Urgency"])]
        return {
            "feeling": r.choices(["Great", "Good", "Okay"], [0.25, 0.55, 0.20])[0],
            "stool_count": r.choices([1, 2, 3], [0.15, 0.65, 0.20])[0],
            "stool_form": r.choices(["Normal", "Soft"], [0.75, 0.25])[0],
            "blood": "None",
            "pain": r.choices([1, 2, 3], [0.4, 0.4, 0.2])[0],
            "night_waking": False,
            "symptoms": sym,
            "energy": r.choice([6, 6, 7, 7, 8]),
            "school_missed": False,
        }
    stool = round(2 + s * 5 + r.uniform(-0.6, 1.2))
    stool = max(3, min(8, stool))
    if s < 0.4:
        form = r.choice(["Soft", "Mushy"])
        pain = r.randint(4, 5)
        blood = "None" if r.random() < 0.6 else "A little"
        feeling = r.choice(["Okay", "Bad"])
        energy = r.randint(4, 5)
    else:
        form = r.choices(["Mushy", "Watery"], [0.5, 0.5] if s < 1 else [0.3, 0.7])[0]
        pain = r.randint(6, 8)
        blood = "A little" if r.random() < (0.75 if s < 1 else 1.0) else "None"
        feeling = r.choices(["Bad", "Awful"], [0.6, 0.4] if s < 1 else [0.35, 0.65])[0]
        energy = r.choice([2, 3, 3, 3, 4])
    if d in A_LOT_DAYS:
        blood = "A lot"
    sym = [x for x, p in (("Urgency", 0.6 * s + 0.2), ("Low appetite", 0.7 * s), ("Tiredness", 0.6 * s),
                          ("Joint pain", 0.55 * s), ("Nausea", 0.15 * s)) if r.random() < p]
    night = s >= 0.3 and r.random() < (0.72 if s < 1 else 0.9)
    return {
        "feeling": feeling, "stool_count": stool, "stool_form": form, "blood": blood, "pain": pain,
        "night_waking": night, "symptoms": sym or ["Tiredness"], "energy": energy,
        "school_missed": d in SCHOOL_MISSED,
    }


for d in days():
    weekend = d.weekday() >= 5
    s = sev(d)

    # azathioprine ~92%, still taken during the flare
    if mr.random() < (0.94 if not weekend else 0.88):
        b.take_dose(aza, d, (7, mr.randint(35, 59)) if not weekend else (mr.randint(9, 11), mr.randint(0, 59)))
    if (d - date(2026, 8, 14)).days % 14 == 0 and d >= date(2026, 8, 14):
        b.take_dose(ada, d, (19, r.randint(5, 40)))

    st = day_state(d)
    if s == 0:
        if r.random() < (0.82 if not weekend else 0.68):
            if r.random() < 0.03:
                b.submit("ibd", d, (r.randint(19, 21), r.randint(0, 59)), blank=True)
                continue
            h, m = (r.randint(19, 21), r.randint(0, 59)) if r.random() < 0.85 else (22, r.randint(0, 45))
            b.submit("ibd", d, (h, m), st)
            if r.random() < 0.04:
                b.submit("ibd", d, (h, min(59, m + r.randint(1, 6))), {"feeling": st["feeling"]})
        continue

    # flare: always logs; more often as it gets worse; 2 to 3 a day in the last week
    if d >= LAST_WEEK:
        n = r.choice([2, 3, 3])
    else:
        n = 2 if r.random() < 0.15 + 0.4 * s else 1
    slots = [(r.randint(6, 7), r.randint(0, 59)), (r.randint(13, 16), r.randint(0, 59)), (r.randint(20, 22), r.randint(0, 59))]
    if n == 1:
        slots = [slots[2]]
    elif n == 2:
        slots = [slots[0], slots[2]]
    for i, t in enumerate(slots):
        final = i == len(slots) - 1
        if final:
            b.submit("ibd", d, t, st)
        elif i == 0:
            # morning: night waking and pain, stool count so far
            b.submit("ibd", d, t, {
                "feeling": st["feeling"], "stool_count": max(1, st["stool_count"] // 3 + 1),
                "blood": st["blood"] if r.random() < 0.6 else None, "pain": st["pain"],
                "night_waking": st["night_waking"], "school_missed": st["school_missed"] if d.weekday() < 5 else None,
            })
        else:
            b.submit("ibd", d, t, {
                "feeling": st["feeling"], "stool_count": max(2, st["stool_count"] - r.randint(1, 3)),
                "stool_form": st["stool_form"], "pain": min(8, st["pain"] + r.choice([0, 0, 1])),
                "symptoms": st["symptoms"],
            })

gt = {
    "name": "Isaac",
    "age": 16,
    "conditions": ["IBD (Crohn's disease)"],
    "viewers": ["Gastroenterologist", "Primary care", "Nurse"],
}

cm = compute_metrics(copy.deepcopy(b).build(), b.trackers)
t = cm["trackers"][0]["windows"]
meds = {m["name"]: m["windows"] for m in cm["medications"]["medications"]}
p30, l30 = t["prior30"], t["last30"]
lq, pq = l30["questions"], p30["questions"]
az, ad = meds["Azathioprine 100 mg"], meds["Adalimumab (Humira) 40 mg pen"]
lb = lq["blood"]["lastAnswerOfDayCounts"]
blood_l30 = lb.get("A little", 0) + lb.get("A lot", 0)
nw = lq["night_waking"]["yesDays"]
weeks = ((date(2026, 11, 5) - FLARE).days + 1) / 7
sym_l30 = lq["symptoms"]["daysByOption"]

gt.update({
    "scenario": ("Crohn's disease with an active, worsening flare since about Oct 10 even though he reports taking azathioprine and "
                 "adalimumab on schedule. Stools went from about 2 to 6 to 8 a day, mushy or watery, with blood that became heavy in the last week, "
                 "high pain, night-time stools most nights, low energy and missed school. He now logs 2 to 3 times a day."),
    "clinician30s": (f"Active worsening Crohn's flare. Last 30 days: stool mean {lq['stool_count']['meanOfDailyMax']}/day (max {lq['stool_count']['max']:.0f}), "
                     f"blood on {blood_l30} days ({lb.get('A lot', 0)} 'A lot' in the last week), night stools {nw} days, pain mean {lq['pain']['meanOfDailyMax']}, "
                     f"{lq['school_missed']['yesDays']} school days missed. Self-reported azathioprine {az['last30']['adherencePct']}% and adalimumab "
                     f"{ad['last30']['dosesTaken']}/{ad['last30']['expectedDoses']}, so this looks like treatment failure, not non-adherence. Needs prompt contact and workup."),
    "expectedFlags": [
        {"flag": "active_ibd_flare_worsening", "severity": "high", "for": ["Gastroenterologist", "Primary care"],
         "evidence": (f"stool_count meanOfDailyMax {pq['stool_count']['meanOfDailyMax']} prior30 -> {lq['stool_count']['meanOfDailyMax']} last30 (max {lq['stool_count']['max']:.0f}); "
                      f"pain {pq['pain']['meanOfDailyMax']} -> {lq['pain']['meanOfDailyMax']}; energy {pq['energy']['meanOfDailyMax']} -> {lq['energy']['meanOfDailyMax']}; "
                      f"stool_form last30 {lq['stool_form']['lastAnswerOfDayCounts']}")},
        {"flag": "rectal_bleeding", "severity": "high", "for": ["Gastroenterologist", "Primary care"],
         "evidence": f"blood last30 {lb} (prior30 {pq['blood']['lastAnswerOfDayCounts']}); 'A lot' on {lb.get('A lot', 0)} days, all Oct 31 to Nov 5"},
        {"flag": "nocturnal_stools", "severity": "high", "for": ["Gastroenterologist"],
         "evidence": f"night_waking yesDays {nw} of {lq['night_waking']['daysAnswered']} answered days last30 (prior30 {pq['night_waking']['yesDays']}); about {nw / weeks:.1f} nights/week since Oct 10"},
        {"flag": "missed_school_and_extraintestinal_symptoms", "severity": "medium", "for": ["Gastroenterologist", "Primary care"],
         "evidence": (f"school_missed yesDays {lq['school_missed']['yesDays']} last30 (all weekdays); symptoms last30 Low appetite {sym_l30.get('Low appetite', 0)} days, "
                      f"Joint pain {sym_l30.get('Joint pain', 0)} days, Urgency {sym_l30.get('Urgency', 0)} days")},
        {"flag": "flare_despite_reported_adherence", "severity": "medium", "for": ["Gastroenterologist"],
         "evidence": (f"azathioprine adherencePct {az['last30']['adherencePct']} last30 / {az['full90']['adherencePct']} full90; adalimumab "
                      f"{ad['last30']['dosesTaken']}/{ad['last30']['expectedDoses']} last30 and {ad['full90']['dosesTaken']}/{ad['full90']['expectedDoses']} full90. Self-reported, not verified.")},
    ],
    "expectedNonFlags": [
        f"More submissions per day (multiSubmissionDays {l30['multiSubmissionDays']} last30) is a sign he is unwell and tracking closely, not a data error.",
        "Morning submissions show a lower stool count than the evening one on the same day; use the daily max.",
        "Do not call this non-adherence: self-reported doses are on schedule.",
    ],
    "keyFindings": {
        "flareStart": "about 2026-10-10",
        "stoolCount": f"{pq['stool_count']['meanOfDailyMax']} prior30 -> {lq['stool_count']['meanOfDailyMax']} last30, max {lq['stool_count']['max']:.0f}",
        "blood": f"last30 {lb}",
        "pain": f"{pq['pain']['meanOfDailyMax']} prior30 -> {lq['pain']['meanOfDailyMax']} last30",
        "nightWaking": f"{nw} days last30",
        "energy": f"{pq['energy']['meanOfDailyMax']} prior30 -> {lq['energy']['meanOfDailyMax']} last30",
        "schoolMissed": f"{lq['school_missed']['yesDays']} weekdays last30",
        "feelingLast30": f"{lq['feeling']['lastAnswerOfDayCounts']}",
        "azathioprineAdherence": f"{az['prior30']['adherencePct']}% prior30, {az['last30']['adherencePct']}% last30 (self-reported)",
        "adalimumab": f"{ad['full90']['dosesTaken']}/{ad['full90']['expectedDoses']} doses on schedule full90",
        "logging": f"multiSubmissionDays {l30['multiSubmissionDays']} last30 vs {p30['multiSubmissionDays']} prior30; 2 to 3 per day Oct 30 to Nov 5",
    },
    "injectedQuirks": [
        "Several submissions per day in the flare; morning ones have partial answers and a lower stool count.",
        "A few blank or feeling-only resubmissions in the baseline period.",
        "Adalimumab every 2 weeks stored as Weekly with interval 2, start 2026-08-14.",
        "No spirometer and no action plan (asthmaTreatmentPlan is null).",
    ],
})
b.save(gt)
print("p08-isaac done")
