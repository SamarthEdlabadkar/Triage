import copy
import random
import sys
from datetime import date
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "lib"))
from smarthome import PatientBuilder, days  # noqa: E402
from metrics import compute_metrics  # noqa: E402

b = PatientBuilder("p09-finn", "Finn O.", 17, "M", seed=909, height_cm=180, dob="2009-04-17")
r = b.rng
mr = random.Random(r.randint(0, 2**31))  # separate stream for doses
b.assign_tracker("ibd")
b.add_tracker_reminder("ibd", "20:30", enabled=False)  # he turned it off
mtx = b.add_medication("Methotrexate 15 mg", "IBD", "Weekly", "Pill", 6, "tablets (2.5 mg)", times=["10:00"],
                       period_unit="Weekly", interval=1, start_date=date(2026, 8, 8), schedule_days=[5])
fol = b.add_medication("Folic acid 1 mg", "IBD", "Daily", "Pill", 1, "tablet", times=["08:00"])

P1_END = date(2026, 9, 4)     # weeks 1 to 4
P2_END = date(2026, 10, 2)    # weeks 5 to 8
LAST_NONBLANK = date(2026, 10, 19)
LATE_LOGS = {date(2026, 10, 6), date(2026, 10, 12), LAST_NONBLANK}
LAST_BLANK = date(2026, 10, 27)
BURST_DAYS = {date(2026, 9, 9), date(2026, 9, 17), date(2026, 9, 29)}
BLANK_DAYS = {date(2026, 9, 12), date(2026, 9, 21), date(2026, 9, 26)}
EMPTY_DAYS = {date(2026, 9, 14), date(2026, 9, 24)}
# methotrexate (Saturdays): Sep 12 taken a day late, Sep 19 and Oct 10 missed, Oct 31 missed (stopped)
MTX_LATE = {date(2026, 9, 12): date(2026, 9, 13)}
MTX_MISSED = {date(2026, 9, 19), date(2026, 10, 10), date(2026, 10, 31)}
FOLIC_LATE = {date(2026, 10, 3), date(2026, 10, 9), date(2026, 10, 17), date(2026, 10, 24)}  # only doses after Oct 2


def answers(phase):
    if phase == 1:
        stool, pain = r.choice([2, 2, 3]), r.choice([2, 2, 3])
        feeling = r.choices(["Great", "Good", "Okay"], [0.2, 0.6, 0.2])[0]
        energy, sym = r.choice([6, 7, 7, 8]), (["None of these"] if r.random() < 0.85 else ["Tiredness"])
    elif phase == 2:
        stool, pain = r.choice([2, 3, 3, 4]), r.choice([2, 3, 3, 4])
        feeling = r.choices(["Good", "Okay", "Bad"], [0.35, 0.5, 0.15])[0]
        energy, sym = r.choice([5, 6, 6, 7]), (["None of these"] if r.random() < 0.6 else r.sample(["Tiredness", "Urgency", "Low appetite"], 1))
    else:
        stool, pain = r.choice([3, 4, 4]), r.choice([3, 4, 4])
        feeling = r.choice(["Okay", "Bad"])
        energy, sym = r.choice([4, 5, 5]), r.sample(["Tiredness", "Urgency", "Low appetite"], 2)
    return {
        "feeling": feeling, "stool_count": stool,
        "stool_form": r.choices(["Normal", "Soft", "Mushy"], [0.6, 0.35, 0.05] if phase == 1 else [0.25, 0.55, 0.2])[0],
        "blood": "None", "pain": pain, "night_waking": False, "symptoms": sym, "energy": energy, "school_missed": False,
    }


def eve():
    return (r.randint(19, 22), r.randint(0, 59))


for d in days():
    weekend = d.weekday() >= 5
    phase = 1 if d <= P1_END else (2 if d <= P2_END else 3)

    # ---- doses ----
    if d.weekday() == 5 and d not in MTX_MISSED and d not in MTX_LATE:
        b.take_dose(mtx, d, (mr.randint(10, 12), mr.randint(0, 59)), value=6)
    for due, late in MTX_LATE.items():
        if d == late:
            b.take_dose(mtx, d, (17, mr.randint(0, 59)), value=6)
    if phase == 1:
        if mr.random() < 0.95:
            b.take_dose(fol, d, (7, mr.randint(30, 59)) if not weekend else (mr.randint(9, 11), mr.randint(0, 59)))
    elif phase == 2:
        if mr.random() < (0.66 if not weekend else 0.5):
            b.take_dose(fol, d, (7, mr.randint(30, 59)) if not weekend else (mr.randint(10, 12), mr.randint(0, 59)))
    elif d in FOLIC_LATE:
        b.take_dose(fol, d, (mr.randint(9, 11), mr.randint(0, 59)))

    # ---- tracker ----
    if phase == 1:
        if r.random() < (0.93 if not weekend else 0.85):
            b.submit("ibd", d, eve(), answers(1))
    elif phase == 2:
        if d in BLANK_DAYS:
            b.submit("ibd", d, eve(), blank=True)
        elif d in EMPTY_DAYS:
            b.submit("ibd", d, eve(), empty_values=True)
        elif d in BURST_DAYS:
            a = answers(2)
            h, m = (r.randint(20, 21), r.randint(0, 30))
            n = r.randint(3, 5)
            for i in range(n):
                v = dict(a)
                if i < n - 1:
                    # answers flip around before the final one
                    v["feeling"] = r.choice(["Good", "Okay", "Bad"])
                    v["stool_count"] = min(4, max(1, a["stool_count"] + r.choice([-1, 0, 1])))
                    v["pain"] = min(4, max(1, a["pain"] + r.choice([-1, 0, 1])))
                    if r.random() < 0.4:
                        v = {k: v[k] for k in ("feeling", "stool_count", "pain")}
                b.submit("ibd", d, (h, m + i * r.randint(1, 3)), v)
        elif r.random() < (0.62 if not weekend else 0.42):
            ans = answers(2)
            for k in ("stool_form", "energy", "symptoms", "school_missed"):
                if r.random() < 0.2:
                    ans[k] = None
            b.submit("ibd", d, eve(), ans)
    else:
        if d in LATE_LOGS:
            ans = answers(3)
            if d == date(2026, 10, 12):
                ans["night_waking"] = True
            if d != date(2026, 10, 6):
                ans["stool_count"], ans["pain"] = 4, 4
            if d == LAST_NONBLANK:
                ans = {k: ans[k] for k in ("feeling", "stool_count", "pain", "symptoms")}  # quick, partial
            b.submit("ibd", d, (18, r.randint(5, 50)), ans)
        elif d == LAST_BLANK:
            b.submit("ibd", d, (16, 47), blank=True)

gt = {
    "name": "Finn",
    "age": 17,
    "conditions": ["IBD (Crohn's disease)"],
    "viewers": ["Gastroenterologist", "Primary care", "Nurse"],
}

cm = compute_metrics(copy.deepcopy(b).build(), b.trackers)
tr = cm["trackers"][0]
t = tr["windows"]
meds = {m["name"]: m["windows"] for m in cm["medications"]["medications"]}
f90, p30, l30 = t["full90"], t["prior30"], t["last30"]
first30_days = f90["daysWithAnswers"] - p30["daysWithAnswers"] - l30["daysWithAnswers"]
mt, fa = meds["Methotrexate 15 mg"], meds["Folic acid 1 mg"]
fa_first = fa["full90"]["dosesTaken"] - fa["prior30"]["dosesTaken"] - fa["last30"]["dosesTaken"]
mt_first = mt["full90"]["dosesTaken"] - mt["prior30"]["dosesTaken"] - mt["last30"]["dosesTaken"]
mt_first_exp = mt["full90"]["expectedDoses"] - mt["prior30"]["expectedDoses"] - mt["last30"]["expectedDoses"]
lq, pq = l30["questions"], p30["questions"]
fq = f90["questions"]


def first30_mean(k):
    n = fq[k]["daysAnswered"] - pq[k]["daysAnswered"] - lq[k]["daysAnswered"]
    tot = (fq[k]["meanOfDailyMax"] * fq[k]["daysAnswered"] - pq[k]["meanOfDailyMax"] * pq[k]["daysAnswered"]
           - lq[k]["meanOfDailyMax"] * lq[k]["daysAnswered"])
    return round(tot / n, 1)


days_silent = (date(2026, 11, 6) - LAST_NONBLANK).days
badges = copy.deepcopy(b).build()
badge_dates = sorted(x["date"][:10] for x in badges["earnedTrackerBadges"] + badges["earnedMedicationBadges"])

gt.update({
    "scenario": ("Crohn's disease on weekly methotrexate. He logged and took meds well for the first month, then logging became patchy "
                 "with blank and repeated submissions, and after early October it nearly stopped. His last real answers were on Oct 19, "
                 "a blank submission on Oct 27, and his last recorded dose was Oct 24. When he did answer, symptoms were creeping up a little."),
    "clinician30s": (f"Disengaging, current status unknown. Answers on {first30_days} days in the first 30, {p30['daysWithAnswers']} prior30, "
                     f"{l30['daysWithAnswers']} last30; last real answers 2026-10-19, nothing since but one blank on Oct 27. Last dose Oct 24, "
                     f"methotrexate due Oct 31 not recorded. Last answers showed stool {lq['stool_count']['max']:.0f}/day and pain {lq['pain']['max']:.0f}, up from about {first30_mean('stool_count')} and {first30_mean('pain')} in the first month. "
                     "No data is not the same as no symptoms: reach out and check in directly."),
    "expectedFlags": [
        {"flag": "disengagement_logging_decline", "severity": "high", "for": ["Gastroenterologist", "Primary care", "Nurse"],
         "evidence": (f"daysWithAnswers: {first30_days} in Aug 8 to Sep 6 (full90 {f90['daysWithAnswers']} minus prior30 and last30), "
                      f"{p30['daysWithAnswers']} prior30, {l30['daysWithAnswers']} last30; lastNonBlankSubmission {tr['lastNonBlankSubmission']} (Oct 19 local); "
                      f"blankSubmissions {tr['blankSubmissions']}; last30 longestGapDays {l30['longestGapDays']}; tracker reminder disabled")},
        {"flag": "status_unknown_since_oct_19", "severity": "high", "for": ["Gastroenterologist", "Primary care"],
         "evidence": (f"no answers after 2026-10-19 ({days_silent} days before the Nov 6 visit); lastSubmission {tr['lastSubmission']} is a blank; "
                      f"lastAnyActivity {cm['lastAnyActivity']}. Do not read missing days as symptom free.")},
        {"flag": "medication_adherence_decline", "severity": "high", "for": ["Gastroenterologist", "Primary care"],
         "evidence": (f"folic acid {fa_first}/30 doses first 30 days, adherencePct {fa['prior30']['adherencePct']} prior30, {fa['last30']['adherencePct']} last30; "
                      f"methotrexate {mt_first}/{mt_first_exp} first 30 days, {mt['prior30']['dosesTaken']}/{mt['prior30']['expectedDoses']} prior30, "
                      f"{mt['last30']['dosesTaken']}/{mt['last30']['expectedDoses']} last30, no dose after 2026-10-24 (Oct 31 dose missing). Self-reported.")},
        {"flag": "mild_symptom_creep_when_reported", "severity": "medium", "for": ["Gastroenterologist"],
         "evidence": (f"stool_count meanOfDailyMax {pq['stool_count']['meanOfDailyMax']} prior30 -> {lq['stool_count']['meanOfDailyMax']} last30 "
                      f"(first30 about {first30_mean('stool_count')}, derived); pain {pq['pain']['meanOfDailyMax']} -> {lq['pain']['meanOfDailyMax']}; "
                      f"night_waking yesDays last30 {lq['night_waking']['yesDays']}; blood None on all answered days")},
    ],
    "expectedNonFlags": [
        "Do not say 'no symptoms in the last 2 weeks': there is no data, not good data.",
        f"Burst days with several submissions minutes apart and changing answers (multiSubmissionDays {p30['multiSubmissionDays']} prior30) are logging behaviour; use the last answer of the day.",
        "Blank and empty-value submissions are not symptom reports.",
        f"Badges ({cm['earnedBadgeCount']}) were all earned early ({badge_dates[0]} to {badge_dates[-1]}); they do not reflect current engagement.",
        "Methotrexate taken one day late on Sep 13 still counts as taken.",
    ],
    "keyFindings": {
        "loggingDaysWithAnswers": f"{first30_days} first30 (derived), {p30['daysWithAnswers']} prior30, {l30['daysWithAnswers']} last30",
        "lastNonBlankSubmission": "2026-10-19 (local)",
        "lastSubmission": "2026-10-27, blank",
        "lastDose": "2026-10-24 (methotrexate and folic acid)",
        "methotrexate": f"{mt_first}/{mt_first_exp} first30, {mt['prior30']['dosesTaken']}/{mt['prior30']['expectedDoses']} prior30, {mt['last30']['dosesTaken']}/{mt['last30']['expectedDoses']} last30",
        "folicAcidAdherence": f"{round(100 * fa_first / 30, 1)}% first30 (derived), {fa['prior30']['adherencePct']}% prior30, {fa['last30']['adherencePct']}% last30",
        "blankSubmissions": f"{tr['blankSubmissions']} of {tr['totalSubmissions']}",
        "symptomsWhenReported": f"stool {first30_mean('stool_count')} first30 (derived) -> {pq['stool_count']['meanOfDailyMax']} -> {lq['stool_count']['meanOfDailyMax']}, pain {first30_mean('pain')} -> {pq['pain']['meanOfDailyMax']} -> {lq['pain']['meanOfDailyMax']} (first30 -> prior30 -> last30), no blood",
        "trackerReminder": "disabled",
        "badges": f"{cm['earnedBadgeCount']}, all dated {badge_dates[0]} to {badge_dates[-1]}",
    },
    "injectedQuirks": [
        "Blank submissions and empty_values submissions (every question present, value '') in September and one blank on Oct 27.",
        "Burst days (Sep 9, 17, 29) with 3 to 5 submissions minutes apart, answers changing, some partial.",
        "Tracker reminder present but enabled=false.",
        "Methotrexate stored as Weekly with daysOfWeek [5] (Saturday), start 2026-08-08; one dose taken a day late.",
        "No spirometer and no action plan (asthmaTreatmentPlan is null).",
    ],
})
b.save(gt)
print("p09-finn done")
