import sys
from datetime import date, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "lib"))
from smarthome import PatientBuilder, days, WINDOW_START, WINDOW_END  # noqa: E402

b = PatientBuilder("p10-maya", "Maya K.", 15, "F", seed=1020, height_cm=163, dob="2011-03-22")
r = b.rng
b.assign_tracker("migraine")
b.add_tracker_reminder("migraine", "20:30")
excedrin = b.add_medication("Excedrin Migraine", "Migraine", "As Needed", "Pill", 2, "tablets")
ibu = b.add_medication("Ibuprofen 400 mg", "Migraine", "As Needed", "Pill", 1, "tablet")
ribo = b.add_medication("Riboflavin 400 mg", "Migraine", "Daily", "Pill", 1, "tablet", times=["08:00"])

SCHOOL_START = date(2026, 8, 13)
PERIOD_STARTS = [date(2026, 8, 14), date(2026, 9, 11), date(2026, 10, 9), date(2026, 11, 6)]
period_days = {p + timedelta(days=i) for p in PERIOD_STARTS for i in range(3)}

# 30-day blocks aligned with the metric windows: (start, end, headache days, excedrin days, ibuprofen days, school missed)
BLOCKS = [
    (WINDOW_START, date(2026, 9, 6), 12, 11, 5, 0),
    (date(2026, 9, 7), date(2026, 10, 6), 13, 12, 4, 1),
    (date(2026, 10, 7), WINDOW_END, 17, 13, 5, 3),
]


def weighted_sample(pool, k, weight):
    pool = list(pool)
    out = []
    for _ in range(k):
        w = [weight(d) for d in pool]
        pick = r.choices(pool, w)[0]
        out.append(pick)
        pool.remove(pick)
    return sorted(out)


def school_day(d):
    return d.weekday() < 5 and d >= SCHOOL_START


headache, exc_days, ibu_days, missed = set(), set(), set(), set()
for start, end, n_h, n_e, n_i, n_m in BLOCKS:
    pool = list(days(start, end))
    hd = weighted_sample(pool, n_h, lambda d: 4.0 if d in period_days else (1.4 if school_day(d) else 0.7))
    headache |= set(hd)
    ed = r.sample(hd, n_e)
    exc_days |= set(ed)
    rest = [d for d in hd if d not in ed]
    idays = rest[:n_i] + r.sample(ed, max(0, n_i - len(rest)))
    ibu_days |= set(idays)
    wk = [d for d in hd if school_day(d)]
    missed |= set(r.sample(wk, n_m))

for d in days():
    weekend = d.weekday() >= 5
    # Riboflavin preventive: about 60%, worse on weekends.
    if r.random() < (0.66 if not weekend else 0.48):
        b.take_dose(ribo, d, (7, r.randint(35, 59)) if not weekend else (10, r.randint(0, 50)))

    # Sleep the night before: short on school nights.
    school_next = d.weekday() < 5 and d >= SCHOOL_START
    if school_next:
        sleep = r.gauss(6.4, 0.35)
    else:
        sleep = r.gauss(8.0, 0.6)
    if d in headache:
        sleep -= 0.25
    sleep = max(4.5, min(10.5, round(sleep * 2) / 2))

    is_h = d in headache
    if is_h or r.random() < (0.88 if not weekend else 0.72):
        ev = (r.choice([20, 21, 21, 22]), r.randint(0, 59))
        if is_h:
            sev = r.choices([4, 5, 6, 7, 8], [0.16, 0.26, 0.28, 0.22, 0.08])[0]
            if d in missed:
                sev = max(sev, 7)
            duration = (r.choice(["1 to 4 hours", "4 to 12 hours"]) if sev <= 5
                        else r.choices(["4 to 12 hours", "All day"], [0.6, 0.4])[0])
            if d in missed:
                duration = "All day"
            sym = [s for s, p in [("Light bothered me", 0.75), ("Sound bothered me", 0.5), ("Nausea", 0.35 if sev >= 6 else 0.1)] if r.random() < p]
            if sev >= 8 and r.random() < 0.5:
                sym.append("Throwing up")
            sym = sym or ["None of these"]
            trig = []
            if sleep < 6.5:
                trig.append("Poor sleep")
            if r.random() < 0.55:
                trig.append("Screens")
            if school_day(d) and r.random() < 0.6:
                trig.append("Stress")
            if d in period_days:
                trig.append("Period")
            if not trig:
                trig = ["Not sure"]
            feeling = "Awful" if sev >= 8 else ("Bad" if sev >= 6 else r.choice(["Okay", "Bad"]))
            ans = {
                "feeling": feeling,
                "headache": True,
                "severity": sev,
                "duration": duration,
                "symptoms": sym,
                "triggers": trig if r.random() < 0.9 else None,
                "sleep_hours": sleep if r.random() < 0.92 else None,
                "school_missed": (d in missed) if school_day(d) else None,
            }
            if d in missed:
                ev = (r.choice([13, 14, 15]), r.randint(0, 59))  # home from school, logs early
            b.submit("migraine", d, ev, ans)
            # Occasional second submission later the same evening, severity bumped up.
            if r.random() < 0.12:
                ans2 = dict(ans, severity=min(10, sev + 1), feeling="Bad" if sev < 8 else "Awful")
                b.submit("migraine", d, (min(23, ev[0] + 1), r.randint(0, 59)), ans2)
        else:
            feeling = r.choices(["Great", "Good", "Okay"], [0.15, 0.55, 0.30])[0]
            b.submit("migraine", d, ev, {
                "feeling": feeling,
                "headache": False,
                "sleep_hours": sleep if r.random() < 0.9 else None,
                "school_missed": False if school_day(d) and r.random() < 0.7 else None,
            })

    if d in exc_days:
        h = r.randint(12, 17) if not weekend else r.randint(10, 16)
        b.take_dose(excedrin, d, (h, r.randint(0, 59)), value=2)
        if r.random() < 0.18:  # second dose later the same day
            b.take_dose(excedrin, d, (min(21, h + r.randint(4, 6)), r.randint(0, 59)), value=2)
    if d in ibu_days:
        b.take_dose(ibu, d, (r.randint(16, 20), r.randint(0, 59)), value=1)

# Quirk: one blank submission (opened and closed the form).
b.submit("migraine", date(2026, 9, 27), (22, 48), blank=True)
b.submit("migraine", date(2026, 10, 25), (23, 5), blank=True)

# Preview metrics on a copy so the ground truth text quotes the real numbers.
import copy  # noqa: E402
import json  # noqa: E402
from metrics import compute_metrics  # noqa: E402

DOC = copy.deepcopy(b).build()
M = compute_metrics(DOC, b.trackers)
T = M["trackers"][0]["windows"]
MED = {m["name"]: m["windows"] for m in M["medications"]["medications"]}


def q(w, k, f):
    return T[w]["questions"][k][f]


def custom(lo, hi):
    """Headache days, Excedrin days and school-night sleep for any date range (non-window ranges)."""
    qid = {qq["metricKey"]: qq["questionId"] for qq in b.trackers["migraine"]["questions"]}
    hd, exd, sleep = set(), set(), []
    for log in DOC["dailyLogs"]:
        d = date.fromisoformat(log["day"])
        if not (lo <= d <= hi):
            continue
        day_sleep = []
        for s_ in log["trackerResponses"]:
            for rr in s_["responses"]:
                if rr["questionId"] == qid["headache"] and rr["value"] == "Yes":
                    hd.add(d)
                if rr["questionId"] == qid["sleep_hours"] and rr["value"] != "":
                    day_sleep.append(float(rr["value"]))
        if day_sleep and d.weekday() < 5 and d >= SCHOOL_START:
            sleep.append(max(day_sleep))
        if any(a["medicationId"] == excedrin for a in log["medicationAdministrations"]):
            exd.add(d)
    return len(hd), len(exd), round(sum(sleep) / len(sleep), 2) if sleep else None


hd = {w: q(w, "headache", "yesDays") for w in T}
ex = {w: MED["Excedrin Migraine"][w]["daysUsed"] for w in T}
ib = {w: MED["Ibuprofen 400 mg"][w]["daysUsed"] for w in T}
rb = {w: MED["Riboflavin 400 mg"][w]["adherencePct"] for w in T}
sev = {w: q(w, "severity", "meanOfDailyMax") for w in T}
sevmax = {w: q(w, "severity", "max") for w in T}
sl = {w: q(w, "sleep_hours", "meanOfDailyMax") for w in T}
sm = {w: q(w, "school_missed", "yesDays") for w in T}
logged = {w: T[w]["daysWithAnswers"] for w in T}
early = custom(WINDOW_START, date(2026, 9, 6))
sn_last = custom(date(2026, 10, 7), WINDOW_END)[2]
sn_all = custom(WINDOW_START, WINDOW_END)[2]
trig = T["full90"]["questions"]["triggers"]["daysByOption"]

GT = {
    "name": "Maya",
    "age": 15,
    "conditions": ["Migraine"],
    "viewers": ["Neurologist", "Primary care", "Nurse"],
    "scenario": (f"Migraines are getting more frequent and are now in the chronic range ({hd['last30']} headache days in the last 30). "
                 f"She takes Excedrin Migraine on {early[1]}, {ex['prior30']} and {ex['last30']} days in each 30-day block, plus ibuprofen, "
                 f"a medication overuse pattern. Her riboflavin preventive is logged only {rb['full90']}% of days and she sleeps about {sn_all} hours on school nights."),
    "clinician30s": (f"Chronic migraine frequency ({hd['last30']} headache days last 30, up from {hd['prior30']}). "
                     f"Excedrin (combination analgesic) on {ex['last30']} days last 30 and >= 10 days in every 30-day block for 90 days: medication overuse headache risk. "
                     f"Preventive adherence {rb['last30']}% (self-reported). School-night sleep about {sn_all} h. "
                     f"{sm['last30']} school days missed last 30. Review preventive plan, acute med limits, and sleep."),
    "expectedFlags": [
        {"flag": "chronic_migraine_frequency", "severity": "high", "for": ["Neurologist", "Primary care"],
         "evidence": f"headache yesDays last30 = {hd['last30']} (>= 15 = chronic range), prior30 = {hd['prior30']}, Aug 8 to Sep 6 = {early[0]}; mean daily max severity last30 = {sev['last30']}, max {sevmax['last30']}; school missed last30 = {sm['last30']} days"},
        {"flag": "acute_medication_overuse", "severity": "high", "for": ["Neurologist", "Primary care"],
         "evidence": f"Excedrin Migraine daysUsed last30 = {ex['last30']}, prior30 = {ex['prior30']}, Aug 8 to Sep 6 = {early[1]} (combination analgesic >= 10 days/month); ibuprofen daysUsed last30 = {ib['last30']}, prior30 = {ib['prior30']}"},
        {"flag": "low_preventive_adherence", "severity": "medium", "for": ["Neurologist", "Primary care", "Nurse"],
         "evidence": f"Riboflavin 400 mg adherencePct last30 = {rb['last30']}%, prior30 = {rb['prior30']}%, full90 = {rb['full90']}% (self-reported)"},
        {"flag": "short_sleep", "severity": "medium", "for": ["Neurologist", "Primary care"],
         "evidence": f"mean reported sleep on school days (Mon to Fri) = {sn_all} h over 90 days, {sn_last} h in last30; overall meanOfDailyMax sleep_hours last30 = {sl['last30']} h; Poor sleep marked as trigger on {trig.get('Poor sleep', 0)} headache days in 90"},
    ],
    "expectedNonFlags": [
        "No-headache days with skipped severity, duration, symptoms and triggers are normal and are not missing data.",
        "A few headache days with two submissions (severity bumped by 1) are re-logs, not two separate headaches.",
        "Period listed as a trigger on a few days fits menstrual migraine; it is context, not a separate flag.",
        "Riboflavin is a supplement; low adherence matters but is self-reported, not verified.",
    ],
    "keyFindings": {
        "headacheDays": f"Aug 8 to Sep 6: {early[0]}, prior30: {hd['prior30']}, last30: {hd['last30']} (chronic range)",
        "excedrinDays": f"Aug 8 to Sep 6: {early[1]}, prior30: {ex['prior30']}, last30: {ex['last30']}",
        "ibuprofenDays": f"prior30: {ib['prior30']}, last30: {ib['last30']}",
        "riboflavinAdherence": f"{rb['full90']}% over 90 days, {rb['last30']}% last30 (self-reported)",
        "severity": f"mean daily max {sev['last30']} last30, max {sevmax['full90']}",
        "schoolNightSleep": f"about {sn_all} h",
        "schoolMissed": f"{sm['last30']} days last30, {sm['prior30']} prior30",
        "loggingDays": f"{logged['last30']} of 30 days last30",
        "topTriggers": ", ".join(f"{k} {v}" for k, v in sorted(trig.items(), key=lambda x: -x[1])),
    },
    "injectedQuirks": [
        "Some headache days have a second submission later the same evening with severity bumped by 1 (daily max is used).",
        "Two blank submissions (form opened and closed).",
        "On no-headache days severity, duration, symptoms and triggers are skipped, and school_missed is sometimes skipped.",
        "Some Excedrin days have two separate doses (2 tablets each).",
        "Headache days on which she missed school are logged in the early afternoon instead of the evening.",
    ],
}
b.save(GT)
print("p10-maya done")
print(json.dumps({"hd": hd, "early": early, "ex": ex, "ib": ib, "rb": rb, "sev": sev, "sleep": sl, "schoolNight": [sn_all, sn_last], "missed": sm, "logged": logged}, indent=None))
