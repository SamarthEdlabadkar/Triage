import copy
import json
import sys
from datetime import date
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "lib"))
from smarthome import PatientBuilder, days, WINDOW_START, WINDOW_END  # noqa: E402
from metrics import compute_metrics  # noqa: E402

b = PatientBuilder("p11-ben", "Ben T.", 14, "M", seed=1110, height_cm=168, dob="2012-07-09")
r = b.rng
b.assign_tracker("migraine")
b.add_tracker_reminder("migraine", "20:00")
START = date(2026, 9, 1)
SCHOOL_START = date(2026, 8, 13)
ami = b.add_medication("Amitriptyline 10 mg", "Migraine", "Daily", "Pill", 1, "tablet", times=["21:00"], start_date=START)
riza = b.add_medication("Rizatriptan 10 mg", "Migraine", "As Needed", "Pill", 1, "tablet")
ibu = b.add_medication("Ibuprofen 400 mg", "Migraine", "As Needed", "Pill", 1, "tablet")

# (start, end, headache days, rizatriptan days, ibuprofen days, school missed, severity choices, weights)
BLOCKS = [
    (WINDOW_START, date(2026, 8, 31), 10, 5, 4, 2, [5, 6, 7, 8], [0.15, 0.3, 0.35, 0.2]),
    (START, date(2026, 9, 6), 2, 1, 1, 0, [5, 6, 7], [0.3, 0.4, 0.3]),
    (date(2026, 9, 7), date(2026, 10, 6), 6, 2, 3, 0, [3, 4, 5, 6], [0.2, 0.35, 0.3, 0.15]),
    (date(2026, 10, 7), WINDOW_END, 4, 1, 2, 0, [3, 4, 5], [0.35, 0.4, 0.25]),
]


def school_day(d):
    return d.weekday() < 5 and d >= SCHOOL_START


plan = {}  # day -> dict(sev, riza, ibu, missed)
for start, end, n_h, n_r, n_i, n_m, sevs, wts in BLOCKS:
    pool = list(days(start, end))
    hd = sorted(r.sample(pool, n_h))
    sev = {d: r.choices(sevs, wts)[0] for d in hd}
    by_sev = sorted(hd, key=lambda d: -sev[d])
    rz = set(by_sev[:n_r])
    rest = [d for d in hd if d not in rz]
    ib = set(r.sample(rest, min(n_i, len(rest))))
    wk = [d for d in by_sev if school_day(d)]
    ms = set(wk[:n_m])
    for d in hd:
        plan[d] = {"sev": max(sev[d], 7) if d in ms else sev[d], "riza": d in rz, "ibu": d in ib, "missed": d in ms}

# About 90% adherence: 3 missed nights in each 30-day window (mostly Fri/Sat), plus 1 in Sep 1 to 6.
ami_missed = set()
for lo, hi, n in [(START, date(2026, 9, 6), 1), (date(2026, 9, 7), date(2026, 10, 6), 3), (date(2026, 10, 7), WINDOW_END, 3)]:
    pool = list(days(lo, hi))
    while len([d for d in ami_missed if lo <= d <= hi]) < n:
        ami_missed.add(r.choices(pool, [3 if d.weekday() in (4, 5) else 1 for d in pool])[0])

for d in days():
    weekend = d.weekday() >= 5
    on_prev = d > START  # amitriptyline taken the night before
    if d >= START and d not in ami_missed:
        b.take_dose(ami, d, (21, r.randint(0, 40)) if not weekend else (r.choice([21, 22]), r.randint(0, 50)))

    school_next = d.weekday() < 5 and d >= SCHOOL_START
    if on_prev:
        sleep = r.gauss(8.4, 0.3) if school_next else r.gauss(9.0, 0.35)
        sleep = max(8.0, min(9.5, sleep))
    else:
        sleep = r.gauss(7.0, 0.4) if school_next else r.gauss(8.3, 0.5)
    sleep = round(sleep * 2) / 2

    p = plan.get(d)
    if p or r.random() < (0.88 if not weekend else 0.75):
        ev = (r.choice([19, 20, 20, 21]), r.randint(0, 59))
        if p:
            sev = p["sev"]
            duration = ("1 to 4 hours" if sev <= 4 else
                        r.choice(["1 to 4 hours", "4 to 12 hours"]) if sev <= 6 else
                        r.choice(["4 to 12 hours", "All day"]))
            sym = [s for s, pr in [("Light bothered me", 0.7 if sev >= 5 else 0.35), ("Sound bothered me", 0.5 if sev >= 5 else 0.2),
                                   ("Nausea", 0.45 if sev >= 7 else 0.1)] if r.random() < pr]
            if sev >= 7 and r.random() < 0.2:
                sym.append("Aura (seeing spots or lines)")
            trig = [t for t, pr in [("Screens", 0.45), ("Skipped a meal", 0.3), ("Weather", 0.2),
                                    ("Poor sleep", 0.5 if sleep < 7.5 else 0.05)] if r.random() < pr] or ["Not sure"]
            feeling = "Awful" if sev >= 8 else "Bad" if sev >= 6 else r.choice(["Okay", "Okay", "Bad"]) if sev >= 4 else "Okay"
            b.submit("migraine", d, ev, {
                "feeling": feeling,
                "headache": True,
                "severity": sev,
                "duration": duration,
                "symptoms": sym or ["None of these"],
                "triggers": trig if r.random() < 0.85 else None,
                "sleep_hours": sleep if r.random() < 0.9 else None,
                "school_missed": p["missed"] if school_day(d) else None,
            })
            if p["riza"]:
                b.take_dose(riza, d, (r.randint(11, 17), r.randint(0, 59)))
            if p["ibu"]:
                b.take_dose(ibu, d, (r.randint(14, 19), r.randint(0, 59)))
        else:
            good = [0.35, 0.5, 0.15] if on_prev else [0.2, 0.5, 0.3]
            b.submit("migraine", d, ev, {
                "feeling": r.choices(["Great", "Good", "Okay"], good)[0],
                "headache": False,
                "sleep_hours": sleep if r.random() < 0.88 else None,
                "school_missed": False if school_day(d) and r.random() < 0.6 else None,
            })
            if r.random() < 0.04:  # re-opened the form later and only re-answered feeling
                b.submit("migraine", d, (22, r.randint(0, 30)), {"feeling": "Good"})

b.submit("migraine", date(2026, 9, 19), (21, 12), empty_values=True)
b.submit("migraine", date(2026, 10, 18), (20, 41), blank=True)

# Preview metrics on a copy so the ground truth text quotes the real numbers.
DOC = copy.deepcopy(b).build()
M = compute_metrics(DOC, b.trackers)
T = M["trackers"][0]["windows"]
MED = {m["name"]: m["windows"] for m in M["medications"]["medications"]}
QID = {qq["metricKey"]: qq["questionId"] for qq in b.trackers["migraine"]["questions"]}


def custom(lo, hi):
    """Same aggregation rules as metrics.py, for any date range (used for the pre-Sep-1 baseline)."""
    hd, sev, sleep, logged, rz, ib, missed = set(), [], [], 0, set(), set(), 0
    for log in DOC["dailyLogs"]:
        d = date.fromisoformat(log["day"])
        if not (lo <= d <= hi):
            continue
        vals = {}
        for s_ in log["trackerResponses"]:
            for rr in s_["responses"]:
                if rr["value"] != "":
                    vals.setdefault(rr["questionId"], []).append(rr["value"])
        if vals:
            logged += 1
        if "Yes" in vals.get(QID["headache"], []):
            hd.add(d)
        if vals.get(QID["severity"]):
            sev.append(max(float(x) for x in vals[QID["severity"]]))
        if vals.get(QID["sleep_hours"]):
            sleep.append(max(float(x) for x in vals[QID["sleep_hours"]]))
        if "Yes" in vals.get(QID["school_missed"], []):
            missed += 1
        for a in log["medicationAdministrations"]:
            if a["medicationId"] == riza:
                rz.add(d)
            if a["medicationId"] == ibu:
                ib.add(d)
    avg = lambda xs: round(sum(xs) / len(xs), 2) if xs else None  # noqa: E731
    return {"days": (hi - lo).days + 1, "logged": logged, "headacheDays": len(hd), "meanSeverity": avg(sev),
            "maxSeverity": max(sev) if sev else None, "meanSleep": avg(sleep), "rizatriptanDays": len(rz),
            "ibuprofenDays": len(ib), "schoolMissed": missed}


pre = custom(WINDOW_START, date(2026, 8, 31))
post = custom(START, WINDOW_END)
l30 = custom(date(2026, 10, 7), WINDOW_END)
p30 = custom(date(2026, 9, 7), date(2026, 10, 6))
ad = {w: MED["Amitriptyline 10 mg"][w]["adherencePct"] for w in T}
pre_rate = round(pre["headacheDays"] / pre["days"] * 30, 1)

GT = {
    "name": "Ben",
    "age": 14,
    "conditions": ["Migraine"],
    "viewers": ["Neurologist", "Primary care", "Nurse"],
    "scenario": (f"Started amitriptyline 10 mg nightly on Sep 1 and takes it about {round(ad['full90'])}% of nights. "
                 f"Headache days fell from {pre['headacheDays']} in the 24 days before starting to {l30['headacheDays']} in the last 30, "
                 f"headaches are milder, and he now sleeps 8 to 9 hours."),
    "clinician30s": (f"Improving on preventive. Headache days {pre['headacheDays']} in 24 days pre-start (about {pre_rate}/30 days) "
                     f"down to {p30['headacheDays']} prior30 and {l30['headacheDays']} last30; mean severity {pre['meanSeverity']} to {l30['meanSeverity']}. "
                     f"Acute meds rare (rizatriptan {l30['rizatriptanDays']} day, ibuprofen {l30['ibuprofenDays']} days last30). "
                     f"Amitriptyline adherence {ad['last30']}% last30 (self-reported). Continue current plan."),
    "expectedFlags": [
        {"flag": "improving_on_preventive", "severity": "low", "for": ["Neurologist", "Primary care"],
         "evidence": (f"headache days Aug 8 to Aug 31 (24 days) = {pre['headacheDays']}, prior30 = {T['prior30']['questions']['headache']['yesDays']}, "
                      f"last30 = {T['last30']['questions']['headache']['yesDays']}; severity meanOfDailyMax pre = {pre['meanSeverity']}, "
                      f"prior30 = {T['prior30']['questions']['severity']['meanOfDailyMax']}, last30 = {T['last30']['questions']['severity']['meanOfDailyMax']}; "
                      f"Amitriptyline adherencePct last30 = {ad['last30']}%, full90 = {ad['full90']}% (self-reported). Positive finding: continue preventive.")},
    ],
    "expectedNonFlags": [
        "Amitriptyline has no doses expected before Sep 1 (start date); 0 doses in August is not non-adherence.",
        f"Amitriptyline adherence about {round(ad['full90'])}% is good; the few missed nights are not a concern.",
        "Longer sleep (8 to 9 h) after starting amitriptyline is an expected effect and is not a problem.",
        "No-headache days with skipped severity, duration, symptoms and triggers are normal.",
        "One empty_values submission and one blank submission are app noise, not missing data.",
    ],
    "keyFindings": {
        "preventiveStart": "amitriptyline 10 mg nightly from 2026-09-01",
        "headacheDaysBefore": f"{pre['headacheDays']} in 24 days Aug 8 to Aug 31 (about {pre_rate} per 30 days)",
        "headacheDaysAfter": f"prior30 (Sep 7 to Oct 6): {p30['headacheDays']}, last30 (Oct 7 to Nov 5): {l30['headacheDays']}",
        "severityBeforeAfter": f"mean daily max {pre['meanSeverity']} (max {pre['maxSeverity']}) before vs {l30['meanSeverity']} (max {l30['maxSeverity']}) last30",
        "acuteMedsBeforeAfter": (f"rizatriptan {pre['rizatriptanDays']} days + ibuprofen {pre['ibuprofenDays']} days before; "
                                 f"rizatriptan {l30['rizatriptanDays']} + ibuprofen {l30['ibuprofenDays']} last30"),
        "sleepBeforeAfter": f"mean {pre['meanSleep']} h before vs {post['meanSleep']} h since Sep 1",
        "schoolMissed": f"{pre['schoolMissed']} days before, {post['schoolMissed']} since Sep 1",
        "amitriptylineAdherence": f"{ad['full90']}% since start, {ad['last30']}% last30 (self-reported)",
        "logging": f"{pre['logged']} of 24 days before, {l30['logged']} of 30 last30",
    },
    "injectedQuirks": [
        "One empty_values submission (every question present with value '') on 2026-09-19.",
        "One blank submission on 2026-10-18.",
        "A few no-headache days have a second late submission with only the feeling answer.",
        "Amitriptyline record exists from enrollment but its startDate is 2026-09-01, so no doses are due before then.",
        "Weekend amitriptyline doses are sometimes after 22:00.",
    ],
}
b.save(GT)
print("p11-ben done")
print(json.dumps({"pre": pre, "p30": p30, "l30": l30, "post": post, "ad": ad,
                  "hd": {w: T[w]["questions"]["headache"]["yesDays"] for w in T}}))
