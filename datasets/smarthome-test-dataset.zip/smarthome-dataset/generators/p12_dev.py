import copy
import json
import sys
from datetime import date
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "lib"))
from smarthome import PatientBuilder, days, WINDOW_START, WINDOW_END  # noqa: E402
from metrics import compute_metrics  # noqa: E402

b = PatientBuilder("p12-dev", "Dev P.", 17, "M", seed=1234, height_cm=178, dob="2009-04-17")
r = b.rng
b.assign_tracker("asthma")
b.assign_tracker("migraine")
b.add_tracker_reminder("asthma", "21:00")
NEW_EXC = date(2026, 9, 1)  # old Excedrin record archived and re-added on this day
SCHOOL_START = date(2026, 8, 17)
MIDTERMS = (date(2026, 10, 12), date(2026, 10, 23))
exc_old = b.add_medication("Excedrin", "Migraine", "As Needed", "Pill", 2, "tablets", archived=True)
dulera = b.add_medication("Dulera 200/5 mcg", "Asthma", "Daily", "Inhaler", 2, "puffs", times=["07:30", "21:30"])
albuterol = b.add_medication("Albuterol HFA", "Asthma", "As Needed", "Inhaler", 2, "puffs")
exc_new = b.add_medication("Excedrin", "Migraine", "As Needed", "Pill", 2, "tablets", start_date=NEW_EXC)
b.add_spirobank()
pred = {"fev1": 4.10, "fvc": 4.85, "pef": 8.6}
SPIRO_SKIP = {date(2026, 8, 30), date(2026, 9, 27), date(2026, 10, 25)}  # missed a few Sundays


def school_day(d):
    return d.weekday() < 5 and d >= SCHOOL_START


def mid(d):
    return MIDTERMS[0] <= d <= MIDTERMS[1]


# Migraine: headache days per 30-day block; last block has the midterm cluster.
headache = set()
headache |= set(r.sample(list(days(WINDOW_START, date(2026, 8, 31))), 3))
headache |= set(r.sample(list(days(NEW_EXC, date(2026, 9, 6))), 2))
headache |= set(r.sample(list(days(date(2026, 9, 7), date(2026, 10, 6))), 5))
headache |= set(r.sample([d for d in days(*MIDTERMS) if d.weekday() < 5], 5))
headache |= set(r.sample([d for d in days(date(2026, 10, 7), WINDOW_END) if not mid(d)], 2))
headache = sorted(headache)
exc_days = {d for d in headache if r.random() < 0.85 or mid(d)}
stray = set(r.sample(sorted(d for d in exc_days if mid(d)), 2))  # logged against the archived record (stale shortcut)

# Albuterol about 1 day/week, mostly after basketball.
alb_days = set()
for lo, hi, n in [(WINDOW_START, date(2026, 9, 6), 4), (date(2026, 9, 7), date(2026, 10, 6), 4), (date(2026, 10, 7), WINDOW_END, 5)]:
    pool = list(days(lo, hi))
    alb_days |= set(r.sample(pool, n))

for d in days():
    weekend = d.weekday() >= 5
    # Dulera about 80%: evening missed more than morning.
    if r.random() < (0.87 if not weekend else 0.78):
        b.take_dose(dulera, d, (7, r.randint(10, 50)) if not weekend else (r.choice([9, 10]), r.randint(0, 59)))
    if r.random() < (0.78 if not weekend else 0.7):
        b.take_dose(dulera, d, (r.choice([21, 22]), r.randint(0, 45)))

    alb = d in alb_days
    if alb:
        b.take_dose(albuterol, d, (r.randint(16, 18), r.randint(0, 59)), value=2)

    # Asthma tracker: about 70% of evenings, always on albuterol days.
    if alb or r.random() < (0.72 if not weekend else 0.6):
        late_oct = d >= date(2026, 10, 20)
        if alb:
            sym = r.sample(["Coughing", "Shortness Of Breath", "Tight Chest"], r.choice([1, 2]))
            trig = ["Exercise"] + (["Cold air"] if late_oct and r.random() < 0.6 else [])
            feeling = r.choice(["Good", "Okay"])
        else:
            sym = ["Coughing"] if r.random() < 0.025 else ["None of these "]
            trig = ["Exercise"] if r.random() < 0.12 else ["None of these"]
            feeling = r.choices(["Great", "Good", "Okay"], [0.45, 0.45, 0.1])[0]
            if d in headache and feeling == "Great":
                feeling = "Okay"
        b.submit("asthma", d, (r.choice([21, 22]), r.randint(0, 59)), {
            "feeling": feeling,
            "symptoms": sym,
            "night_waking": False,
            "school_missed": False if school_day(d) else None,
            "triggers": trig if r.random() < 0.85 else None,
        })

    # Spirometry about weekly (Sunday evening), FEV1 about 88% predicted and stable.
    if d.weekday() == 6 and d not in SPIRO_SKIP:
        b.spirometry_session(d, (20, r.randint(0, 30)), pred, r.gauss(0.865, 0.012), n_blows=r.choice([3, 3, 4]),
                             reject_prob=0.12, link_to_tracker=True)

    # Migraine tracker: ONLY submitted on headache days.
    if d in headache:
        m = mid(d)
        sev = r.choice([6, 7, 7, 8]) if m else r.choice([4, 5, 5, 6])
        sleep = round((r.gauss(5.8, 0.4) if m else r.gauss(7.3, 0.5)) * 2) / 2
        trig = (["Stress", "Poor sleep"] + (["Screens"] if r.random() < 0.6 else [])) if m else \
            ([t for t, p in [("Screens", 0.4), ("Skipped a meal", 0.3), ("Weather", 0.25)] if r.random() < p] or ["Not sure"])
        sym = [s for s, p in [("Light bothered me", 0.7), ("Sound bothered me", 0.4), ("Nausea", 0.3 if sev >= 7 else 0.05)] if r.random() < p]
        missed_school = m and sev >= 8 and school_day(d) and r.random() < 0.6
        b.submit("migraine", d, (r.choice([20, 21, 22]), r.randint(0, 59)), {
            "feeling": "Bad" if sev >= 7 else r.choice(["Okay", "Bad"]),
            "headache": True,
            "severity": sev,
            "duration": r.choice(["4 to 12 hours", "All day"]) if sev >= 7 else r.choice(["1 to 4 hours", "4 to 12 hours"]),
            "symptoms": sym or ["None of these"],
            "triggers": trig,
            "sleep_hours": sleep if r.random() < 0.9 else None,
            "school_missed": missed_school if school_day(d) else None,
        })
        if d in exc_days:
            mid_ = exc_old if (d < NEW_EXC or d in stray) else exc_new
            b.take_dose(mid_, d, (r.randint(13, 19), r.randint(0, 59)), value=2)

b.set_action_plan("Green", "2026-09-14T18:22:05.431Z", "2027-03-14", None)

# Preview metrics on a copy so the ground truth text quotes the real numbers.
DOC = copy.deepcopy(b).build()
M = compute_metrics(DOC, b.trackers)
TR = {t["trackerName"]: t for t in M["trackers"]}
AT = TR["Asthma Tracker"]["windows"] if "Asthma Tracker" in TR else M["trackers"][0]["windows"]
MT = TR["Migraine Tracker"]["windows"]
MEDS = M["medications"]["medications"]
by_id = {m["medicationId"]: m["windows"] for m in MEDS}
dul = by_id[dulera]
alb_w = by_id[albuterol]
old_w, new_w = by_id[exc_old], by_id[exc_new]
SP = M["spirometry"]
W = ["prior30", "last30", "full90"]
hd = {w: MT[w]["questions"]["headache"]["yesDays"] for w in W}
mlog = {w: MT[w]["daysWithAnswers"] for w in W}
exc_comb = {w: len({date.fromisoformat(l["day"]) for l in DOC["dailyLogs"]
                    for a in l["medicationAdministrations"] if a["medicationId"] in (exc_old, exc_new)
                    and (date(2026, 10, 7) if w == "last30" else date(2026, 9, 7) if w == "prior30" else WINDOW_START)
                    <= date.fromisoformat(l["day"]) <=
                    (WINDOW_END if w != "prior30" else date(2026, 10, 6))}) for w in W}
mid_hd = sum(1 for d in headache if mid(d))
aug_hd = sum(1 for d in headache if WINDOW_START <= d <= date(2026, 9, 6))
old_aug = sum(1 for d in exc_days if d < NEW_EXC)
pm = TR["Migraine Tracker"]["windows"]["last30"]["questions"]
sev_l30 = pm["severity"]["meanOfDailyMax"]
sev_p30 = MT["prior30"]["questions"]["severity"]["meanOfDailyMax"]
qid = {q["metricKey"]: q["questionId"] for q in b.trackers["migraine"]["questions"]}
ms, os_ = [], []
for l in DOC["dailyLogs"]:
    d = date.fromisoformat(l["day"])
    for s_ in l["trackerResponses"]:
        for rr in s_["responses"]:
            if rr["questionId"] == qid["sleep_hours"] and rr["value"] != "":
                (ms if mid(d) else os_).append(float(rr["value"]))
mid_sleep = round(sum(ms) / len(ms), 2)
oth_sleep = round(sum(os_) / len(os_), 2)
asym = {w: AT[w]["questions"]["symptoms"]["daysWithAny"] for w in W}
anw = {w: AT[w]["questions"]["night_waking"]["yesDays"] for w in W}
alog = {w: AT[w]["daysWithAnswers"] for w in W}
sm_mig = MT["last30"]["questions"]["school_missed"]["yesDays"]

GT = {
    "name": "Dev",
    "age": 17,
    "conditions": ["Asthma", "Migraine"],
    "viewers": ["Pulmonologist", "Neurologist", "Primary care", "Nurse"],
    "scenario": (f"Asthma is stable: Dulera about {round(dul['full90']['adherencePct'])}% of doses, albuterol about once a week, FEV1 near "
                 f"{round(SP['last14dAvgBestFev1Pct'])}% predicted, Green zone. Migraines are infrequent except a cluster of {mid_hd} headache days "
                 f"during midterms (Oct 12 to 23). His Excedrin doses are split across two medication records with the same name, "
                 f"and he only opens the migraine tracker on headache days."),
    "clinician30s": (f"Asthma: stable, Green, FEV1 {SP['first14dAvgBestFev1Pct']:.1f}% to {SP['last14dAvgBestFev1Pct']:.1f}% predicted, "
                     f"albuterol {alb_w['last30']['daysUsed']} days last30, Dulera {dul['last30']['adherencePct']}% last30 (self-reported). "
                     f"Migraine: {hd['last30']} headache days last30 ({mid_hd} during midterms), {hd['prior30']} prior30. "
                     f"Excedrin is logged under two records named 'Excedrin': combine them ({exc_comb['last30']} days last30). "
                     f"If a migraine preventive is considered, avoid propranolol (non-selective beta-blocker) because of asthma."),
    "expectedFlags": [
        {"flag": "duplicate_medication_record", "severity": "medium", "for": ["Primary care", "Neurologist", "Nurse"],
         "evidence": (f"two medications named 'Excedrin': archived record dosesRecordedFull90 = {next(m for m in MEDS if m['medicationId'] == exc_old)['dosesRecordedFull90']} "
                      f"(daysUsed full90 = {old_w['full90']['daysUsed']}, last30 = {old_w['last30']['daysUsed']} stray doses after it was archived), "
                      f"active record daysUsed full90 = {new_w['full90']['daysUsed']}, last30 = {new_w['last30']['daysUsed']}; "
                      f"combined Excedrin days last30 = {exc_comb['last30']}, prior30 = {exc_comb['prior30']}, full90 = {exc_comb['full90']}")},
        {"flag": "headache_cluster_midterms", "severity": "low", "for": ["Neurologist", "Primary care"],
         "evidence": (f"headache yesDays last30 = {hd['last30']}, prior30 = {hd['prior30']}, Aug 8 to Sep 6 = {aug_hd}; "
                      f"{mid_hd} of the last30 headache days fall Oct 12 to 23; severity meanOfDailyMax last30 = {sev_l30} vs prior30 = {sev_p30}; "
                      f"mean sleep on midterm headache days {mid_sleep} h vs {oth_sleep} h on other headache days; Stress and Poor sleep triggers")},
        {"flag": "migraine_missing_days_ambiguous", "severity": "low", "for": ["Neurologist"],
         "evidence": (f"migraine daysWithAnswers = headache yesDays in every window (last30 {mlog['last30']} = {hd['last30']}, "
                      f"full90 {mlog['full90']} = {hd['full90']}); he never logs a no-headache day, so unlogged days cannot be read as headache-free")},
        {"flag": "propranolol_caution_asthma", "severity": "low", "for": ["Neurologist", "Pulmonologist", "Primary care"],
         "evidence": (f"conditions Asthma + Migraine; asthma on Dulera {dul['full90']['adherencePct']}% (self-reported), action plan Green. "
                      "Propranolol, a common migraine preventive, is a non-selective beta-blocker generally avoided in asthma; pick another preventive if one is needed")},
    ],
    "expectedNonFlags": [
        f"Asthma is controlled: albuterol {alb_w['prior30']['daysUsed']} and {alb_w['last30']['daysUsed']} days in prior30/last30 (about 1 day/week, mostly after exercise), night waking {anw['last30']} days, FEV1 stable. Do not flag worsening.",
        f"Dulera adherence {dul['full90']['adherencePct']}% (self-reported) with evening doses missed more; worth a mention but not a control problem given stable FEV1 and Green zone.",
        f"Combined Excedrin use ({exc_comb['last30']} days last30) is below the >= 10 days/month overuse threshold for combination analgesics; do not flag overuse.",
        "Doses against the archived Excedrin record are real doses, not errors to drop; count them with the active record.",
        "The midterm headache cluster is situational (stress, short sleep) and settled after Oct 23.",
    ],
    "keyFindings": {
        "fev1": f"first 14d avg {SP['first14dAvgBestFev1Pct']:.1f}%, last 14d avg {SP['last14dAvgBestFev1Pct']:.1f}% predicted (change {SP['changeFev1PctPoints']} points), {SP['sessions']} sessions in 90 days",
        "dulera": f"{dul['full90']['adherencePct']}% full90, {dul['last30']['adherencePct']}% last30 (self-reported)",
        "albuterol": f"{alb_w['full90']['daysUsed']} days in 90 (prior30 {alb_w['prior30']['daysUsed']}, last30 {alb_w['last30']['daysUsed']})",
        "asthmaSymptomDays": f"prior30 {asym['prior30']}, last30 {asym['last30']}; night waking 0",
        "zone": "Green",
        "headacheDays": f"Aug 8 to Sep 6: {aug_hd}, prior30: {hd['prior30']}, last30: {hd['last30']} ({mid_hd} in Oct 12 to 23 midterms)",
        "excedrinSplit": (f"archived 'Excedrin' {old_w['full90']['daysUsed']} days (August {old_aug}, October stray {old_w['last30']['daysUsed']}), "
                          f"active 'Excedrin' {new_w['full90']['daysUsed']} days; combined {exc_comb['full90']} days in 90, {exc_comb['last30']} last30"),
        "migraineLogging": "only on headache days; no-headache days are never logged",
        "schoolMissedMigraine": f"{sm_mig} day(s) last30",
        "crossSpecialtyNote": "Avoid propranolol as a migraine preventive because of asthma.",
    },
    "specialistViews": {
        "Pulmonologist": (f"Stable asthma. Green zone, FEV1 about {round(SP['last14dAvgBestFev1Pct'])}% predicted with no downward trend, "
                          f"albuterol about 1 day/week mostly after exercise, no night waking. Dulera {dul['full90']['adherencePct']}% self-reported, "
                          "evening doses missed more. Note: if neurology starts a preventive, propranolol should be avoided."),
        "Neurologist": (f"Low-frequency migraine ({aug_hd}, {hd['prior30']}, {hd['last30']} headache days per 30-day block) with a stress and short-sleep "
                        f"cluster during midterms. Excedrin use combined across two records is {exc_comb['last30']} days last30, under overuse thresholds. "
                        "Migraine tracker is only filled on headache days, so frequency is a minimum. Avoid propranolol if a preventive is needed (asthma)."),
        "Primary care": ("Both conditions reasonably controlled. Clean up the duplicate Excedrin medication record (archived one still receives doses). "
                         "Discuss sleep and stress around exams. Coordinate preventive choice between neurology and pulmonology (no propranolol)."),
    },
    "injectedQuirks": [
        "Two medication records named 'Excedrin': index 0 is archived, a newer active one starts 2026-09-01.",
        f"August Excedrin doses are logged against the archived record; {old_w['last30']['daysUsed']} stray October doses also land on it (stale shortcut/reminder).",
        "Migraine tracker submitted only on headache days, so headache=No never appears.",
        "Spirometer question value is usually an empty string even when a session exists.",
        "Asthma tracker skipped on about 30% of evenings, more on weekends.",
    ],
}
b.save(GT)
print("p12-dev done")
print(json.dumps({"hd": hd, "aug_hd": aug_hd, "mid_hd": mid_hd, "mlog": mlog, "exc_old": old_w, "exc_new": new_w, "exc_comb": exc_comb,
                  "dulera": {w: dul[w]["adherencePct"] for w in W}, "alb": {w: alb_w[w]["daysUsed"] for w in W},
                  "fev1": [SP["first14dAvgBestFev1Pct"], SP["last14dAvgBestFev1Pct"], SP["sessions"], SP["gradeCounts"]],
                  "sleep": [mid_sleep, oth_sleep], "asym": asym, "alog": alog, "sev": [sev_p30, sev_l30], "sm": sm_mig}))
