import copy
import json
import sys
from datetime import date
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "lib"))
from smarthome import PatientBuilder, days  # noqa: E402
from metrics import compute_metrics  # noqa: E402

D = date
b = PatientBuilder("p13-rosa", "Rosa P.", 14, "F", seed=1317, height_cm=158, dob="2012-02-17")
r = b.rng
b.assign_tracker("asthma")
b.assign_tracker("ibd")
b.add_tracker_reminder("asthma", "20:00")
b.add_tracker_reminder("ibd", "20:00")
flut = b.add_medication("Fluticasone HFA 110 mcg", "Asthma", "Daily", "Inhaler", 2, "puffs", times=["07:15", "20:30"])
rescue = b.add_medication("Albuterol HFA", "Asthma", "As Needed", "Inhaler", 2, "puffs")
ada = b.add_medication("Adalimumab 40 mg pen", "IBD", "Every 2 Weeks", "Injection", 40, "mg", times=["18:00"],
                       period_unit="Weekly", interval=2, start_date=D(2026, 8, 12))
iron = b.add_medication("Ferrous sulfate 325 mg", "IBD", "Daily", "Pill", 1, "tablet", times=["07:15"])
b.add_spirobank()
pred = {"fev1": 3.05, "fvc": 3.50, "pef": 6.3}
NONE_A = "None of these "
NONE_I = "None of these"
MISSED = D(2026, 10, 21)
CREEP = D(2026, 10, 23)

# ---- daily meds
for d in days():
    wk = d.weekday() >= 5
    if r.random() < (0.92 if not wk else 0.84):
        b.take_dose(flut, d, (7 if not wk else 9, r.randint(5, 50)))
    if r.random() < (0.85 if not wk else 0.76):
        b.take_dose(flut, d, (20, r.randint(15, 59)) if r.random() < 0.75 else (21, r.randint(5, 50)))
    if r.random() < (0.55 if not wk else 0.4):
        b.take_dose(iron, d, (7 if not wk else 9, r.randint(10, 55)))

# ---- adalimumab: due Aug 12, 26, Sep 9, 23, Oct 7, 21, Nov 4 (Wednesdays)
for d, t in [(D(2026, 8, 12), (18, 10)), (D(2026, 8, 26), (18, 25)), (D(2026, 9, 9), (18, 5)),
             (D(2026, 9, 27), (11, 40)),   # Sep 23 dose given 4 days late (Sunday)
             (D(2026, 10, 7), (18, 20)),
             # Oct 21 missed entirely
             (D(2026, 11, 4), (18, 15))]:
    b.take_dose(ada, d, t)

# ---- albuterol, 2 days in 90
b.take_dose(rescue, D(2026, 8, 29), (15, 20), value=2)
b.take_dose(rescue, D(2026, 10, 3), (10, 45), value=2)


# ---- trackers
def asthma_ans(d):
    sym = [NONE_A]
    trig = ["None of these"]
    if d in (D(2026, 8, 29), D(2026, 10, 3)):
        sym, trig = ["Coughing", "Tight Chest"], ["Exercise"] if d.month == 8 else ["Cold air"]
    elif r.random() < 0.04:
        sym = ["Coughing"]
    ibd_bad = d >= CREEP
    feeling = r.choices(["Great", "Good", "Okay"], [0.4, 0.5, 0.1] if not ibd_bad else [0.15, 0.55, 0.3])[0]
    if sym != [NONE_A] and feeling == "Great":
        feeling = "Good"
    return {"feeling": feeling, "symptoms": sym, "night_waking": False, "school_missed": False,
            "triggers": trig if r.random() < 0.8 else None}


def ibd_ans(d):
    k = 0.0 if d < CREEP else min(1.0, ((d - CREEP).days + 1) / 8)
    stool = max(1, min(6, round(r.choice([1, 2, 2, 2, 3]) + 2.6 * k + r.gauss(0, 0.4))))
    pain = max(1, min(7, round(r.choice([1, 2, 2, 3]) + 2.6 * k + r.gauss(0, 0.4))))
    energy = max(3, min(9, round(r.choice([7, 7, 8, 8, 9]) - 2.8 * k + r.gauss(0, 0.4))))
    form = r.choices(["Normal", "Soft", "Mushy"], [0.8, 0.2, 0.0] if k == 0 else [0.3 - 0.25 * k, 0.5, 0.2 + 0.25 * k])[0]
    sym = []
    if r.random() < 0.1 + 0.65 * k:
        sym.append("Urgency")
    if r.random() < 0.08 + 0.45 * k:
        sym.append("Tiredness")
    if k > 0.5 and r.random() < 0.25:
        sym.append("Low appetite")
    if k == 0 and r.random() < 0.05:
        sym = ["Tiredness"]
    feeling = r.choices(["Great", "Good", "Okay", "Bad"], [0.35, 0.55, 0.1, 0] if k < 0.3 else [0.05, 0.3, 0.5, 0.15])[0]
    return {"feeling": feeling, "stool_count": stool, "stool_form": form, "blood": "None", "pain": pain,
            "night_waking": False, "symptoms": sym or [NONE_I], "energy": energy, "school_missed": False}


blank_days = {D(2026, 9, 2), D(2026, 10, 10)}
for d in days():
    wk = d.weekday() >= 5
    if r.random() < (0.9 if not wk else 0.76):
        t = (20, r.randint(5, 50)) if r.random() < 0.7 else (21, r.randint(0, 40))
        if d in blank_days:
            b.submit("asthma", d, t, blank=True)
        else:
            a = asthma_ans(d)
            b.submit("asthma", d, t, a)
            if r.random() < 0.04:
                b.submit("asthma", d, (t[0], min(59, t[1] + r.randint(2, 8))), {"feeling": a["feeling"]})
        p_ibd = (0.72 if d < CREEP else 0.88) * (1.0 if not wk else 0.85)
        if r.random() < p_ibd:
            ia = ibd_ans(d)
            if r.random() < 0.15:  # skips a couple of optional questions
                for k in r.sample(["stool_form", "energy", "symptoms", "night_waking"], 2):
                    ia[k] = None
            b.submit("ibd", d, (t[0], min(59, t[1] + r.randint(1, 4))), ia)
    if d.weekday() in (1, 5) or (d.weekday() == 3 and r.random() < 0.25):
        if r.random() < 0.8:
            b.spirometry_session(d, (19, r.randint(30, 50)) if not wk else (11, r.randint(0, 30)), pred,
                                 r.gauss(0.925, 0.018), n_blows=r.choice([3, 3, 4]), reject_prob=0.1,
                                 link_to_tracker=True)

b.set_action_plan("Green", "2026-08-08T17:22:45.310Z", "2027-02-08", None)


# ---- numbers for the ground-truth text
def ibd_sub(doc, start, end):
    t = b.trackers["ibd"]
    qs = {q["questionId"]: q for q in t["questions"]}
    st, pa, en, urg, n = [], [], [], 0, 0
    for log in doc["dailyLogs"]:
        d = date.fromisoformat(log["day"])
        if not (start <= d <= end):
            continue
        subs = [s for s in log["trackerResponses"] if s["trackerId"] == t["trackerId"] and any(x["value"] for x in s["responses"])]
        if not subs:
            continue
        n += 1
        vals = {}
        for s in subs:
            for x in s["responses"]:
                if x["value"] != "":
                    vals.setdefault(qs[x["questionId"]]["metricKey"], []).append(x["value"])
        if "stool_count" in vals:
            st.append(max(float(v) for v in vals["stool_count"]))
        if "pain" in vals:
            pa.append(max(float(v) for v in vals["pain"]))
        if "energy" in vals:
            en.append(max(float(v) for v in vals["energy"]))
        if any("Urgency" in json.loads(v) for v in vals.get("symptoms", [])):
            urg += 1
    avg = lambda xs: round(sum(xs) / len(xs), 1) if xs else None  # noqa: E731
    return {"days": n, "stool": avg(st), "stoolMax": max(st) if st else None, "pain": avg(pa), "painMax": max(pa) if pa else None,
            "energy": avg(en), "urgencyDays": urg}


doc = copy.deepcopy(b).build()
M = compute_metrics(doc, b.trackers)
TA, TI = M["trackers"][0], M["trackers"][1]
meds = {m["name"]: m for m in M["medications"]["medications"]}
F = meds["Fluticasone HFA 110 mcg"]
R = meds["Albuterol HFA"]
A = meds["Adalimumab 40 mg pen"]
I = meds["Ferrous sulfate 325 mg"]
S = M["spirometry"]
pre = ibd_sub(doc, D(2026, 8, 8), MISSED)
post = ibd_sub(doc, D(2026, 10, 22), D(2026, 11, 5))
asthma_pct = round(100 * TA["windows"]["full90"]["daysWithAnswers"] / 90)
ibd_pct = round(100 * TI["windows"]["full90"]["daysWithAnswers"] / 90)
IL, IP = TI["windows"]["last30"]["questions"], TI["windows"]["prior30"]["questions"]
blood_l = IL["blood"]["lastAnswerOfDayCounts"]
derived = "derived from dailyLogs with the same per-day rules"

b.save({
    "name": "Rosa",
    "age": 14,
    "conditions": ["Asthma", "IBD (Crohn's disease)"],
    "viewers": ["Pulmonologist", "Gastroenterologist", "Primary care"],
    "scenario": ("Teen with well controlled asthma and Crohn's disease on adalimumab. Asthma is quiet (Green, FEV1 steady in the low 90s, "
                 f"albuterol {R['windows']['full90']['daysUsed']} days in 90). She gave one adalimumab dose 4 days late in September and skipped the "
                 f"Oct 21 dose entirely; after that her IBD symptoms crept up (stool {pre['stool']} to {post['stool']}/day, pain {pre['pain']} "
                 f"to {post['pain']}, energy {pre['energy']} to {post['energy']}, more urgency, no blood). She logs IBD less often than asthma."),
    "clinician30s": (f"For GI: missed Oct 21 adalimumab dose, then rising stool frequency, pain and urgency with lower energy over the last 2 weeks, "
                     "no blood or night stools. Ask why the dose was missed, consider labs (CRP, calprotectin) and a drug level. "
                     "For pulmonology: nothing to change."),
    "expectedFlags": [
        {"flag": "missed_biologic_dose", "severity": "high", "for": ["Gastroenterologist"],
         "evidence": (f"Adalimumab expected 7 doses (Aug 12 to Nov 4), dosesRecordedFull90 {A['dosesRecordedFull90']}; "
                      f"full90 adherencePct {A['windows']['full90']['adherencePct']}, prior30 {A['windows']['prior30']['adherencePct']}, "
                      f"last30 {A['windows']['last30']['adherencePct']} ({A['windows']['last30']['dosesTaken']} of {A['windows']['last30']['expectedDoses']}). "
                      "No dose recorded within 2 days of Oct 21; Sep 23 dose recorded Sep 27 (4 days late, counted as missed by the 2-day match rule).")},
        {"flag": "ibd_symptoms_worsening_after_missed_dose", "severity": "medium", "for": ["Gastroenterologist"],
         "evidence": (f"IBD tracker last30 stool_count meanOfDailyMax {IL['stool_count']['meanOfDailyMax']} (max {IL['stool_count']['max']}) vs prior30 "
                      f"{IP['stool_count']['meanOfDailyMax']}; pain {IL['pain']['meanOfDailyMax']} vs {IP['pain']['meanOfDailyMax']}; energy "
                      f"{IL['energy']['meanOfDailyMax']} vs {IP['energy']['meanOfDailyMax']}; Urgency days {IL['symptoms']['daysByOption'].get('Urgency', 0)} vs "
                      f"{IP['symptoms']['daysByOption'].get('Urgency', 0)}. Oct 22 to Nov 5 ({derived}): stool {post['stool']} (max {post['stoolMax']:.0f}), "
                      f"pain {post['pain']} (max {post['painMax']:.0f}), energy {post['energy']}, urgency {post['urgencyDays']} of {post['days']} logged days, "
                      f"vs Aug 8 to Oct 21 stool {pre['stool']}, pain {pre['pain']}, energy {pre['energy']}. Blood last30: {blood_l}; night_waking yesDays {IL['night_waking']['yesDays']}.")},
        {"flag": "ibd_logging_gaps", "severity": "low", "for": ["Gastroenterologist"],
         "evidence": (f"IBD tracker daysWithAnswers full90 {TI['windows']['full90']['daysWithAnswers']} (about {ibd_pct}% of days) vs asthma "
                      f"{TA['windows']['full90']['daysWithAnswers']} (about {asthma_pct}%); IBD longestGapDays full90 {TI['windows']['full90']['longestGapDays']}. "
                      "Unlogged IBD days are unknown, not symptom-free.")},
        {"flag": "low_iron_adherence", "severity": "low", "for": ["Gastroenterologist"],
         "evidence": f"Ferrous sulfate full90 adherencePct {I['windows']['full90']['adherencePct']} (self-reported)."},
    ],
    "expectedNonFlags": [
        f"Asthma should not be flagged: fluticasone full90 adherence {F['windows']['full90']['adherencePct']}% (self-reported), albuterol "
        f"{R['windows']['full90']['daysUsed']} days in 90, FEV1 first14d {S['first14dAvgBestFev1Pct']} vs last14d {S['last14dAvgBestFev1Pct']} "
        f"(change {S['changeFev1PctPoints']}), Green zone.",
        "Slightly lower asthma 'feeling' scores in late October track her belly symptoms, not her asthma.",
        "The Sep 27 adalimumab dose is late, not missing; the metric counts it as missed only because of its 2-day match window.",
        "Mild IBD changes do not yet reach flare criteria: no blood, no night stools, no missed school.",
    ],
    "keyFindings": {
        "asthmaControl": f"well controlled, Green; fluticasone {F['windows']['full90']['adherencePct']}% (self-reported); albuterol {R['windows']['full90']['daysUsed']} days in 90",
        "fev1": f"steady, first14d {S['first14dAvgBestFev1Pct']:.1f}% vs last14d {S['last14dAvgBestFev1Pct']:.1f}%; {S['sessions']} sessions",
        "adalimumab": f"{A['dosesRecordedFull90']} of 7 doses recorded; Sep 23 dose 4 days late (Sep 27); Oct 21 missed; Nov 4 taken",
        "ibdSymptomCreep": f"Aug 8 to Oct 21: stool {pre['stool']}, pain {pre['pain']}, energy {pre['energy']}; Oct 22 to Nov 5: stool {post['stool']}, pain {post['pain']}, energy {post['energy']}, urgency {post['urgencyDays']}/{post['days']} days; no blood",
        "logging": f"asthma tracker about {asthma_pct}% of days, IBD tracker about {ibd_pct}% of days",
        "ironAdherence": f"{I['windows']['full90']['adherencePct']}%",
    },
    "specialistViews": {
        "Pulmonologist": "Asthma stable: Green, FEV1 low 90s and flat, rare rescue, good controller adherence. No change. Ignore the IBD side.",
        "Gastroenterologist": ("Main concern. Missed Oct 21 adalimumab and a late September dose, followed by rising stool count, pain, urgency and "
                               "tiredness without blood. Check adherence barriers (injection fear, schedule), labs, and whether to tighten follow-up. "
                               "IBD is logged on fewer days, so gaps are unknowns."),
        "Primary care": ("Both conditions in one view: asthma fine, Crohn's drifting after a missed biologic dose. Iron supplement taken about half "
                         "the time; consider checking ferritin and a simple routine (pair with inhaler)."),
    },
    "injectedQuirks": [
        "Two trackers assigned; IBD is submitted right after asthma on about 60% of days.",
        "Sep 23 adalimumab dose logged on Sep 27, outside the metric's 2-day matching window.",
        "Some IBD submissions skip optional questions (stool form, energy, symptoms, night waking).",
        "Spirometer-linked asthma submissions usually have an empty value (counted as blank).",
        "Two blank asthma submissions and a few feeling-only second submissions.",
    ],
})
print("p13-rosa done")
