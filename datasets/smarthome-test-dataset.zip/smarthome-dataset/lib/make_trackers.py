import json
import uuid
from pathlib import Path

NS = uuid.UUID("6f1c2a3e-9b7d-4e21-8a55-2c4d1e0f9a10")
OUT = Path(__file__).resolve().parent.parent / "trackers"


def uid(*parts):
    return str(uuid.uuid5(NS, "/".join(parts)))


FACE = ["Great", "Good", "Okay", "Bad", "Awful"]


def q(tracker, key, text, qtype, metric_key, options=None, required=False, none_option=None, unit=None, min_v=None, max_v=None):
    d = {
        "questionId": uid(tracker, key),
        "text": text,
        "type": qtype,
        "required": required,
        "metricKey": metric_key,
    }
    if options is not None:
        d["options"] = options
    if none_option is not None:
        d["noneOption"] = none_option
    if unit is not None:
        d["unit"] = unit
    if min_v is not None:
        d["min"] = min_v
        d["max"] = max_v
    return d


TRACKERS = {
    "asthma": {
        "trackerId": uid("tracker", "asthma"),
        "name": "Asthma Tracker",
        "condition": "Asthma",
        "version": 3,
        "questions": [
            q("asthma", "spiro", "Please complete your spirometer reading", "spirometry", "spirometry_prompt"),
            q("asthma", "feeling", "How are you feeling today?", "face_scale", "feeling", options=FACE, required=True),
            q("asthma", "symptoms", "Please select the following symptoms that you are currently experiencing", "checkbox", "symptoms",
              options=["Coughing", "Wheezing", "Tight Chest", "Shortness Of Breath", "Activity limitations", "None of these "],
              none_option="None of these "),
            q("asthma", "night", "Did your asthma wake you up last night?", "yes_no", "night_waking"),
            q("asthma", "school", "Did you miss school or activities today because of your asthma?", "yes_no", "school_missed"),
            q("asthma", "trigger", "Were you around any of these today?", "checkbox", "triggers",
              options=["Smoke", "Pollen", "Pets", "Cold air", "Exercise", "Being sick", "None of these"],
              none_option="None of these"),
        ],
    },
    "ibd": {
        "trackerId": uid("tracker", "ibd"),
        "name": "IBD Tracker",
        "condition": "IBD",
        "version": 1,
        "questions": [
            q("ibd", "feeling", "How are you feeling today?", "face_scale", "feeling", options=FACE, required=True),
            q("ibd", "bm", "How many times did you poop today?", "number", "stool_count", unit="times", min_v=0, max_v=30),
            q("ibd", "stool", "What did most of your poop look like?", "icon_choice", "stool_form",
              options=["Hard lumps", "Normal", "Soft", "Mushy", "Watery"]),
            q("ibd", "blood", "Did you see any blood?", "single_choice", "blood",
              options=["None", "A little", "A lot"]),
            q("ibd", "pain", "How bad is your belly pain right now?", "scale_1_10", "pain", min_v=1, max_v=10),
            q("ibd", "night", "Did you wake up at night to poop?", "yes_no", "night_waking"),
            q("ibd", "symptoms", "Do you have any of these right now?", "checkbox", "symptoms",
              options=["Urgency", "Nausea", "Low appetite", "Tiredness", "Joint pain", "None of these"],
              none_option="None of these"),
            q("ibd", "energy", "How is your energy today?", "scale_1_10", "energy", min_v=1, max_v=10),
            q("ibd", "school", "Did you miss school or activities today because of your belly?", "yes_no", "school_missed"),
        ],
    },
    "migraine": {
        "trackerId": uid("tracker", "migraine"),
        "name": "Migraine Tracker",
        "condition": "Migraine",
        "version": 2,
        "questions": [
            q("migraine", "feeling", "How are you feeling today?", "face_scale", "feeling", options=FACE, required=True),
            q("migraine", "headache", "Did you have a headache today?", "yes_no", "headache", required=True),
            q("migraine", "severity", "How bad was your worst headache today?", "scale_1_10", "severity", min_v=1, max_v=10),
            q("migraine", "duration", "How long did it last?", "single_choice", "duration",
              options=["Less than 1 hour", "1 to 4 hours", "4 to 12 hours", "All day"]),
            q("migraine", "symptoms", "Did you have any of these with your headache?", "checkbox", "symptoms",
              options=["Nausea", "Throwing up", "Light bothered me", "Sound bothered me", "Aura (seeing spots or lines)", "None of these"],
              none_option="None of these"),
            q("migraine", "triggers", "What do you think set it off?", "checkbox", "triggers",
              options=["Poor sleep", "Skipped a meal", "Stress", "Screens", "Weather", "Period", "Not sure"]),
            q("migraine", "sleep", "How many hours did you sleep last night?", "number", "sleep_hours", unit="hours", min_v=0, max_v=16),
            q("migraine", "school", "Did you miss school or activities today because of a headache?", "yes_no", "school_missed"),
        ],
    },
}

if __name__ == "__main__":
    OUT.mkdir(exist_ok=True)
    for key, t in TRACKERS.items():
        (OUT / f"{key}.json").write_text(json.dumps(t, indent=2) + "\n")
    print("wrote", ", ".join(TRACKERS))
