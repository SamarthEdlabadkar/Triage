"""Reference metrics for ground truth. One possible set of aggregation rules, documented in README."""
import json
from datetime import date, timedelta

from smarthome import WINDOW_END, WINDOW_START, local_day, parse_iso, TZ

WINDOWS = {
    "last30": (WINDOW_END - timedelta(days=29), WINDOW_END),
    "prior30": (WINDOW_END - timedelta(days=59), WINDOW_END - timedelta(days=30)),
    "full90": (WINDOW_START, WINDOW_END),
}


def _in(d, w):
    return w[0] <= d <= w[1]


def _decode(question, value):
    if value == "":
        return None
    t = question["type"]
    if t == "checkbox":
        return json.loads(value)
    if t in ("number", "scale_1_10"):
        return float(value)
    if t == "yes_no":
        return value == "Yes"
    return value


def _is_blank(sub):
    return not any(r["value"] != "" for r in sub["responses"])


def tracker_metrics(doc, tracker):
    qs = {q["questionId"]: q for q in tracker["questions"]}
    per_day = {}
    total = blank = 0
    last_any = last_nonblank = None
    for log in doc["dailyLogs"]:
        d = date.fromisoformat(log["day"])
        subs = [s for s in log["trackerResponses"] if s["trackerId"] == tracker["trackerId"]]
        if not subs:
            continue
        total += len(subs)
        last_any = max(last_any or "", max(s["submittedAt"] for s in subs))
        nb = [s for s in subs if not _is_blank(s)]
        blank += len(subs) - len(nb)
        if nb:
            last_nonblank = max(last_nonblank or "", max(s["submittedAt"] for s in nb))
        per_day[d] = {"subs": len(subs), "nonblank": nb}

    out = {
        "trackerName": tracker["name"],
        "totalSubmissions": total,
        "blankSubmissions": blank,
        "lastSubmission": last_any,
        "lastNonBlankSubmission": last_nonblank,
        "windows": {},
    }
    for wname, w in WINDOWS.items():
        wdays = {d: v for d, v in per_day.items() if _in(d, w)}
        logged = sorted(d for d, v in wdays.items() if v["nonblank"])
        gaps = [(b - a).days - 1 for a, b in zip(logged, logged[1:])]
        wm = {
            "daysWithAnySubmission": len(wdays),
            "daysWithAnswers": len(logged),
            "multiSubmissionDays": sum(1 for v in wdays.values() if v["subs"] > 1),
            "longestGapDays": max(gaps) if gaps else None,
            "questions": {},
        }
        for q in tracker["questions"]:
            if q["type"] == "spirometry":
                continue
            daily = []
            for d in logged:
                vals = []
                for s in wdays[d]["nonblank"]:
                    for r in s["responses"]:
                        if r["questionId"] == q["questionId"]:
                            v = _decode(q, r["value"])
                            if v is not None:
                                vals.append(v)
                if vals:
                    daily.append(vals)
            key = q["metricKey"]
            t = q["type"]
            if t == "checkbox":
                none = q.get("noneOption")
                counts = {}
                any_days = 0
                for vals in daily:
                    union = {x for v in vals for x in v if x != none}
                    if union:
                        any_days += 1
                    for x in union:
                        counts[x] = counts.get(x, 0) + 1
                wm["questions"][key] = {"daysAnswered": len(daily), "daysWithAny": any_days, "daysByOption": dict(sorted(counts.items()))}
            elif t == "yes_no":
                wm["questions"][key] = {"daysAnswered": len(daily), "yesDays": sum(1 for vals in daily if any(vals))}
            elif t in ("number", "scale_1_10"):
                mx = [max(vals) for vals in daily]
                wm["questions"][key] = {
                    "daysAnswered": len(daily),
                    "meanOfDailyMax": round(sum(mx) / len(mx), 2) if mx else None,
                    "max": max(mx) if mx else None,
                }
            else:
                counts = {}
                for vals in daily:
                    counts[vals[-1]] = counts.get(vals[-1], 0) + 1
                wm["questions"][key] = {"daysAnswered": len(daily), "lastAnswerOfDayCounts": counts}
        out["windows"][wname] = wm
    return out


def _due(med, d):
    timing = med["dosage"]["timing"]
    if med["howOften"] == "As Needed":
        return 0
    start = date.fromisoformat(med["startDate"])
    if d < start:
        return 0
    if timing["daysOfWeek"] is not None and d.weekday() not in timing["daysOfWeek"]:
        return 0
    if timing["periodUnit"] == "Weekly" and (d - start).days % (7 * timing["interval"]) != 0:
        return 0
    return max(1, len(timing["timesOfDay"]))


def med_metrics(doc):
    admins = {}
    for log in doc["dailyLogs"]:
        for a in log["medicationAdministrations"]:
            admins.setdefault(a["medicationId"], []).append((date.fromisoformat(log["day"]), a))
    known = {m["id"] for m in doc["medications"]}
    out = {"medications": [], "dosesWithUnknownMedicationId": sum(len(v) for k, v in admins.items() if k not in known)}
    for med in doc["medications"]:
        recs = admins.get(med["id"], [])
        m = {
            "medicationId": med["id"],
            "name": med["name"],
            "relatedCondition": med["relatedCondition"],
            "howOften": med["howOften"],
            "archived": med["archived"],
            "dosesRecordedFull90": sum(1 for d, _ in recs if _in(d, WINDOWS["full90"])),
            "windows": {},
        }
        for wname, w in WINDOWS.items():
            wr = [(d, a) for d, a in recs if _in(d, w)]
            if med["howOften"] == "As Needed" or med["archived"]:
                m["windows"][wname] = {
                    "daysUsed": len({d for d, _ in wr}),
                    "totalUnits": sum(float(a["value"]) for _, a in wr),
                }
                continue
            weekly = med["dosage"]["timing"]["periodUnit"] == "Weekly"
            expected = taken = on_time = 0
            times = med["dosage"]["timing"]["timesOfDay"]
            used = set()
            d = w[0]
            while d <= w[1]:
                due = _due(med, d)
                if due:
                    expected += due
                    if weekly:
                        match = next((i for i, (dd, _) in enumerate(recs) if i not in used and abs((dd - d).days) <= 2), None)
                        if match is not None:
                            used.add(match)
                            taken += 1
                            on_time += 1 if recs[match][0] == d else 0
                    else:
                        day_recs = [a for dd, a in recs if dd == d]
                        taken += min(due, len(day_recs))
                        for slot, a in zip(times, sorted(day_recs, key=lambda x: x["administeredAt"])):
                            hh, mm = map(int, slot.split(":"))
                            lt = parse_iso(a["administeredAt"]).astimezone(TZ)
                            if abs((lt.hour * 60 + lt.minute) - (hh * 60 + mm)) <= 120:
                                on_time += 1
                d += timedelta(days=1)
            m["windows"][wname] = {
                "expectedDoses": expected,
                "dosesTaken": taken,
                "adherencePct": round(100 * taken / expected, 1) if expected else None,
                "onTimePct": round(100 * on_time / taken, 1) if taken else None,
            }
        out["medications"].append(m)
    return out


def spirometry_metrics(doc):
    if not doc["medicalDevices"]:
        return None
    blows = doc["medicalDevices"][0]["baselineReadings"]
    sessions = {}
    for b in blows:
        sessions.setdefault(b["sessionId"], []).append(b)
    rows = []
    for sid, bs in sessions.items():
        acc = [b for b in bs if b["accepted"]]
        best = max(acc, key=lambda b: b["fvcPlusResults"]["fev1"]) if acc else None
        rows.append({
            "day": local_day(bs[0]["readingDate"]),
            "blows": len(bs),
            "accepted": len(acc),
            "bestFev1": best["fvcPlusResults"]["fev1"] if best else None,
            "bestFev1Pct": best["fvcPlusResults"]["fev1PercentPredicted"] if best else None,
            "grade": bs[0]["qualityReport"]["sessionGrade"],
        })
    rows.sort(key=lambda r: r["day"])
    usable = [r for r in rows if r["bestFev1"] is not None]

    def avg(rs, k):
        return round(sum(r[k] for r in rs) / len(rs), 3) if rs else None

    first = [r for r in usable if (r["day"] - usable[0]["day"]).days < 14] if usable else []
    last = [r for r in usable if (usable[-1]["day"] - r["day"]).days < 14] if usable else []
    out = {
        "sessions": len(rows),
        "blows": len(blows),
        "acceptedBlows": sum(r["accepted"] for r in rows),
        "sessionsWithNoAcceptedBlow": sum(1 for r in rows if r["accepted"] == 0),
        "gradeCounts": {g: sum(1 for r in rows if r["grade"] == g) for g in "ABCDF" if any(r["grade"] == g for r in rows)},
        "firstSession": rows[0]["day"].isoformat() if rows else None,
        "lastSession": rows[-1]["day"].isoformat() if rows else None,
        "first14dAvgBestFev1Pct": avg(first, "bestFev1Pct"),
        "last14dAvgBestFev1Pct": avg(last, "bestFev1Pct"),
        "minBestFev1PctLast30": round(min((r["bestFev1Pct"] for r in usable if _in(r["day"], WINDOWS["last30"])), default=0), 1) or None,
        "sessionsLast30": sum(1 for r in rows if _in(r["day"], WINDOWS["last30"])),
    }
    if out["first14dAvgBestFev1Pct"] and out["last14dAvgBestFev1Pct"]:
        out["changeFev1PctPoints"] = round(out["last14dAvgBestFev1Pct"] - out["first14dAvgBestFev1Pct"], 1)
    return out


def compute_metrics(doc, trackers):
    by_id = {t["trackerId"]: t for t in trackers.values()}
    last = []
    for log in doc["dailyLogs"]:
        last += [s["submittedAt"] for s in log["trackerResponses"]]
        last += [a["administeredAt"] for a in log["medicationAdministrations"]]
    for dev in doc["medicalDevices"]:
        last += [b["readingDate"] for b in dev["baselineReadings"]]
    return {
        "aggregationRules": "see README: per-day answer = last non-blank submission; checkboxes = union of the day; yes/no = any Yes; numbers = daily max",
        "lastAnyActivity": max(last) if last else None,
        "trackers": [tracker_metrics(doc, by_id[a["trackerId"]]) for a in doc["assignedTrackers"]],
        "medications": med_metrics(doc),
        "spirometry": spirometry_metrics(doc),
        "asthmaActionPlan": doc["asthmaTreatmentPlan"]["status"] if doc["asthmaTreatmentPlan"] else None,
        "earnedBadgeCount": len(doc["earnedTrackerBadges"]) + len(doc["earnedMedicationBadges"]),
    }
