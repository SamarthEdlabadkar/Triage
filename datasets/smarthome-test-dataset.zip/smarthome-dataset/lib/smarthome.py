"""Shared builder for SMART@Home synthetic patient records.

Every generator imports PatientBuilder from here so all 13 files share one format.
"""
import json
import random
import uuid
from datetime import date, datetime, time, timedelta, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parent.parent
TZ = ZoneInfo("America/New_York")
WINDOW_START = date(2026, 8, 8)
WINDOW_END = date(2026, 11, 5)
VISIT_DATE = date(2026, 11, 6)

QUALITY_MESSAGES = [
    "KeepGoingUntilCompletelyEmpty",
    "BlastOutImmediatelyWhenCompletelyFull",
    "DontHesitate",
    "BlowOutFasterAndHarder",
    "AvoidCoughing",
]
TRACKER_BADGE_STREAKS = [3, 5, 7, 10, 14, 21, 30]
MED_BADGE_STREAKS = [3, 7, 14, 30]


def load_trackers():
    return {p.stem: json.loads(p.read_text()) for p in (ROOT / "trackers").glob("*.json")}


def days(start=WINDOW_START, end=WINDOW_END):
    d = start
    while d <= end:
        yield d
        d += timedelta(days=1)


def to_utc_iso(day, hh, mm, ss=0, ms=0):
    local = datetime.combine(day, time(hh, mm, ss, ms * 1000), tzinfo=TZ)
    return local.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.") + f"{ms:03d}Z"


def parse_iso(s):
    return datetime.strptime(s, "%Y-%m-%dT%H:%M:%S.%fZ").replace(tzinfo=timezone.utc)


def local_day(iso):
    return parse_iso(iso).astimezone(TZ).date()


def _hm(t):
    if isinstance(t, str):
        h, m = t.split(":")
        return int(h), int(m)
    return t


class PatientBuilder:
    def __init__(self, persona_id, display_name, age, sex, seed, enrolled_date=WINDOW_START,
                 height_cm=None, dob=None):
        self.persona_id = persona_id
        self.rng = random.Random(seed)
        self.trackers = load_trackers()
        self.enrolled_date = enrolled_date
        self.doc = {
            "id": self._uuid(),
            "personaId": persona_id,
            "studyId": f"SAH-{self.rng.randint(1000, 9999)}",
            "displayName": display_name,
            "age": age,
            "sex": sex,
            "dateOfBirth": dob,
            "heightCm": height_cm,
            "enrolledDate": enrolled_date.isoformat(),
            "assignedTrackers": [],
            "medications": [],
            "reminders": [],
            "medicalDevices": [],
            "asthmaTreatmentPlan": None,
            "dailyLogs": [],
            "earnedMedicationBadges": [],
            "earnedTrackerBadges": [],
        }
        self._logs = {}
        self._med_index = 0

    def _uuid(self):
        return str(uuid.UUID(int=self.rng.getrandbits(128), version=4))

    def _log(self, day):
        key = day.isoformat()
        if key not in self._logs:
            self._logs[key] = {
                "day": key,
                "allMedicationsAdministered": None,
                "trackerResponses": [],
                "medicationAdministrations": [],
            }
        return self._logs[key]

    def _ms(self):
        return self.rng.randint(0, 999)

    def assign_tracker(self, tracker_key, assigned_date=None):
        t = self.trackers[tracker_key]
        self.doc["assignedTrackers"].append({
            "trackerId": t["trackerId"],
            "trackerName": t["name"],
            "assignedDate": (assigned_date or self.enrolled_date).isoformat(),
        })
        return t["trackerId"]

    def add_medication(self, name, condition, how_often, icon, dose_qty, dose_unit,
                       times=None, period_unit="Daily", interval=1, archived=False,
                       start_date=None, schedule_days=None, reminder=True):
        """how_often: 'Daily', 'As Needed', 'Weekly', 'Every 2 Weeks', 'School Days'.
        times: list of 'HH:MM' local times for scheduled meds.
        schedule_days: optional list of weekday ints (0=Mon) the med is due on."""
        med_id = self._uuid()
        med = {
            "id": med_id,
            "name": name,
            "relatedCondition": condition,
            "howOften": how_often,
            "icon": icon,
            "dosage": {
                "doseQuantity": dose_qty,
                "doseUnit": dose_unit,
                "timing": {
                    "periodUnit": period_unit if how_often != "As Needed" else None,
                    "interval": interval if how_often != "As Needed" else None,
                    "timesOfDay": times or [],
                    "daysOfWeek": schedule_days,
                },
            },
            "startDate": (start_date or self.enrolled_date).isoformat(),
            "archived": archived,
            "index": self._med_index,
        }
        self._med_index += 1
        self.doc["medications"].append(med)
        if reminder and times and not archived:
            for t in times:
                self.doc["reminders"].append({
                    "id": self._uuid(),
                    "type": "Medication",
                    "medicationId": med_id,
                    "time": t,
                    "daysOfWeek": schedule_days or [0, 1, 2, 3, 4, 5, 6],
                    "enabled": True,
                })
        return med_id

    def add_tracker_reminder(self, tracker_key, t, enabled=True):
        self.doc["reminders"].append({
            "id": self._uuid(),
            "type": "Tracker",
            "trackerId": self.trackers[tracker_key]["trackerId"],
            "time": t,
            "daysOfWeek": [0, 1, 2, 3, 4, 5, 6],
            "enabled": enabled,
        })

    def take_dose(self, med_id, day, t, value=1):
        hh, mm = _hm(t)
        name = next(m["name"] for m in self.doc["medications"] if m["id"] == med_id)
        self._log(day)["medicationAdministrations"].append({
            "medicationId": med_id,
            "name": name,
            "administeredAt": to_utc_iso(day, hh, mm, self.rng.randint(0, 59), self._ms()),
            "value": str(value),
        })

    def _serialize(self, question, v):
        qt = question["type"]
        if v == "":
            return ""
        if qt == "checkbox":
            return json.dumps(list(v), separators=(",", ":"))
        if qt == "yes_no":
            return "Yes" if v in (True, "Yes") else "No"
        if qt in ("number", "scale_1_10"):
            return str(v)
        if qt == "spirometry":
            return v if isinstance(v, str) else json.dumps(v, separators=(",", ":"))
        if "options" in question and v not in question["options"]:
            raise ValueError(f"{v!r} not an option for {question['metricKey']}")
        return str(v)

    def submit(self, tracker_key, day, t, answers=None, blank=False, empty_values=False):
        """answers: {metricKey: python value}. Missing keys are left out (optional).
        blank=True -> submission with no responses. empty_values=True -> every question present with value ''."""
        tracker = self.trackers[tracker_key]
        hh, mm = _hm(t)
        responses = []
        if empty_values:
            responses = [{"questionId": q["questionId"], "value": ""} for q in tracker["questions"]]
        elif not blank:
            by_key = {q["metricKey"]: q for q in tracker["questions"]}
            for k, v in (answers or {}).items():
                if v is None:
                    continue
                q = by_key[k]
                responses.append({"questionId": q["questionId"], "value": self._serialize(q, v)})
        self._log(day)["trackerResponses"].append({
            "trackerId": tracker["trackerId"],
            "trackerVersion": tracker["version"],
            "submittedAt": to_utc_iso(day, hh, mm, self.rng.randint(0, 59), self._ms()),
            "responses": responses,
        })

    def add_spirobank(self, serial="Z125775"):
        dev = {
            "id": self._uuid(),
            "protocol": 9,
            "address": str(uuid.UUID(int=self.rng.getrandbits(128))).upper(),
            "bootId": "SM",
            "serialNumber": serial,
            "deviceType": 0,
            "atsStandard": "ATS/ERS 2019",
            "name": "Spirobank",
            "advertisementName": f"SM-009-{serial}",
            "baselineReadingDate": None,
            "baselineReadings": [],
        }
        self.doc["medicalDevices"].append(dev)
        return dev

    def spirometry_session(self, day, t, pred, fev1_pct, fvc_pct=None, n_blows=3,
                           reject_prob=0.15, noise=0.035, tracker_key="asthma",
                           link_to_tracker=False, ratio_cap=None):
        """pred: dict with fev1, fvc, pef (L, L, L/s) predicted for this child.
        fev1_pct: true % predicted for this session (e.g. 0.92).
        Returns list of blows and the best accepted FEV1 (or None)."""
        dev = self.doc["medicalDevices"][0]
        fvc_pct = fvc_pct if fvc_pct is not None else min(1.05, fev1_pct + 0.06)
        hh, mm = _hm(t)
        session_id = self._uuid()
        blows = []
        for i in range(n_blows):
            rejected = self.rng.random() < reject_prob
            effort = self.rng.uniform(0.72, 0.9) if rejected else self.rng.uniform(0.97, 1.0)
            fev1 = pred["fev1"] * fev1_pct * effort * (1 + self.rng.gauss(0, noise))
            fvc = pred["fvc"] * fvc_pct * (effort if not rejected else self.rng.uniform(0.78, 0.92)) * (1 + self.rng.gauss(0, noise))
            fvc = max(fvc, fev1 * 1.02)
            ratio = fev1 / fvc
            if ratio_cap and ratio > ratio_cap:
                fev1 = fvc * ratio_cap * self.rng.uniform(0.97, 1.0)
                ratio = fev1 / fvc
            pef = pred["pef"] * fev1_pct * effort * (1 + self.rng.gauss(0, noise * 1.5))
            fef2575 = fev1 * self.rng.uniform(0.8, 1.15) * (ratio / 0.85)
            msgs = []
            if rejected:
                msgs.append(self.rng.choice(QUALITY_MESSAGES))
                if self.rng.random() < 0.25:
                    msgs.append(self.rng.choice([m for m in QUALITY_MESSAGES if m not in msgs]))
            blows.append({
                "readingId": self._uuid(),
                "sessionId": session_id,
                "readingDate": to_utc_iso(day, hh, min(59, mm + i), self.rng.randint(0, 59), self._ms()),
                "accepted": not rejected,
                "fvcPlusResults": {
                    "fvc": fvc,
                    "fev1": fev1,
                    "fev1FvcRatio": ratio * 100,
                    "pef": pef,
                    "fef2575": fef2575,
                    "fev1PercentPredicted": fev1 / pred["fev1"] * 100,
                    "fvcPercentPredicted": fvc / pred["fvc"] * 100,
                    "pefPercentPredicted": pef / pred["pef"] * 100,
                    "fev1Predicted": pred["fev1"],
                    "fvcPredicted": pred["fvc"],
                    "pefPredicted": pred["pef"],
                    "fet": round(self.rng.uniform(1.4, 3.2) if rejected else self.rng.uniform(3.0, 6.5), 2),
                    "evol": round(self.rng.uniform(0.02, 0.2), 3),
                },
                "qualityReport": {"qualityIndications": msgs},
            })
        accepted = [b for b in blows if b["accepted"]]
        fev1s = sorted((b["fvcPlusResults"]["fev1"] for b in accepted), reverse=True)
        if len(accepted) >= 3 and fev1s[0] - fev1s[1] <= 0.15:
            grade = "A"
        elif len(accepted) >= 2 and fev1s[0] - fev1s[1] <= 0.15:
            grade = "B"
        elif len(accepted) >= 2:
            grade = "C"
        elif len(accepted) == 1:
            grade = "D"
        else:
            grade = "F"
        # Device quirk from the brief: qualityCode is session-level and often disagrees with per-blow accepted.
        code = "Accept" if grade in ("A", "B") else "NotAccept"
        for b in blows:
            b["qualityReport"]["sessionGrade"] = grade
            b["qualityReport"]["qualityCode"] = code
        dev["baselineReadings"].extend(blows)
        if dev["baselineReadingDate"] is None:
            dev["baselineReadingDate"] = day.isoformat()
        best = fev1s[0] if fev1s else None
        if link_to_tracker:
            value = "" if self.rng.random() < 0.7 else {"sessionId": session_id, "bestFev1": round(best, 2) if best else None}
            self.submit(tracker_key, day, (hh, min(59, mm + n_blows)), {"spirometry_prompt": value})
        return blows, best

    def set_action_plan(self, status, last_updated, expiration, retest_time=None):
        self.doc["asthmaTreatmentPlan"] = {
            "status": status,
            "lastUpdated": last_updated,
            "expiration": expiration,
            "retestTime": retest_time,
        }

    def _scheduled_due(self, med, day):
        timing = med["dosage"]["timing"]
        if med["howOften"] == "As Needed" or med["archived"]:
            return 0
        start = date.fromisoformat(med["startDate"])
        if day < start:
            return 0
        if timing["daysOfWeek"] is not None and day.weekday() not in timing["daysOfWeek"]:
            return 0
        if timing["periodUnit"] == "Weekly":
            if (day - start).days % (7 * timing["interval"]) != 0:
                return 0
            return max(1, len(timing["timesOfDay"]))
        return max(1, len(timing["timesOfDay"]))

    def _compute_badges(self):
        nonblank_days = {}
        for k, log in self._logs.items():
            for r in log["trackerResponses"]:
                if any(x["value"] != "" for x in r["responses"]):
                    nonblank_days.setdefault(k, []).append(r["submittedAt"])
        streak, earned = 0, set()
        prev = None
        for d in sorted(nonblank_days):
            dd = date.fromisoformat(d)
            streak = streak + 1 if prev and (dd - prev).days == 1 else 1
            prev = dd
            for s in TRACKER_BADGE_STREAKS:
                if streak == s and s not in earned:
                    earned.add(s)
                    self.doc["earnedTrackerBadges"].append({"badgeName": f"TrackerBadge{s}", "date": max(nonblank_days[d])})
        for med in self.doc["medications"]:
            streak, earned = 0, set()
            for d in days(date.fromisoformat(med["startDate"]), WINDOW_END):
                due = self._scheduled_due(med, d)
                if due == 0:
                    continue
                log = self._logs.get(d.isoformat())
                taken = sum(1 for a in (log["medicationAdministrations"] if log else []) if a["medicationId"] == med["id"])
                if taken >= due:
                    streak += 1
                    for s in MED_BADGE_STREAKS:
                        if streak == s and s not in earned:
                            earned.add(s)
                            self.doc["earnedMedicationBadges"].append({
                                "badgeName": f"MedicationBadge{s}",
                                "medicationId": med["id"],
                                "date": to_utc_iso(d, 21, 0),
                            })
                else:
                    streak = 0

    def build(self):
        for k, log in self._logs.items():
            d = date.fromisoformat(k)
            log["trackerResponses"].sort(key=lambda r: r["submittedAt"])
            log["medicationAdministrations"].sort(key=lambda a: a["administeredAt"])
            due_total, all_ok = 0, True
            for med in self.doc["medications"]:
                due = self._scheduled_due(med, d)
                if due:
                    due_total += due
                    taken = sum(1 for a in log["medicationAdministrations"] if a["medicationId"] == med["id"])
                    all_ok = all_ok and taken >= due
            log["allMedicationsAdministered"] = all_ok if due_total else None
        self.doc["dailyLogs"] = [self._logs[k] for k in sorted(self._logs)]
        self.doc["earnedTrackerBadges"] = []
        self.doc["earnedMedicationBadges"] = []
        self._compute_badges()
        return self.doc

    def save(self, ground_truth):
        """ground_truth: dict with hand-written fields. Metrics are computed and attached here."""
        from metrics import compute_metrics
        doc = self.build()
        (ROOT / "patients" / f"{self.persona_id}.json").write_text(json.dumps(doc, indent=2) + "\n")
        gt = dict(ground_truth)
        gt["personaId"] = self.persona_id
        gt["patientDocId"] = doc["id"]
        gt["computedMetrics"] = compute_metrics(doc, self.trackers)
        (ROOT / "ground_truth" / f"{self.persona_id}.json").write_text(json.dumps(gt, indent=2) + "\n")
        return doc, gt
