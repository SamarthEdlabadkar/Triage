"""Validate every patient file against the shared format and its ground truth.
Usage: python3 lib/validate.py [persona-id ...]"""
import json
import sys
from datetime import date

from metrics import compute_metrics
from smarthome import ROOT, WINDOW_END, WINDOW_START, load_trackers, local_day

TOP = {"id": str, "personaId": str, "studyId": str, "displayName": str, "age": int, "sex": str,
       "enrolledDate": str, "assignedTrackers": list, "medications": list, "reminders": list,
       "medicalDevices": list, "dailyLogs": list, "earnedMedicationBadges": list, "earnedTrackerBadges": list}
GT_KEYS = ["name", "age", "conditions", "viewers", "scenario", "clinician30s", "expectedFlags",
           "keyFindings", "injectedQuirks", "computedMetrics"]


def check(pid, trackers):
    errs, warns = [], []
    doc = json.loads((ROOT / "patients" / f"{pid}.json").read_text())
    gt_path = ROOT / "ground_truth" / f"{pid}.json"
    for k, t in TOP.items():
        if not isinstance(doc.get(k), t):
            errs.append(f"top-level {k} missing or not {t.__name__}")
    if "asthmaTreatmentPlan" not in doc:
        errs.append("asthmaTreatmentPlan key missing (use null when not asthma)")
    by_id = {t["trackerId"]: t for t in trackers.values()}
    assigned = {a["trackerId"] for a in doc["assignedTrackers"]}
    meds = {m["id"] for m in doc["medications"]}
    days_seen = []
    n_sub = n_dose = 0
    for log in doc["dailyLogs"]:
        d = date.fromisoformat(log["day"])
        days_seen.append(d)
        if not (WINDOW_START <= d <= WINDOW_END):
            errs.append(f"{log['day']} outside 90-day window")
        for s in log["trackerResponses"]:
            n_sub += 1
            if s["trackerId"] not in assigned:
                errs.append(f"{log['day']} response for unassigned tracker")
                continue
            if local_day(s["submittedAt"]) != d:
                errs.append(f"{log['day']} submittedAt {s['submittedAt']} is a different local day")
            qs = {q["questionId"]: q for q in by_id[s["trackerId"]]["questions"]}
            for r in s["responses"]:
                q = qs.get(r["questionId"])
                if q is None:
                    errs.append(f"{log['day']} unknown questionId {r['questionId']}")
                    continue
                if not isinstance(r["value"], str):
                    errs.append(f"{log['day']} value not a string for {q['metricKey']}")
                    continue
                v = r["value"]
                if v == "":
                    continue
                if q["type"] == "checkbox":
                    bad = [x for x in json.loads(v) if x not in q["options"]]
                    if bad:
                        errs.append(f"{log['day']} {q['metricKey']} bad options {bad}")
                elif q["type"] in ("face_scale", "single_choice", "icon_choice") and v not in q["options"]:
                    errs.append(f"{log['day']} {q['metricKey']} bad option {v!r}")
                elif q["type"] in ("number", "scale_1_10"):
                    x = float(v)
                    if "min" in q and not (q["min"] <= x <= q["max"]):
                        errs.append(f"{log['day']} {q['metricKey']} out of range {v}")
                elif q["type"] == "yes_no" and v not in ("Yes", "No"):
                    errs.append(f"{log['day']} yes_no value {v!r}")
        for a in log["medicationAdministrations"]:
            n_dose += 1
            if local_day(a["administeredAt"]) != d:
                errs.append(f"{log['day']} dose time on a different local day")
            if a["medicationId"] not in meds:
                warns.append(f"{log['day']} dose with unknown medicationId")
            if not isinstance(a["value"], str):
                errs.append(f"{log['day']} dose value not a string")
    if days_seen != sorted(set(days_seen)):
        errs.append("dailyLogs not sorted or has duplicate days")
    n_blow = 0
    for dev in doc["medicalDevices"]:
        for b in dev["baselineReadings"]:
            n_blow += 1
            if not (WINDOW_START <= local_day(b["readingDate"]) <= WINDOW_END):
                errs.append(f"reading {b['readingDate']} outside window")
            if not isinstance(b["accepted"], bool):
                errs.append("reading accepted not bool")
            res = b["fvcPlusResults"]
            if not (0.3 < res["fev1"] < 6.5 and res["fev1"] < res["fvc"]):
                errs.append(f"implausible spirometry {res['fev1']:.2f}/{res['fvc']:.2f} on {b['readingDate']}")
    if "Asthma" in [by_id[t]["condition"] for t in assigned]:
        if doc["asthmaTreatmentPlan"] is None:
            warns.append("asthma tracker but no action plan")
    if not gt_path.exists():
        errs.append("ground truth file missing")
        gt = {}
    else:
        gt = json.loads(gt_path.read_text())
        for k in GT_KEYS:
            if k not in gt:
                errs.append(f"ground truth missing {k}")
        if gt.get("computedMetrics") != json.loads(json.dumps(compute_metrics(doc, trackers))):
            errs.append("ground truth metrics are stale: rerun the generator")
    return errs, warns, {"subs": n_sub, "doses": n_dose, "blows": n_blow, "flags": len(gt.get("expectedFlags", []))}


def main():
    trackers = load_trackers()
    ids = sys.argv[1:] or sorted(p.stem for p in (ROOT / "patients").glob("*.json"))
    ok = True
    print(f"{'persona':<14}{'subs':>6}{'doses':>7}{'blows':>7}{'flags':>7}  result")
    for pid in ids:
        errs, warns, s = check(pid, trackers)
        status = "OK" if not errs else f"{len(errs)} errors"
        print(f"{pid:<14}{s['subs']:>6}{s['doses']:>7}{s['blows']:>7}{s['flags']:>7}  {status}" + (f" ({len(warns)} warnings)" if warns else ""))
        for e in errs[:15]:
            print("   ERROR", e)
        for w in warns[:5]:
            print("   warn ", w)
        ok = ok and not errs
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
